<?php

// Admin Actions /////////////////////////////////////////////////////////////////////////////////////

// This File will control all admin actions for 2 reasons ...

// 1: Security. All Actions will require a post action, and can do server tokens in the future.

// 2: Future Feature Will Allow Admin Permissions Which Will be checked in this file ...

// 3: Admin Activity Log Will Be Implimented here

//////////////////////////////////////////////////////////////////////////////////////////////////////

	include_once('../conn.php'); // Admin Access control Done Here. 
	
	include_once('../functions.php');
	
	function out($url,$msg = '',$err = ''){
	
		if($msg !=''){
	
			if(strpos($url,'?')){$out = '&msg='.$msg;}
	
			else{$out = '?msg='.$msg;}
	
		}
	
		if($err != ''){
	
			if(strpos($url,'?')){$out = '&err='.$err;}
	
			else{$out = '?err='.$err;}
	
			}
	
		
	
		header("Location: ".$url.$out);exit;
	
		}
		
	function stripmessage($ref){
		
		$refmsg = explode('&msg=',$ref);
	
		if(count($refmsg) > 1) $cleanref = $refmsg[0];
		else{
			$refmsg = explode('?msg=',$ref);
			
			if(count($refmsg) > 1){$cleanref = $refmsg[0];}
			
		}
	
		$refmsg = explode('&err=',$ref);
		//die(var_dump($refmsg));
		if(count($refmsg) > 1) $cleanref .= $refmsg[0];
		else{$refmsg = explode('?err=',$ref);if(count($refmsg) > 1){$cleanref .= $refmsg[0];}}
		
		if($cleanref !=''){$ref = $cleanref;}
		
		return $ref;
	}
	
	
	// Check for Post

	if(!isset($_POST['act'])){header("Location: ".$_SERVER['HTTP_REFERER']);exit;/*Fail silently*/}
	
	$act = $_POST['act'];
	
	$type = $_GET['type'];
	
	$ref = $_SERVER['HTTP_REFERER'];

	// Strip message from referrer ///////////////////////////////
	
	$ref = stripmessage($ref);
	
	////////////////////////////////////////////////////////////
	if($type == 'member'){
		// Member Modifications
	
		if($act == 'status')   {
	
			//die('here');
	
			if(isset($_POST['active']) && $_POST['id'] > 1){
	
				
	
				$sql = "UPDATE tblusers SET nActive = '" . $dbo->format($_POST['active']) . "' where nUser_ID = '" . $dbo->format($_POST['id'])."' LIMIT 1";
	
				$dbo->update($sql);
	
				// Admin Log - Log Action ...
	
			
	
				// Lets Clear The Action from the qs
	
				$ref = str_replace('?act=status','',$ref);
	
				$ref = str_replace('&act=status','',$ref);
	
				// Set MSg and Go Back
	
				$status = 'Deactivated';
				if($_POST['active'] == 1){$status = 'Activated';}
	
				$msg = 'Member '.$status.' Successfully';
	
				
	
				//header("Location: ".$ref.$msg);exit;
				out($ref,$msg);
	
				
	
				}
	
			else{
	
				// Lets Clear The Action from the qs
	
				$ref = str_replace('?type=member','',$ref);
	
				$ref = str_replace('&type=member','',$ref);
	
				out($ref,$msg);}
	
		}
	
		if($act == 'edit')     {
	
			if($_POST['id'] <= 0){
	
				$msg = "ERROR: No Member Id Posted.";
	
				out($ref,'',$msg);
	
			}
	
			$c=0;
	
			unset($_SESSION['errors']);
	
	
	
			if (trim($_POST["sForename"]) == "")
	
			{
	
			$c++;
	
			$_SESSION['errors']['nm']=1;
	
		}
	
	
	
			if (trim($_POST["sSurname"]) == "")
	
			{
	
			$c++;
	
			$_SESSION['errors']['ln']=1;
	
		}
	
	
	
			if(trim($_POST["sEmail"]) == "")
	
			{
	
			$c++;
	
			$_SESSION['errors']['em']=1;
	
		}
	
	
	
			if (!isValidEmail($_POST["sEmail"]) && $_POST["sEmail"] != "")
	
			{
	
			$c++;
	
			$_SESSION['errors']['em']=2;
	
		}
		
	
	
	
			if (!isValidEmail($_POST["sPaypalEmail"]) && $_POST["sPaypalEmail"] != "")
	
			{
	
			$c++;
	
			$_SESSION['errors']['pem']=1;
	
		}
	
	
	
			if (trim($_POST["sPassword"]) == "" )
	
			{
	
			$c++;
	
			$_SESSION['errors']['pwd']=1;
	
		}
	
		
	
	
	
		// If no errors from validation, update user's record
	
		if ($c == 0){	
	
			// Email Chainging
			// If the email changed we need to do an affiliate commission check.
			// affiliate commissions are still tracked by email, as of 3.0.9
			
			$curemail = $dbo->getval("SELECT sEmail FROM tblusers WHERE nUser_ID = '".$_POST['id']."';");
			
			if($currentemail != $_POST["sEmail"]){
				
				// Email Has Changed!
				// Ok the user changed their email address.
				// Affiliate payments are linked to the email address as of version 3.0
				// Lets Check For Affiliate Payments.
						
				$sql = "SELECT sUserEmail FROM tblaffiliatepayments WHERE sUserEmail = '$currentEmail';";
						
				if($dbo->num_rows($sql)){
							
					// We Have Affiliate Payments With The Old Email.
					// Lets Update Them.
							
					$sql = "UPDATE tblaffiliatepayments SET sUserEmail = '{$dbo->format($_POST['sEmail'])}' WHERE sUserEmail = '$currentEmail';";
					$dbo->update($sql);
				}
			}
			
			
			
			$sql = "UPDATE tblusers SET 
	
			sforename='" . $dbo->format($_POST["sForename"]) . "', 
	
			ssurname='" . $dbo->format($_POST["sSurname"]) . "', 
	
			saddr1='" . $dbo->format($_POST["sAddr1"]) . "', 
	
			saddr2='" . $dbo->format($_POST["sAddr2"]) . "', 
	
			saddr3='" . $dbo->format($_POST["sAddr3"]) . "', 
	
			stown='" . $dbo->format($_POST["sTown"]) . "', 
	
			scounty='" . $dbo->format($_POST["sCounty"]) . "', 
	
			scountry='" . $dbo->format($_POST["sCountry"]) . "', 
	
			spostcode='" . $dbo->format($_POST["sPostcode"]) . "',  
	
			semail='" . $dbo->format($_POST["sEmail"]) . "', 
	
			stelephone='" . $dbo->format($_POST["sTelephone"]) . "', 
	
			smobile='" . $dbo->format($_POST["sMobile"]) . "', 
	
			spassword='" . $dbo->format($_POST["sPassword"]) . "', 
	
			nadmin='" . $dbo->format($_POST["nAdmin"]) . "', 
	
			spaypalemail='" . $dbo->format($_POST["sPaypalEmail"]) . "', 
	
			naffiliate='" . $dbo->format($_POST["nAffiliate"]) . "', 
	
			naffiliate_id='" . $dbo->format($_POST["nAffiliate_ID"]) . "', 
	
			ncustomcommission='" . $dbo->format($_POST["nCustomCommission"]) . "',
	
			scomments='" . $dbo->format($_POST["sComments"]) . "',
	
			sCustomField1='" . $dbo->format($_POST["sCustomField1"]) . "',
	
			sCustomField2='" . $dbo->format($_POST["sCustomField2"]) . "',
	
			sCustomField3='" . $dbo->format($_POST["sCustomField3"]) . "',
	
			sCustomField4='" . $dbo->format($_POST["sCustomField4"]) . "',
	
			sCustomField5='" . $dbo->format($_POST["sCustomField5"]) . "',
	
			sCustomField6='" . $dbo->format($_POST["sCustomField6"]) . "',
	
			sCustomField7='" . $dbo->format($_POST["sCustomField7"]) . "',
	
			sCustomField8='" . $dbo->format($_POST["sCustomField8"]) . "',
	
			sCustomField9='" . $dbo->format($_POST["sCustomField9"]) . "',
	
			sCustomField10='" . $dbo->format($_POST["sCustomField10"]) . "'
	
			WHERE nuser_id=" . $_POST['id'];
	
			$dbo->update($sql);
	
	
	
			$msg = "Member details updated successfully";
	
			if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
			else{$msg = '?msg='.$msg;}
	
			header("Location: ".$ref.$msg);exit;
	
				
	
		}
	
		else{
	
			// We Got Errors, Error codes stored in $_SESSION['errors'];<br />
	
			// Post data for Submitted form to repopulate on error.
	
			foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
	
			$msg = "Please Correct The $c Errors Below.";
	
			out($ref,'',$msg);
	
			}
	
		}
	
		if($act == 'modlevel') {
	
			
	
			if (isset($_POST['Level']) && $_POST['Level'] == 'Add') {
	
				$modUser = get_user_by_id($_POST['id']);
	
				// Add level
	
				if (isset($_POST['nLevel_ID']) && is_numeric($_POST['nLevel_ID'])) {
	
					// First check if this user has already been added to this level
	
					//die('all good');
	
					$sql = "SELECT 1 FROM tbluserlevels WHERE nLevel_ID=" . $dbo->format($_POST['nLevel_ID']) . " AND nUser_ID=" . $dbo->format($_POST['id']);
	
					$result = $dbo->getval($sql);
	
					if ($result !== false) {
	
				// User already assigned, so update the nActive column
	
				$sql = "UPDATE tbluserlevels SET nActive=1, nDateExpires=" . date('Ymd', strtotime($dbo->format($_POST['nDateExpires']))) . ", nDateActive=".date(Ymd)." WHERE nLevel_ID=" . $dbo->format($_POST['nLevel_ID']) . " AND nUser_ID=" . $dbo->format($_POST['id']);
	
				$dbo->update($sql);
	
			} 
	
					else {
	
				// Add level
	
				$sql = "INSERT INTO tbluserlevels (nLevel_ID, nUser_ID, nDateExpires, nDateActive) VALUES (" . $dbo->format($_POST['nLevel_ID']) . ", " . $dbo->format($_POST['id']) . "," . date('Ymd', strtotime($dbo->format($_POST['nDateExpires']))) . ", ".date(Ymd).")";
	
				$dbo->insert($sql);
	
			}
	
					$msg = "Member level added successfully";
	
					if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
					else{$msg = '?msg='.$msg;}
	
					$modUser->nLevel_ID = $_POST['nLevel_ID'];
	
					pluginClass::action("user_AddLevel",$modUser);
	
					header("Location: ".$ref.$msg);exit;
	
					
	
		}
	
				else{header("Location: $ref");exit;}
	
			}
	
			elseif (isset($_POST['Level']) && $_POST['Level'] == 'Deactivate') {
	
				// Delete level (deactivate)
	
				$modUser = get_user_by_id($_POST['id']);
	
				if (isset($_POST['nAssignedLevel_ID']) && is_numeric($_POST['nAssignedLevel_ID'])) {
	
				//die('a');
	
				$sql = "UPDATE tbluserlevels SET nActive=0 WHERE nUserLevel_ID=" . $dbo->format($_POST['nAssignedLevel_ID']) . " AND nUser_ID=" . $dbo->format($_POST['id']).";";
				//die($sql);
				$dbo->update($sql);
				
				// get the membership level to send to plugins ...
				
				$sql = "SELECT nLevel_ID from tbluserlevels WHERE nUserLevel_ID = '{$dbo->format($_POST['nAssignedLevel_ID'])}'";
				
				$modUser->nLevel_ID = $dbo->getval($sql);
				
				pluginClass::action("user_CancelLevel",$modUser);
	
				$msg = "Member level deleted successfully";
	
				if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
				else{$msg = '?msg='.$msg;}
	
				header("Location: ".$ref.$msg);exit;
	
			}
	
				else{die('b');header("Location: $ref");exit;}
	
			}
			
			elseif(isset($_POST['Level']) && $_POST['Level'] == 'Reactivate'){
				$uiDate = $dbo->format($_POST['nExpires']);
				//if($chkSsettings->nDateFormat == 1 || $chkSsettings->nDateFormat == 3){$dbDate = preg_replace("/(\d+)\D+(\d+)\D+(\d+)/","$2$3$1",$uiDate);}
				//else{$dbDate = preg_replace("/(\d+)\D+(\d+)\D+(\d+)/","$3$2$1",$uiDate);}
				
				$dbDate = fStoreDate($chkSsettings->nDateFormat,$_POST['nExpires']);
				//$dbDate = date("Ymd", strtotime($uiDate));
				$sql = "UPDATE tbluserlevels SET `nDateExpires` = '$dbDate',`nActive` = '1' WHERE `nUserLevel_ID` = {$_POST['nAssignedLevel_ID']}";
				
				$dbo->update($sql);
				
				$sql = "SELECT nLevel_ID from tbluserlevels WHERE nUserLevel_ID = '{$_POST['nAssignedLevel_ID']}' ";
				
				
				$modUser = get_user_by_id($_POST['id']);
				$modUser->nLevel_ID = $dbo->getval($sql);
				
				pluginClass::action("user_AddLevel",$modUser);
				
				
				$msg = 'Level Reactivated Successfully';
				out($ref,$msg);
				}
				
			elseif(isset($_POST['Level']) && $_POST['Level'] == 'Edit'){
				//die(var_dump($_POST));
				
				
				
				$uiDate = $dbo->format($_POST['nExpires']);
				$payplan = $_POST['Plan'];
				$paycount = $_POST['Count'];
				$txn = $_POST['Txn'];
				$coupon = $_POST['Coupon'];
				$lid = $_POST['level_id'];
				
				$startdate = fStoreDate($chkSsettings->nDateFormat,$_POST['DateActive']);
				$expiredate = fStoreDate($chkSsettings->nDateFormat,$_POST['DateExpires']);
				
				
				$sql = "UPDATE tbluserlevels SET nPaymentPlan_ID = '$payplan', nPaymentCounter = '$paycount', nDateActive = '$startdate', nDateExpires = '$expiredate', ";
				
				$sql .= ($txn == '')?"sTransactionNumber = NULL, ":"sTransactionNumber = '$txn', ";
				
				$sql .=($coupon == '0')?"nCoupon_ID = NULL ":"nCoupon_ID = '$coupon' ";
				
				$sql .= "WHERE nUserLevel_ID = $lid";
				
				//die($sql);
				
				if(!$dbo->update($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
				else{$msg = urlencode('User Membership Access Updated Successfully.');out($ref,$msg);}
				
				}
				
			elseif (isset($_POST['Level']) && $_POST['Level'] == 'Delete') {
	
				// Delete level
				
				// get the membership level to send to plugins ...
				$sql = "SELECT tblusers.*, tbluserlevels.nLevel_ID from tbluserlevels
				INNER JOIN tblusers ON tbluser.nUser_ID = tbluserlevels.nUser_ID WHERE WHERE nUserLevel_ID = '".$dbo->format($_POST['nAssignedLevel_ID'])."'";
				
				$modUser = $dbo->getobject($sql);
				
				//$sql = "SELECT nLevel_ID from tbluserlevels WHERE nUserLevel_ID = '".$dbo->format($_POST['nAssignedLevel_ID'])."'";
				
				//$modUser->nLevel_ID = ($dbo->getval($sql))?$dbo->getval($sql):0;
				
				
				$sql = "DELETE FROM tbluserlevels WHERE nUserLevel_ID=" . $dbo->format($_POST['nAssignedLevel_ID']) . ";";
				
				$dbo->delete($sql);
				
				pluginClass::action("user_DeleteLevel",$modUser);
	
				$msg = "Member level deleted successfully";
	
				if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
				else{$msg = '?msg='.$msg;}
	
				header("Location: ".$ref.$msg);exit;
	
			}
	
			else{header("Location: $ref");exit;}
	
		}
	
		if($act == 'delete')   {
	
			if($_POST['id'] && $_POST['id'] > 1){
				delete_user($_POST['id']);
	
	
			// Set MSg and Go Back
	
			$msg = 'Member Deleted Successfully';
			out($ref,$msg);
	
				}
	
		}
		
		if($act == 'updateProfile'){
			$c=0;
			unset($_SESSION['profile']['errors']);
			unset($_SESSION['form']);
			// Check Fields
			if (trim($_POST["sForename"]) == ""){
	
			$c++;
	
			$_SESSION['profile']['errors']['nm']=1;
	
		}
			if (trim($_POST["sSurname"]) == ""){
	
			$c++;
	
			$_SESSION['profile']['errors']['ln']=1;
	
		}
			if(trim($_POST["sEmail"]) == ""){
	
			$c++;
	
			$_SESSION['profile']['errors']['em']=1;
	
		}
			if (!isValidEmail($_POST["sEmail"]) && $_POST["sEmail"] != ""){
	
			$c++;
	
			$_SESSION['profile']['errors']['em']=2;
	
		}
		
			// Password Change Check
			if(trim($_POST["sConfirmPass"]) && trim($_POST["sConfirmPass"])!=''){
				// We Have A Password Change, Lets Validate
				if(trim($_POST["sPassword"]) != trim($_POST["sConfirmPass"])){
					// Passwords Do Not Match .. Error out
					$c++;
					$_SESSION['profile']['errors']['pw']=1;
					}
				}
		
			// If no errors from validation, update user's record
	
		if ($c == 0){	
	
			$sql = "UPDATE tblusers SET 
	
			sForename='" . $dbo->format($_POST["sForename"]) . "', 
	
			sSurname='" . $dbo->format($_POST["sSurname"]) . "', 
	
			sAddr1='" . $dbo->format($_POST["sAddr1"]) . "', 
	
			sAddr2='" . $dbo->format($_POST["sAddr2"]) . "', 
	
			sTown='" . $dbo->format($_POST["sTown"]) . "', 
	
			sCounty='" . $dbo->format($_POST["sCounty"]) . "', 
	
			sCountry='" . $dbo->format($_POST["sCountry"]) . "', 
	
			sPostcode='" . $dbo->format($_POST["sPostcode"]) . "',  
	
			sEmail='" . $dbo->format($_POST["sEmail"]) . "', 
	
			sTelephone='" . $dbo->format($_POST["sTelephone"]) . "', 
	
			sMobile='" . $dbo->format($_POST["sMobile"]) . "', 
	
			sPassword='" . $dbo->format($_POST["sPassword"]) . "'
	
			WHERE nuser_id=" . $_POST['id'];
	//die($sql);
			
			
			if($dbo->update($sql)){$msg = "Member details updated successfully";out($ref,$msg);}
			else{out($ref,'','There Was An Error Updating The Member Record! Details Below<br />'.$dbo->error);}
	
	
	
			
	
			if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
			else{$msg = '?msg='.$msg;}
	
			header("Location: ".$ref.$msg);exit;
	
				
	
		}
	
		else{
	
			// We Got Errors, Error codes stored in $_SESSION['errors'];<br />
	
			// Post data for Submitted form to repopulate on error.
	
			foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
	
			$msg = "Please Correct The $c Errors Below.";
	
			out($ref,'',$msg);
	
			}
			}
			
		if($act == 'updateAccount'){
			$c=0;
			//die(var_dump($_POST));
			unset($_SESSION['profile']['errors']);
			unset($_SESSION['form']);
			// Check Fields
			
			// If no errors from validation, update user's record
			
			// Build Join Date String
			$joindate = fStoreDate($chkSsettings->nDateFormat,$_POST['nJoinDate']);
			
			////
			
			
	
		if ($c == 0){	
	
			$sql = "UPDATE tblusers SET 
	
			nAdmin='" . $dbo->format($_POST["nAdmin"]) . "', 
	
			nActive='" . $dbo->format($_POST["nActive"]) . "', 
	
			nJoinDate='" . $joindate . "', 
	
			nUnsubscribe='" . $dbo->format($_POST["nUnsubscribe"]) . "', 
	
			nConfirmed='" . $dbo->format($_POST["nConfirmed"]) . "' 
	
			WHERE nuser_id=" . $dbo->format($_POST['id']);
	//die($sql);
			
			
			if($dbo->update($sql)){
				
				// Email Confirm System
				$curr = $_POST['currentconfirm'];
				$new = $_POST["nConfirmed"];
			
				/////
				// If Not Confirmed and Admin Confirm Is Requested
				if($curr == '0' && $new == '1'){
					
					// Lets Check For An Existing Confirm Code.
					$sql = "SELECT * FROM tbluserconfirm WHERE nUser_ID = $objUser->nUser_ID AND nConfirmStatus = '0'";
					$res = $dbo->select($sql);
					
					if($dbo->nr($res)){
								
						$row = $dbo->getobj($res);
						
						$dbo->update("
						UPDATE `tbluserconfirm` 
						SET `sConfirmIp` = '".$_SERVER['REMOTE_ADDR']."',
						`nConfirmStatus` = '1',
						`nConfirmMethod` = '3' 
						WHERE `nConfirm_ID` = '$row->nConfirm_ID';");
						
						
					}
					else{
								// Add The Confirm Entry
								$sql = "
								INSERT INTO `tbluserconfirm` (
								`nConfirm_ID` ,
								`nUser_ID` ,
								`nAffiliate` ,
								`nPaymentPlan_ID` ,
								`nSignupTime` ,
								`sSignupIp` ,
								`nConfirmTime` ,
								`sConfirmIp` ,
								`nConfirmStatus` ,
								`nConfirmMethod`
								)
								VALUES (
								NULL , '".$dbo->format($_POST['id'])."', '0', '0', '".time()."', '".$_SERVER['REMOTE_ADDR']."', '".time()."', '".$_SERVER['REMOTE_ADDR']."', '1', '3'
								);";
								
								$dbo->insert($sql);
							}
					
					
					
				}
				
				$msg = "Account details updated successfully";out($ref,$msg);
				
				
				}
			else{out($ref,'','There Was An Error Updating The Member Record! Details Below<br />'.$dbo->error);}
	
	
	
			
	
			if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
			else{$msg = '?msg='.$msg;}
	
			header("Location: ".$ref.$msg);exit;
	
				
	
		}
	
		else{
	
			// We Got Errors, Error codes stored in $_SESSION['errors'];<br />
	
			// Post data for Submitted form to repopulate on error.
	
			foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
	
			$msg = "Please Correct The $c Errors Below.";
	
			out($ref,'',$msg);
	
			}
			}
		
		if($act == 'updateComments'){
			$sql = "UPDATE tblusers SET sComments = '{$dbo->format($_POST['sComments'])}' WHERE nUser_ID = {$_POST['id']}";
			if($dbo->update($sql)){
				out($ref,'Member Comment Added Successfully!');
				}
			else{out($ref,'','There Was An Error Saving Your Comment! Details Below<br />'.$dbo->error);}
			
			}
			
		if($act == 'updateAffiliate'){
			
			$c=0;
			unset($_SESSION['affiliate']['errors']);
			unset($_SESSION['form']);
			// Check Fields
			if (!isValidEmail ( $_POST["sPaypalEmail"]) && $_POST["sPaypalEmail"] != ""){
	
			$c++;
	
			$_SESSION['affiliate']['errors']['pem']=2;
	
		}
		
			
			// If no errors from validation, update user's record
	
		if ($c == 0){	
	//die('here');
			$sql = "UPDATE tblusers SET 
	
			nAffiliate_ID='" . $dbo->format($_POST["nAffiliate_ID"]) . "', 
	
			nAffiliate='" . $dbo->format($_POST["nAffiliate"]) . "', 
	
			sPaypalEmail='" . $dbo->format($_POST["sPaypalEmail"]) . "', 
	
			nCustomCommission='" . $dbo->format($_POST["nCustomCommission"]) . "'
	
			WHERE nuser_id=" . $_POST['id'];
	//die($sql);
			$dbo->update($sql);
	
	
	
			$msg = "Affiliate Details Updated Successfully";
			out($ref,$msg);
		}
	
		else{
	
			// We Got Errors, Error codes stored in $_SESSION['errors'];<br />
	
			// Post data for Submitted form to repopulate on error.
	
			foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
	
			$msg = "Please Correct The $c Errors Below.";
	
			out($ref,'',$msg);
	
			}
			}
			
		if($act == 'updateCustom'){
			// No Error Checking Needed
			
		$sql = "UPDATE tblusers SET 
			sCustomField1='" . $dbo->format($_POST["sCustomField1"]) . "',
	
			sCustomField2='" . $dbo->format($_POST["sCustomField2"]) . "',
	
			sCustomField3='" . $dbo->format($_POST["sCustomField3"]) . "',
	
			sCustomField4='" . $dbo->format($_POST["sCustomField4"]) . "',
	
			sCustomField5='" . $dbo->format($_POST["sCustomField5"]) . "',
	
			sCustomField6='" . $dbo->format($_POST["sCustomField6"]) . "',
	
			sCustomField7='" . $dbo->format($_POST["sCustomField7"]) . "',
	
			sCustomField8='" . $dbo->format($_POST["sCustomField8"]) . "',
	
			sCustomField9='" . $dbo->format($_POST["sCustomField9"]) . "',
	
			sCustomField10='" . $dbo->format($_POST["sCustomField10"]) . "'
	
			WHERE nuser_id=" . $_POST['id'];
			
			$dbo->update($sql);
			
			out($ref,'Custom Fields Updated Successfully!');
			
			}
		
		if($act == 'doAdmin'){
			
			$ref = str_replace('?type=doAdmin','',$ref);
			$ref = str_replace('&type=doAdmin','',$ref);
			
			$user = $_POST['id'];
			$isadmin = $_POST['isadmin'];
			$sql = "UPDATE tblusers SET `nAdmin` = '".$dbo->format($isadmin)."' WHERE nUser_ID = '".$dbo->format($user)."';";
			if(!$dbo->update($sql)){out(urlencode($ref,'','SQL Error: '.$dbo->error));}
			else{out($ref,urlencode('Admin Status Updated Successfully.'));}
		}
		
		if($act == 'emailPref'){
			$user = $_POST['id'];
			$emailPref = $_POST['emailPref'];
			$sql = "UPDATE tblusers SET `nUnsubscribe` = '".$dbo->format($emailPref)."' WHERE nUser_ID = '".$dbo->format($user)."';";
			
			$ref = str_replace('?type=admin','',$ref);
			$ref = str_replace('&type=admin','',$ref);
			
			
			if(!$dbo->update($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
			else{$msg = urlencode('Email Preference Updated Successfully.');out($ref,$msg);}
			
			
			
		}
		
		if($act == 'addTransaction'){
			
			// Convert Date and Time to Timestamp for Storage
			// Separate Date and Time
			//die(var_dump($_POST));
			$datetime = explode(' ',$_POST['datetime']);
			$date = $datetime[0];
			$time = $datetime[1];
			unset($datetime);
			
			$cleandate = fMysqlTimestamp($chkSsettings->nDateFormat,$date);
			
			$timestamp = $cleandate.' '.$time;
			
			// User Id
			$uid = $_POST['id'];
			$type = $_POST['type'];
			$processor = $_POST['processor'];
			$amount = number_format($_POST['amount'], 2, '.', '');
			$txn = $_POST['transactionnumber'];
			
			
			$sql = 
			
			"INSERT INTO `tbltransactions` 
			(`nTransaction_ID`, `nTransactionType_ID`, `sProcessor`, `nSaleAmount`, `nCommissionAmount`, `dDateTime`, `sTransactionNumber`, `nUser_ID`)
			VALUES (NULL, '$type', '$processor', '$amount', '0.00', '$timestamp', '$txn', '$uid');";
			
			if(!$dbo->update($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
			else{$msg = urlencode('Transaction Added Successfully.');out($ref,$msg);}
			
			
			}
			
		if($act == 'sendEmail'){
			
			// get user data
			$id = $_POST['sendEmailToId'];
			
			$objUser = get_user_by_id($id);
			
			$to = $objUser->sEmail;
			$from_name = $_POST['from_name'];
			$from_email = $_POST['from_email'];
			$subject = $_POST['subject'];
			$message = $_POST['email_message'];
			$contentType = $_POST['emailType'];
			
			//die(var_dump($_POST));
			//die('email('.$to.', '.$from_name.', '.$from_email.', '.$subject.', '.$message.', '.$contentType.')');
			$success = @email($to, $from_name, $from_email, $subject, $message, $contentType);
			
			if(!$success){out($ref,'','Failed to send email');}
			else{
				
				// Log The Email In The Users Profile ...
				$objUser->id = $objUser->nUser_ID;
				$objEmail = new stdClass;
				$objEmail->subject = $subject;
				$objEmail->body = $message;
				$objEmail->bodyHtml = $message;
				
				logSystemEmail($objUser,$objEmail);
				
				
				$msg = urlencode('Email Sent Successfully to '.$to);
				out($ref,$msg);
			}
			
		}
		
		if($act == 'processManualSale'){
			
			$sCurrencySymbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
			//die(var_dump($_POST));
			$datetime = $_POST['datetime'];
			
			$timestamp = strtotime($datetime);
			
			$mysqlFormattedDateTime = date("Y-m-d H:i:s", $timestamp);
			
			$userId = $_POST['id'];
			$planId = $_POST['paymentPlan'];
			$transId = $_POST['transactionnumber'];
			$objUser = get_user_by_id( $userId );
			
			if(!$objUser){die('No User Found!');}
			$objPaymentPlan = get_payment_plan_by_id($planId);
			if(!$objPaymentPlan){die('Payment Plan Not Found');}
			
			$data['transid'] = $transId;
			$data['userid'] = $userId;
			$data['affid'] = $objUser->nAffiliate_ID;
			$data['fee'] = $post_mc_fee;
			
			// Is This for a One Time Payment Plan Or Recurring ...
			if($objPaymentPlan->nOneTimePayment == '1' || $objPaymentPlan->nTrial1Period == 0){
				// This is a one time payment ...
				$data['amount'] = $objPaymentPlan->nRegularAmount;
				
				// Figure The Expure Date
				$nPeriod = $objPaymentPlan->nRegularPeriod;
				$sPeriod = $objPaymentPlan->sRegularPeriod;
			}
			else{
				$data['amount'] = $objPaymentPlan->nTrialAmount1;
				
				// Figure The Expure Date
				$nPeriod = $objPaymentPlan->nTrial1Period;
				$sPeriod = $objPaymentPlan->sTrial1Period;
			}
			
			// Get Processor Name
			$processor = $dbo->getval("SELECT sProcessorName FROM tblpaymentprocessors WHERE nPaymentProcessor_ID = '".
			$objPaymentPlan->nPaymentProcessor_ID."';");
			
			$data['payout'] = $nCommission = getAffiliateCommission($data['amount'], $objUser->nAffiliate_ID); // Calculate affiliate commission amount
			
			// Add Signup
			$levelId = add_new_signup($objUser,$objPaymentPlan, $data['transid'], ((intval($data['amount']) > 0)?true:false));
			$newTransId = add_transaction($data, 1, $processor);
			
			if($nCommission) 
				$newCommissionId = addAffiliatesPayments($objUser->nAffiliate_ID, $objUser, $nCommission, 
				get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID), $sCurrencySymbol, $nTransaction_ID);
			
			// Get the new level id
			$sql = "SELECT nUserLevel_ID FROM tbluserlevels WHERE nUser_ID = '$userId' AND sTransactionNumber = '$transId' LIMIT 1;";
			$level = $dbo->getobject($sql);
			
			// Refigure the Expire Dates
			$newExpire = ($nPeriod == '0')?'20380101':date('Ymd', strtotime('+' . $nPeriod . ' ' . $sPeriod,$timestamp));
			$newActive = date('Ymd', $timestamp);
			error_log('setting expire');
			error_log("timestamp: $timestamp nPeriod: $nPeriod, sPeriod: $sPeriod new Expire: $newExpire  New Active: $newActive");
			
			// We will need to reset all dates and times as functions above are all coded with time()
			$sql = "UPDATE tbluserlevels SET nDateExpires = '$newExpire', nDateActive = '$newActive' WHERE nUserLevel_ID = '".$level->nUserLevel_ID."';";
			$dbo->update($sql);
			
			if($newTransId)
				$sql = $dbo->update("UPDATE tbltransactions SET dDateTime = '".$mysqlFormattedDateTime."' WHERE nTransaction_ID = '".$newTransId."';");
			
			if($newCommissionId)
				$dbo->update("UPDATE tblaffiliatepayments SET nDate = '".$newActive."' WHERE nAffiliatePayment_ID = '".$newCommissionId."';");
			
			$msg = 'Sale Processed Successfully';
			out($ref,$msg);
		}
		
		if($act == 'addPaymentByLevel'){
			// This is used to process payments for membership levels that are set
			// for recurring payments, or one time payments for levels which expire.
			//die(var_dump($_POST));
			$sCurrencySymbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
			$userId = $_POST['userId'];
			$planId = $_POST['planId'];
			$userLevelId = $_POST['userLevelId'];
			$newTransNumber = $_POST["payment_transactionnumber"];
			
			// Get User
			$objUser = get_user_by_id($userId);
			
			// get Payment Plan
			$objPaymentPlan = get_payment_plan_by_id($planId);
			// Get The User Level
			$objUserLevel = $dbo->getobject("SELECT * FROM tbluserlevels WHERE nUserLevel_ID = $userLevelId;");
			
			// Build The data Array
			
			$data['userid'] = $userId;
			$data['affid'] = $objUser->nAffiliate_ID;
			$data['fee'] = $post_mc_fee;
			
			// Get Processor Name
			$processor = $dbo->getval("SELECT sProcessorName FROM tblpaymentprocessors WHERE nPaymentProcessor_ID = '".
			$objPaymentPlan->nPaymentProcessor_ID."';");
			
			$data['payout'] = $nCommission = getAffiliateCommission($data['amount'], $objUser->nAffiliate_ID); // Calculate affiliate commission amount
			//die(var_dump($objUserLevel));
			//#########################################
			// ## Expiration Variables ################
			//#########################################
			$datetime = $_POST['payment_datetime'];
			$timestamp = strtotime($datetime);
			$mysqlFormattedDateTime = date("Y-m-d H:i:s", $timestamp);
				
			$currentExpireStamp = getTimeStampFromYYYY($objUserLevel->nDateExpires);
			// Build Expire Date From Sale Date
			$saleDateExpire = date('Ymd', strtotime('+' . $objPaymentPlan->nRegularPeriod . ' ' . $objPaymentPlan->sRegularPeriod,$timestamp));
			
			// Build Expire Date From Current Expire Date
			$currentExpireExpire = date('Ymd', strtotime('+' . $objPaymentPlan->nRegularPeriod . ' ' . $objPaymentPlan->sRegularPeriod,$currentExpireStamp));
			
			// Lets Build The New Expire Date ...
			
			$postSetExpire = $_POST['setExpire'];
			
			if($postSetExpire == 'greater'){
				// Use The Highest Expire Date
				$setExpire = ($currentExpireExpire > $saleDateExpire)?$currentExpireExpire:$saleDateExpire;
			}
			elseif($postSetExpire == 'lesser'){
				// Use The Lowest Expire Date
				$setExpire = ($currentExpireExpire < $saleDateExpire)?$currentExpireExpire:$saleDateExpire;
			}
			elseif($postSetExpire == 'payment') {
				// Use The Sale Date
				$setExpire = $saleDateExpire;
			}
			else{
				// Use The Expire Date
				$setExpire = $currentExpireExpire;
			}
			
			#################################################
			
			// If transaction number is blank, use the old one.
			$data['transnumber'] = ($newTransNumber!='')?$newTransNumber:$objUserLevel->sTransactionNumber;
			
			
					
				// Use The Highest Expire Date
				//$setExpire = ($currentExpireExpire > $saleDateExpire)?$currentExpireExpire:$saleDateExpire;
				//die(var_dump($objPaymentPlan->nOneTimePayment));
				// Manually Recurring Or Automatic(subscription)
				
				if($objPaymentPlan->nOneTimePayment == '1'){
					// This is a one time payment plan, with expiration
					
					// Add Amount To Transaction
					$data['amount'] = $objPaymentPlan->nRegularAmount;
					
					// Calculate affiliate commission amount
					$data['payout'] = $nCommission = getAffiliateCommission($data['amount'], $objUser->nAffiliate_ID); 
			
					// Add Transaction
					$newTransId = add_transaction($data, 1, $processor);
					
					// Add Commission
					if($nCommission) 
						$newCommissionId = addAffiliatesPayments($objUser->nAffiliate_ID, $objUser, $nCommission,
						get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID), $sCurrencySymbol, $nTransaction_ID);
					
					// Extend Expiration Date For Current Level and increase payment counter
					// We Need A Transaction Number History Here, or tag transactions with something
					
					// We are changing the transaction number to the new one.
					// This needs more work!
					
					$sql = "UPDATE tbluserlevels SET 
					nDateExpires = '$setExpire', 
					nPaymentCounter = nPaymentCounter + 1,
					sTransactionNumber = '".$data['transnumber']."'  
					WHERE nUserLevel_ID = '".$objUserLevel->nUserLevel_ID."';";
					
					$dbo->update($sql);
					
					if($newTransId)
						$sql = $dbo->update("UPDATE tbltransactions 
						SET dDateTime = '".$mysqlFormattedDateTime."' 
						WHERE nTransaction_ID = '".$newTransId."';");
					
					if($newCommissionId)
						$dbo->update("UPDATE tblaffiliatepayments SET nDate = '".$newActive."' WHERE nAffiliatePayment_ID = '".$newCommissionId."';");
					
					$msg = 'Payment Processed Successfully';
					
				}
				else{
					// This is an automatic recurring payment plan
					// This is here in case ipn fails ...
					
					// We Assume Added Payment is Next Scheduled Payment.
					// Lets see if it is a trial payment
					
					if($objUserLevel->nPaymentCounter == '0'){
						// This must have been a free trial.
						// We need to add the next payment ...
						
						// Only Paypal Has 2 Trial Periods
						// Check if this has a second trial price.
						if($processor == 'Paypal' && $objPaymentPlan->nTrial2Period !='0'){
							
								// This has a second trial period
								// Set the Price and The Expiration Period.
								$transAmount = $objPaymentPlan->nTrialAmount2;
								$nExpirePeriod = $objPaymentPlan->nTrial2Period;
								$sExpirePeriod = $objPaymentPlan->sTrial2Period;
								
							
						}
						else{
							// This is a regular scheduled payment.
							// Set the Price and The Expiration Period.
							$transAmount = $objPaymentPlan->nRegularAmount;
							$nExpirePeriod = $objPaymentPlan->nRegularPeriod;
							$sExpirePeriod = $objPaymentPlan->sRegularPeriod;
						}	
					}
					else{
						// Set the Price and The Expiration Period.
						$transAmount = $objPaymentPlan->nRegularAmount;
						$nExpirePeriod = $objPaymentPlan->nRegularPeriod;
						$sExpirePeriod = $objPaymentPlan->sRegularPeriod;	
					}
					
					$data['amount'] = $transAmount;
					
					
					// Add Transaction
					$newTransId = add_transaction($data, 1, $processor);
					
					// Add Commission
					if($nCommission) 
						$newCommissionId = addAffiliatesPayments($objUser->nAffiliate_ID, $objUser, $nCommission, 
						get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID), $sCurrencySymbol, $nTransaction_ID);
			
					// Update Member Level
					add_level($objUser, $objPaymentPlan, $objUserLevel->sTransactionNumber, true);
					
					//$setExpire = date('Ymd', $timestamp);
			
					// We will need to reset all dates and times as functions above are all coded with time()
					$sql = "UPDATE tbluserlevels SET 
					nDateExpires = '$setExpire' 
					WHERE nUserLevel_ID = '".$objUserLevel->nUserLevel_ID."';";
					$dbo->update($sql);
			
					if($newTransId)
						$sql = $dbo->update("UPDATE tbltransactions 
						SET dDateTime = '".$mysqlFormattedDateTime."' 
						WHERE nTransaction_ID = '".$newTransId."';");
			
					if($newCommissionId)
						$dbo->update("UPDATE tblaffiliatepayments SET nDate = '".$newActive."' WHERE nAffiliatePayment_ID = '".$newCommissionId."';");
			
					$msg = 'Recurring Payment Processed Successfully';
					
				}
				
				if($objUserLevel->nActive == '0'){
				// This Account is Not Active
				// If Expire Has Increased Past Today, Reactiate.
				echo 'running not active checking...';
				
				if($setExpire > date('Ymd',time())){
					//die("UPDATE tbluserlevels SET nActive = '1' WHERE nUserLevel_ID = '".$objUserLevel->nUserLevel_ID."';");
					$res = $dbo->update("UPDATE tbluserlevels SET nActive = '1' WHERE nUserLevel_ID = '".$objUserLevel->nUserLevel_ID."';");
				}
				//else{die('expire is not greater than now');}
				
				
			}
				out($ref,$msg);	
			}	
		
		if($act == 'deactivateExpired'){
			//die(var_dump($_POST));
			$userLevelId = $_POST['userLevelId'];
			
			// Request To Deactivate An Expired level ...
			$sql = "UPDATE tbluserlevels SET nActive = '0' WHERE nUserLevel_ID = '$userLevelId'";
			$dbo->update($sql);
			out($ref,'User Level Deactivated Successfully.');
		}	
		
		if($act == 'changeExpiredDate'){
			//die(var_dump($_POST));
			$userLevelId = $_POST['userLevelId'];
			$newDate = fStoreDate($chkSsettings->nDateFormat,$_POST['newExpire']);
			//die($newDate);
			// Request To Deactivate An Expired level ...
			$sql = "UPDATE tbluserlevels SET nDateExpires = '$newDate' WHERE nUserLevel_ID = '$userLevelId'";
			//die($sql);
			$dbo->update($sql);
			out($ref,'User Level Expiration Changed Successfully.');
		}	
		
	}

	if($type == 'page'){
	
		// Page Modifications
	
		if($act == 'add'){
	
			// Error Check Than Add New Page To Database
			// Initialise the error count.
	
			$c = 0;
	
	
	
			if ($_POST['vpname'] == '') {
	
			$c++;
	
			$_SESSION['errors']['vpn'] = 1;
	
		}
			else{$lgthvp = strlen($_POST['vpname']);
	
			if ($lgthvp > 35) {
	
			$c++;
	
			$_SESSION['errors']['lgvpn'] = 1;
	
		}
		
		}
	
			$page_name = $_POST['pname'];
	
			// Checks for white space and removes anything after a .
	
			// Prob need to check for any special characters
	
			$page_name = str_replace(' ', '', $page_name);
	
			$page_name_pieces = explode('.', $page_name);
	
			$page_name = strtolower($page_name_pieces[0]);
	
	
	
			if ($page_name == '') {
	
			$c++;
	
			$_SESSION['errors']['pn'] = 1;
	
		}
	
			else{
	
				$lgth = strlen($page_name);
	
			if ($lgth > 50) {
	
			$c++;
	
			$_SESSION['errors']['lg'] = 1;
	
		}
	
			if (does_page_exist($page_name)) {
	
			$c++;
	
			$_SESSION['errors']['al'] = 1;
	
		}
	
		}
	
			
			
			
			// Check Page Level Access
			if(usePageLevels($_POST['did'])){
				
				if(!$_POST['pageLevel'] or empty($_POST['pageLevel'])){
	
				$c++;
	
				$_SESSION['errors']['pl'] = 1;
	
				
	
					}
				
			}
			
			// Run Validation Hook.
			pluginClass::action("page_new_formvalidate");
	
			// Error Checked If No Errors Go, Else Handle errors
	
	
	
		if ($c == 0) {
	
			
			
			$sContent = $_POST['inpContent'];
	
			$sContent = preg_replace('/^\s*<\?xml .*\?>\s*\r?\n/', '', $sContent);
	
			$sContent = $dbo->format($sContent, 'no_tag_strip');
			
			$sContent = html_entity_decode($sContent,ENT_NOQUOTES,'UTF-8');
	
	
	
			// cre = readonly flag for sFileName (0=readonly, 1=updateable)
	
			$page_name = $dbo->format($page_name);
	
			if (is_array($_POST['sType'])) {$sType = implode(',', $_POST['sType']);}
	
	
	
			$nAccessDays = (isset($_POST['naccessdays'])) ? $dbo->format($_POST['naccessdays']) : 0;
	
			$nDynamicPage = (isset($_POST['nDynamicPage'])) ? 1 : 0;
	
			$nConfEmail = (isset($_POST['nconfemail'])) ? $_POST['nconfemail'] : 0;
	
			$sConfEmailContent = $_POST['sconfemailcontent'];
	
			
	
			// added ability for page to be unavailable for members that join after certain date
	
			if (($_POST['nUnavailableForJoinedAfter_checkbox'] == 1) and ($_POST['nUnavailableForJoinedAfter_year'] !="") and ($_POST['nUnavailableForJoinedAfter_month'] != "")) {
	
				$nUnavailableForJoinedAfter_year = $dbo->format($_POST['nUnavailableForJoinedAfter_year']);
	
				$nUnavailableForJoinedAfter_month = $dbo->format($_POST['nUnavailableForJoinedAfter_month']);
	
				$nUnavailableForJoinedAfter = "'" . $nUnavailableForJoinedAfter_year . "-" . $nUnavailableForJoinedAfter_month ."-01'";
	
			} else {$nUnavailableForJoinedAfter = "NULL";}
	
			// Set formatting for html content
	
			if(!get_magic_quotes_gpc()){$sConfEmailContent = addslashes($sConfEmailContent);}
	
			
	
			if($_POST['fbcomments'] == '1'){$sContent .="[[FACEBOOK_COMMENTS]]";}
	
			else{$sContent = str_replace('[[FACEBOOK_COMMENTS]]','',$sContent);$_POST['fbcomments'] = 0;}
	
			
	
			// Lets get the last sort number and add new page to the end
	
			$sql = "SELECT MAX(nSortOrder) FROM `tblpages` WHERE nDirectory_ID = '".$dbo->format($_POST['did'])."'";
	
			$max = $dbo->getval($sql);
	
			$paper = $max;
	
			$nextsort = $paper+1;
	
			///////////////////////////////////////////////////////////////////
	
			$sql = "INSERT INTO `tblpages` (`nPage_ID` ,`sPageName` ,`sFileName` ,`nDirectory_ID` ,`nDisplay` ,`nSortOrder` ,
	
	`cre` ,`sContent` ,`nAccessDays` ,`nConfEmail` ,`sConfEmailContent` ,`nDynamicPage` ,`nUnavailableForJoinedAfter` ,`nFacebookComments`)
	
	VALUES (
	
	NULL , '" . $dbo->format($_POST['vpname']) . "', '" . $page_name . "', '" . $dbo->format($_POST['did']) . "', '".$dbo->format($_POST['nDisplay'])."', '$nextsort', '1', '" . $sContent . "', '" . $dbo->format($nAccessDays) . "', '" . $dbo->format($nConfEmail) . "', '" . $sConfEmailContent . "' , '" . $dbo->format($nDynamicPage) . "', $nUnavailableForJoinedAfter , '".$dbo->format($_POST['fbcomments'])."');
	
	";
	
	$PAGEID = $dbo->insert($sql);
	
	
	
	// Below is a wasted query, as we already hve the page id value, by using mysql insert id ... duh? v2.4
	
	// $findPage = $dbo->getrow("SELECT * FROM tblpages ORDER BY nPage_ID DESC LIMIT 1");
	
	// It is also flawed as it pulls the last page created and adds them to the page level dataabse even if the records already existed.<br>
	
	// This happens if the NEW page fails to create. Using mysql_insert_id is ideal!!!
	
	if($PAGEID){
		// Get The Page Object For Hook
		$objPage = $dbo->getobject("SELECT * FROM tblpages WHERE nPage_ID = '$PAGEID'");
		pluginClass::action("page_new_Success",$objPage);
		foreach ($_POST['pageLevel'] as $k => $v) {
	
	
	
	$dbo->insert("INSERT into tblpagelevels VALUES('','" . $PAGEID . "','" .$dbo->format($v) . "')");
	
	//echo "INSERT into tblpagelevels VALUES('','" . $MEMBERID . "','" .$dbo->format($v) . "')";
	
	}
	
		}
	
	out('page_management.php?did='.$dbo->format($_POST['did']),'Page '.$dbo->format($_POST['vpname']) .' Created Successfully.');
	
		}
	
		else{
	
			// We Got Errors, Error codes stored in $_SESSION['errors'];<br />
	
			// Post data for Submitted form to repopulate on error.
	
			foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
	
			$msg = "Please Correct The $c Errors Below.";
	
			}
	
		out($ref,'',$msg);	
	
		}
	
		if($act == 'edit'){
	
		// Check Directory Actions
	
		if (!empty($_POST['directoryaction'])) {
	
			if ($_POST['directoryaction'] == 'copy') {
	
				// Create new page
	
				// cre = readonly flag for sFileName (0=readonly, 1=updateable)
	
				$sql = sprintf("INSERT INTO tblpages(sPageName, sPageTitle, sFileName, nDirectory_ID, cre, sContent, nConfEmail, sConfEmailContent )
	
										VALUES ('%s', '%s', '%s', '%s', 1, '%s') ", $dbo->format($_POST['sPageName']),
	
					$dbo->format($_POST['sPageTitle']), $dbo->format($_POST['sFileName']), $dbo->
	
					format($_POST['directorynew']), $dbo->format($_POST['txtContent']),
	
					'no_tag_strip', $dbo->format($_POST['nconfemail']), $_POST['sConfEmailContent']);
	
	
	
				$dbo->insert($sql);
	
			}
			elseif ($_POST['directoryaction'] == 'move') {
	
				$sql = sprintf("UPDATE tblpages SET nDirectory_ID = '%s' WHERE nPage_ID = '%s' ",
	
					$dbo->format($_POST['directorynew']), $dbo->format($_POST['dd']));
	
				$dbo->update($sql);
				
				// If moving a member page to the main folder, we need to remove page level restrictions ....
				if($_POST['directorynew'] == '0'){
					$sql = "DELETE * FROM `tblpagelevels` WHERE `nPage_ID` = '{$dbo->format($_POST['dd'])}';";
					die($sql);
					$dbo->delete($sql);
				}
	
			}
	
		}
	
		$error_count = 0;
	
		// Check length of file name entered
	
		if ($_POST['sPageName'] == '') {
	
			$error_count++;
	
			$_SESSION['errors']['vpn'] = 1;
	
		}
	
		else{
	
			$lgthvp = strlen($_POST['sPageName']);
	
	
	
		if ($lgthvp > 255) {
	
			$error_count++;
	
			$_SESSION['errors']['lgvpn'] = 1;
	
		}
	
	
	
			}
	
	
	
		// Check if page name has been entered
	
		if ($_POST['sFileName'] == '') {
	
			$error_count++;
	
			$_SESSION['errors']['pn'] = 1;
	
		}
	
		else{ 
	
		// Check length of page name
	
		$lgth = strlen($_POST['sFileName']);
	
	
	
		if ($lgth > 255) {
	
			$error_count++;
	
			$_SESSION['errors']['lg'] = 1;
	
		}
	
		// Check if Page Name Change, If So 
		// Check if New Name Already Exists
		$query = "SELECT sFileName FROM tblpages WHERE nPage_ID = {$_POST['id']}";
		$curname = $dbo->getval($query);
		
		if($curname != $_POST['sFileName']){
			if (does_page_exist($_POST['sFileName'],$_POST['id'])) {
	
			$error_count++;
	
			$_SESSION['errors']['al'] = 1;
	
		}
			}
	
	
		 }
		
	
		// Check if at least one level has been selected. System Pages Are Ignored.
	
		//$parent = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '".$_POST['did']."' ");
		
		if(usePageLevels($_POST['did']) && $_POST['cre'] != 0 && empty($_POST['pageLevel'])){
	
			$error_count++;
	
			$_SESSION['errors']['ar'] = 1;
	
			}
	
			pluginClass::action("page_edit_formvalidate");
	
		if ($error_count == 0) {
	
			// Remove spaces from page name
	
			$sremove = str_replace(' ', '', $_POST['sFileName']);
	
			$pieces = explode(".", $sremove);
	
	
	
			// Get filename and not file extension
	
			$sFileName = strtolower($pieces[0]);
	
			/*$sContent = preg_replace('/^\s*<\?xml .*\?>\s*\r?\n/', '', $sContent);
	
			$sContent = $dbo->format($sContent, 'no_tag_strip');
			// Docode HTML entities - v3
			//$sContent = html_entity_decode($sContent,ENT_NOQUOTES,'UTF-8'); Bugged - Shows Bad Characters
			$sContent = htmlspecialchars_decode($sContent); // Fix For Above
			*/
			$sContent = storeHtmlToDb($_POST['txtContent']);
	
	
			// Update page details in database
	
			$nAccessDays = (isset($_POST['naccessdays'])) ? $dbo->format($_POST['naccessdays']) : 0;
	
			$nDynamicPage = (isset($_POST['nDynamicPage'])) ? 1 : 0;
	
			$nConfEmail = (isset($_POST['nconfemail'])) ? 1 : 0;
	
			$sConfEmailContent = $_POST['sconfemailcontent'];
	
			 // Set formatting for html content
	
			if(!get_magic_quotes_gpc()){$sConfEmailContent = addslashes($sConfEmailContent);}
	
			//==== added ability for page to be unavailable for members that join after certain date=======
	
			if (($_POST['nUnavailableForJoinedAfter_checkbox'] == 1) and ($_POST['nUnavailableForJoinedAfter_year'] !=
	
				"") and ($_POST['nUnavailableForJoinedAfter_month'] != "")) {
	
				$nUnavailableForJoinedAfter_year = $dbo->format($_POST['nUnavailableForJoinedAfter_year']);
	
				$nUnavailableForJoinedAfter_month = $dbo->format($_POST['nUnavailableForJoinedAfter_month']);
	
				$nUnavailableForJoinedAfter = "'" . $nUnavailableForJoinedAfter_year . "-" . $nUnavailableForJoinedAfter_month .
	
					"-01'";
	
			} else {
	
				$nUnavailableForJoinedAfter = "NULL";
	
			}
	
			//==== ========== ============= ============ =========== ============= ======================
	
	
	
	
	
			$sFileName = $dbo->format($sFileName);
	
			if($_POST['fbcomments'] == '1'){$sContent .="[[FACEBOOK_COMMENTS]]";}
	
			else{$sContent = str_replace('[[FACEBOOK_COMMENTS]]','',$sContent);}
	
			$sql = "UPDATE tblpages SET 
	
				sPageName = '" . $dbo->format($_POST['sPageName']) . "',
	
				sFileName = '" . $sFileName . "', 
				
				nDisplay = '" . $dbo->format($_POST['nDisplay']) . "', 
	
				sContent = '" . $sContent . "',
	
				nConfEmail = '" . $nConfEmail . "',
	
				sConfEmailContent = '" . $sConfEmailContent . "',
	
				nAccessDays = " . $nAccessDays . ",
	
				nDynamicPage = " . $nDynamicPage . ",
	
				nUnavailableForJoinedAfter = $nUnavailableForJoinedAfter,
	
				nFacebookComments = '".$_POST['fbcomments']."'
	
				WHERE nPage_ID = " . $dbo->format($_POST['id']) . ";";
	
				
	
				//die($sql);
	
	
	
			if(!$dbo->update($sql)){}
			else{
				
				$objPage = $dbo->getobject("SELECT * FROM tblpages WHERE nPage_ID = " . $dbo->format($_POST['id']) . ";");
				pluginClass::action("page_edit_Success",$objPage);
				
			}
	
	
	
			// Update level access only for pages not in a MAIN folder (or sub MAIN folder).... eg ANY NON-MAIN FOLDER/SUB FOLDER PAGES!!
	
			$sql = "SELECT nDirectory_ID, nLevel_ID, nParent_ID FROM tbldirectories WHERE nDirectory_ID=" .$dbo->format($_POST['did']);
	
			$objDirectory = $dbo->getobject($sql);
	
	
	
			// Refresh level access for this page
	
			if ($_POST["did"] != 0 && $objDirectory->nParent_ID != 0) {
	
				//die(var_dump($_POST['pageLevel']));
	
				$dbo->delete("DELETE FROM tblpagelevels WHERE nPage_ID='" . $dbo->format($_POST['id']) ."'");
				if(is_array($_POST['pageLevel'])){foreach ($_POST['pageLevel'] as $k => $v) {
	
					$sql = "INSERT INTO tblpagelevels VALUES('','" . $dbo->format($_POST['id']) ."','" . $dbo->format($v) . "')";
	
					$dbo->insert($sql);
	
				}}
	
			}
	
	
	
			$msg = "Post Updated Successfully!";
	
			out($ref,$msg);
	
			
	
	
	
		}
	
		else{
	
			
	
			// We Got Errors, Error codes stored in $_SESSION['errors'];<br />
	
			// Post data for Submitted form to repopulate on error.
			
			
			foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
	
			$msg = "Please Correct The $error_count Errors Below.";
	
			//die(var_dump($_SESSION['errors']));
	
			out($ref,'',$msg);
			
	
			}
	
		}
	
		if($act == 'status') {
	
			//die(var_dump($_POST));
	
			// UPDATE PAGE DISPLAY
	
			if (isset($_POST['status'])) {
	
				$sql = "UPDATE tblpages SET ndisplay='" . $dbo->format($_POST['status']) . "' WHERE npage_id = '" .$dbo->format($_POST['statusPageId'])."'";
	
				$dbo->update($sql);
	
				header("Location: $ref");exit;}
	
			}
	
		if($act == 'sortrebuild'){
	
			// This is a feature to rebuild the sort field system if sort fields contain duplicate values.<br />
	
			// This is caused by Old version sorting syste, deleting pages, or moving pages between dir.
	
			// TO DO - Rebuild Sort System To Make Sorting Mods When Deleting pages, and moving pages.
	
			$sql = "SELECT nPage_ID, nSortOrder FROM tblpages WHERE nDirectory_ID = '".$_POST['sortrebuilddid']."' ORDER BY `nPage_ID` ASC;";
	
			$res = $dbo->select($sql);
	
			$nr = $dbo->nr($res);
	
			$i = 0;
	
			if($nr){
	
				while($row = $dbo->getobj($res)){
	
					$i++;
	
					$sql = "Update tblpages SET nSortOrder='$i' WHERE nPage_ID='".$row->nPage_ID."' ";
	
					$dbo->update($sql);
	
				}
	
				$msg = "Sort System has been reformatted successfully. Feel free to set your sorting preference.";
	
					if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
					else{$msg = '?msg='.$msg;}
	
					header("Location: ".$ref.$msg);exit;
	
			}
	
			else{header("Location: ".$ref);exit;}
	
		}
	
		if($act == 'resort') {
	
			
	
			order_page_rows($_POST['sortPageId'],$_POST['did'],$_POST['sort']);
	
			
	
			header("Location: $ref".$_POST['qs']);exit;
	
			}
	
		if($act == 'menu')   {
	
			$sql = "Update tblpages SET sNavBarLocation = '".$_POST['menu']."' WHERE nPage_ID = '".$_POST['menuPageId']."' ";
	
			$dbo->update($sql);
	
			header("Location: $ref");exit;
	
			}
	
		if($act == 'movefolder'){
	
			//Move a page to another folder
	
			// Lets make sure this isnt a system page
	
			//die(var_dump($_POST));
	
			$cre = $dbo->getval("SELECT cre FROM tblpages where nPage_ID = '".$_POST['movePageId']."';");
	
			if($cre == 1){
	
				// This is a user created file. Proceed.
				// Lets Add This Page To The END of the New Directory to Prevent Sort Issues...
	
				$sql = "SELECT MAX(nSortOrder) FROM `tblpages` WHERE nDirectory_ID = '".$dbo->format($_POST["ndid"])."'";
	
				$max = $dbo->getval($sql);
	
				$paper = $max;
	
				$nextsort = $paper+1;
	
				$sql = "UPDATE tblpages SET nDirectory_ID='" . $dbo->format($_POST["ndid"]) . "', nSortOrder = '$nextsort' WHERE nPage_ID='" . $dbo->format($_POST["movePageId"]) . "'";
	
				$dbo->update($sql);
	
				//die($sql);
				
				// If moving a member page to the main folder, we need to remove page level restrictions ....
				if($_POST["ndid"] == '0'){
					$sql = "DELETE FROM `tblpagelevels` WHERE `nPage_ID` = '{$dbo->format($_POST['movePageId'])}';";
					//die($sql);
					$dbo->delete($sql);
				}
	
				header("Location: $ref");exit;
	
			}
	
		}
	
		if($act == 'delete') {
	
			if($_POST['delPageId'] && $_POST['delPageId'] !=0){
	
				//die('here');
	
				// Lets get some data
	
				$sql = "SELECT cre,nDirectory_ID,nSortOrder FROM tblpages WHERE nPage_ID = ".$dbo->format($_POST['delPageId'])."";
	
				$page = $dbo->getobject($sql);
	
				// Lets make sure this is not a system page
	
				if($page->cre == 1){
	
					// Delete The Page
					$sql = "DELETE FROM tblpages WHERE nPage_ID = ".$dbo->format($_POST['delPageId'])."";
					$dbo->delete($sql);
					
					// Delete The Page Rights For Deleted Page.
					$sql = "DELETE FROM tblpagelevels WHERE nPage_ID = ".$dbo->format($_POST['delPageId'])."";
					$dbo->delete($sql);
					///
	
					// The Function Below Slides All the Pages sorted after the deleted page 1 spot to compensate for the deleted page.<br />
	
					// Ex. If deleted page was listed 6th, than the 7th page becomes the 6th, 8 into 7 ect ...
	
					reorder_pages_onDelete($_POST['delPageId'],$page->nDirectory_ID,$page->nSortOrder);
	
					// Set MSg and Go Back
	
					$msg = 'Post Deleted Successfully';
	
					$ref = $_SERVER['HTTP_REFERER'];
	
					if(strpos($ref,'?')){$msg = '&msg='.$msg;}
	
					else{$msg = '?msg='.$msg;}
	
					header("Location: ".$ref.$msg);exit;
	
					}
	
				else{header("Location: $ref");exit;}
	
				}
	
			else{header("Location: $ref");exit;}
	
			}
			
	}

if($type == 'db'){

	// Database Modifications

	if($act == 'backup'){

		function getTableList() {

		global $dbo;	

		$rs = $dbo->select("SHOW TABLES");

		while ($row = $dbo->getarray($rs,'NUM')) 

			$aList[] = $row[0];	

			return $aList;

	}

		//die(var_dump($_POST));

		// Check if folder is writeable

		if (is_writable('dump')) {

			$aTables = getTableList();

			foreach($_POST as $k=>$v){

				if($v != '1'){unset($_POST[$k]);}

				}		

			$aExclude = array_diff($aTables, array_keys($_POST));

			// --ignore-table=db_name.tbl_name

			$tableignore = '';

			foreach ($aExclude as $item) {$tableignore .= " --ignore-table=".$db_name.".".$item;}

	

			$backupFile = 'dump/' . date('Y_m_d').'_'.time()."_db.gz";// Time Added To File Name To Protect From Unauthorized Downloads by guessing file name.

			$command = "mysqldump --opt -u $db_username --password='$db_password' $tableignore  $db_name  | gzip > $backupFile";

			exec($command, $result);

			if (is_file(dirname(__FILE__) . '/' . $backupFile)) {

				$message = "Database tables backed up successfully.";

				header("Location: $ref?msg=$message");exit;

			}

			else {$message = "Unable to create backup file.";header("Location: $ref?err=$message");exit;}

		} 

		else {$message = "Folder admin/dump is not writeable.";header("Location: $ref?err=$message");exit;}

		

	}

	if($act == 'optlist'){

		//die(var_dump($_POST));

		// Check if folder is writeable

		foreach($_POST as $k=>$v){if($v == '1'){$dbo->exec('OPTIMIZE TABLE ' . $k);}}

		header("Location: $ref?msg=Tables Optimized");exit;

	}

	if($act == 'clear'){

		//die(var_dump($_POST));

		if($_POST['table'] == 'tbladminlogins' || $_POST['table'] == 'tbluserlogins' || $_POST['table'] == 'tblcronlog' || $_POST['table'] == 'tblquerylog' || $_POST['table'] == 'tblipnlog'){

			

			$dbo->exec("TRUNCATE TABLE ".$_POST['table'].";") or die('fail');

			$msg = 'Table '.$_POST['table'].' Logs Have Been Cleared.';

			//die($ref);

			out($ref,$msg);

			

			}

		}}

if($type == 'folder'){

	// Folder (Category) Modifications

	}
	
if($type == 'transaction'){
	
	if($act == 'edit'){
		
		
		$transId = $_POST["trans_id"];
		$userId = $_POST["suggestionsmHidden"];
		$amount = $_POST["trans_amount"];
		$transType = $_POST["trans_type"];
		$processor = $_POST["processor"];
		$datetime = $_POST["trans_datetime"];
		$transNumber = $_POST ["Txn"];
		
		// Grab Current Details and Check for Changes
		$sql = "SELECT * FROM tbltransactions WHERE nTransaction_ID = '".$transId."';";
		$transaction = $dbo->getObject($sql);
		 //die($datetime); //2015-01-01 05:25
		$datetime = explode(' ',$datetime);
			$date = $datetime[0];
			$time = $datetime[1];
		//die($datetime);
		//$date = fMysqlTimestamp($chkSsettings->nDateFormat,$date);
		//die(var_dump($transaction));
		$datetime = $date.' '.$time;
		//die($datetime);
		if(!$transaction || empty($transaction)){die('transaction does not exist. Please Contact Support.');}
		
		// We have transaction. Find Changed Values.
		$changed = array();
		
		$sql = "UPDATE `tbltransactions` SET ";
		
		if($transaction->nTransactionType_ID != $transType){
			$changed['transType'] = "`nTransactionType_ID` = '".$transType."'";
		}
		if($transaction->sProcessor != $processor){
			$changed['processor'] = "`sProcessor` = '".$processor."'";
		}
		if($transaction->nSaleAmount != $amount){
			$changed['amount'] = "`nSaleAmount` = '".$amount."'";
		}
		/*if($transaction->nCommissionAmount != $affamount){
			$changed['affamount'] = "`nCommissionAmount` = '".$affamount."'";
		}*/
		if($transaction->dDateTime != $datetime){
			$changed['datetime'] = "`dDateTime` = '".$datetime."'";
		}
		if($transaction->sTransactionNumber != $transNumber){
			$changed['transNumber'] = "`sTransactionNumber` = '".$transNumber."'";
		}
		if($transaction->nUser_ID != $userId){
			$changed['userId'] = "`nUser_ID` = '".$userId."'";
		}
		
		$count = count($changed);
		//die(var_dump($count)); 
		if($count >0){
			
			foreach ($changed as $k=>$v) {
				
				$sqlUpdate .= $v.',';
				
			}
			
			$sqlUpdate = rtrim($sqlUpdate,',');
			
		}
		$sql .= $sqlUpdate;
		$sql .= " WHERE `tbltransactions`.`nTransaction_ID` ='".$transId."';";
		
		//die($sql);
		
		if(!$dbo->update($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
		else{$msg = urlencode('Transaction Edited Successfully.');out($ref,$msg);}
	}
	if($act == 'delete'){
		$id = $_POST['tx_id'];
		$sql = "DELETE FROM tbltransactions WHERE nTransaction_ID = $id LIMIT 1;";
		
		if(!$dbo->delete($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
		else{$msg = urlencode('Transaction Deleted Successfully.');out($ref,$msg);}
		
	}
	
	if($act == 'processRefundManually'){
		$data = array();
		$data['transid'] = $dbo->format($_POST['sTransactionNumber']);
		
		// get the data from the parent transaction
		$sql = "SELECT * FROM tbltransactions WHERE sTransactionNumber = '".$data['transid']."' AND nTransactionType_ID = '1' ";
		
		$objTransaction = $dbo->getobject($sql);
		
		if(!$objTransaction){die('Transaction not found');}
		
		// Build Data Array
		$data['email'] = $objTransaction->sUserEmail;
    	$data['firstname'] = $objTransaction->sUserForename;
    	$data['lastname'] = $objTransaction->sUserSurname;
    	$data['aff_email'] = $objTransaction->sAffEmail;
    	$data['aff_firstname'] = $objTransaction->sAffForename;
    	$data['aff_lastname'] = $objTransaction->sAffSurname;
    	$processor = $objTransaction->sProcessor;
    	$data['amount'] = $objTransaction->nSaleAmount;
    	$data['payout'] = $objTransaction->nCommissionAmount;
		$data['userid'] = $objTransaction->nUser_ID;
		
		// Add The Refund To The Database
		add_transaction($data, 2, 'Paypal');
		
		if(isset($_POST["removeCommission"]) && $_POST["removeCommission"] == '1'){
			// Remove The Affiliate Commission, If Applicable.
			set_affiliate_payment_by_transaction ($data['transid'], 'Refund');
		}
		if(isset($_POST ["cancelLevel"]) && $_POST ["cancelLevel"] == '1'){
			// This takes a txn/sub id , and is refund true or false
			cancel_level($data['transid'], true);
		}
		$msg = urlencode('Transaction Refunded Successfully.');out($ref,$msg);
	}
	
}
if($type == 'broadcast'){
	//die(var_dump($_POST));
	if($act == 'add'){
		
		$_POST['subject'] = stripslashes($_POST['subject']);
		$_POST['txtBody'] = stripslashes($_POST['txtBody']);
	/*
		// Get Members from Database
		$find = array(' ', ',');
		$repl = array('', "','");
		switch ($_POST['sType']) {
			case 'affiliate':
				$query = "SELECT * FROM tblusers  WHERE nActive=1  AND nUnsubscribe=0 AND nAffiliate = 1 ";
				break;
			case 'all':
				$query = "SELECT tblusers.* FROM (
	SELECT nUser_ID, MIN(nDateCancelled) AS nActive FROM tbluserlevels
	GROUP BY nUser_ID 
	) AS tmp1
	INNER JOIN tblusers ON tblusers.nUser_ID = tmp1.nUser_ID
	WHERE tmp1.nActive = 0 AND tblusers.nActive = 1 AND tblusers.nUnsubscribe=0";
				break;            
			case 'cancelled':
				$query = "SELECT tblusers.* FROM (
	SELECT nUser_ID, MIN(nDateCancelled) AS nActive FROM tbluserlevels
	GROUP BY nUser_ID 
	) AS tmp1
	INNER JOIN tblusers ON tblusers.nUser_ID = tmp1.nUser_ID
	WHERE tmp1.nActive != 0 AND tblusers.nActive = 1 AND tblusers.nUnsubscribe=0";
				break; 
		}
	
	
		//===========================added for sending email to one or many member levels
		foreach ($membershipLevelsArray as $membersipLevel) {
			if ($_POST['level_' . $membersipLevel[0]]) {
				if ($levelsQuery == "") {
					$levelsQuery = " nLevel_ID=" . $membersipLevel[0];
				} else {
					$levelsQuery .= " OR nLevel_ID=" . $membersipLevel[0];
				}
			}
		}
	
		if ($levelsQuery != "") {
			$query = "SELECT DISTINCT tblusers.nUser_ID, sForename, sSurname, sEmail, sPassword, nJoinDate FROM tblusers, tbluserlevels WHERE tblusers.nActive = 1  AND tblusers.nUnsubscribe='0' AND tblusers.nUser_ID=tbluserlevels.nUser_ID AND (	$levelsQuery )";
		}
		//============================================================================
	
		//$rs = $dbo->select($sql);
		*/
		
		// Get Stored Filter Query
		$query = get_option($_POST["filterName"]);
		$pieces = explode(' ',$_POST['scheduleDateTime']);
		$date = $pieces[0];
		$time = $pieces[1];
		$formatdate = fMysqlTimestamp($chkSsettings->nDateFormat,$date);
		$dateTimeString = $formatdate.' '.$time.'00';
		$scheduleTime = ($_POST['schedule'] == '1')?$dateTimeString:date('Y-m-d H:i:s');
		//die(var_dump($_POST['schedule'] == '1'));
		// Save The Broadcast Info
		$sql = "INSERT INTO `tblbroadcasts` 
		( `nAdmin_ID`, `sMemberQuery`, `sSubject`, `sBody`, `sBodyHtml`, `dCreatedTime`, `dScheduleTime`, `dSentTime`, `nStatus`) 
		VALUES
		('".$_SESSION['admin']['nUser_ID']."', 
		'".addslashes($query)."', 
		'".$dbo->format($_POST['subject'])."', 
		'".$dbo->format($_POST['txtBody'])."', 
		'".storeHtmlToDb($_POST["htmlBody"])."', 
		NOW(), 
		'".$scheduleTime."', 
		'0000-00-00 00:00:00', 0);";
		
		if(!$dbo->update($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
		else{$msg = urlencode('Broadcast Scheduled Successfully.');out($ref,$msg);}
	}
	if($act == 'edit'){
		// Lets Check To See If They Submitted a New Query
		if($_POST["queryType"] == 'filter') $newQuery = true;
		
		if($newQuery == true){
			
			$query = get_option($_POST['filterName']);
		}
		//die($query);
		$id = $dbo->format($_POST["nBroadcast_ID"]);
		$subject = $dbo->format($_POST["subject"]);
		$txt = $dbo->format($_POST["txtBody"]);
		$html = $_POST["htmlBody"];
		//die(var_dump($_POST["scheduleDateTime"]));
		$pieces = explode(' ',$_POST["scheduleDateTime"]);
		//die(var_dump($pieces));
		$mysqlDate = fMysqlTimestamp($chkSsettings->nDateFormat,$pieces[0]);
		$datetime = $mysqlDate.' '.$pieces[1];
		//$html = $_POST["title"];
		$datetime = ($_POST['schedule'] == '0')?'0000-00-00 00:00:00':$datetime;
		$sql = " UPDATE `tblbroadcasts` SET ";
		if($newQuery == true) $sql .= "`sMemberQuery` = '".addslashes($query)."',";
		$sql .="
		`sSubject` = '".$dbo->format($subject)."',
		`sBody` = '".$dbo->format($txt)."',
		`sBodyHtml` = '". storeHtmlToDb($html)."',
		`dScheduleTime` = '".$datetime."' 
		WHERE `nBroadcast_ID` = '".$id."' ;";
		//die($sql);
		if(!$dbo->update($sql)) out($ref,'',urlencode('SQL Error: '.$dbo->error));
		else $msg = urlencode('Broadcast Updated Successfully.');out($ref,$msg);
		
		
	}
	if($act == 'del'){
		
		$sql = "DELETE FROM tblbroadcasts WHERE nBroadcast_ID = '".$dbo->format($_POST['nBroadcast_ID'])."';";
		
		if(!$dbo->delete($sql)) out($ref,'',urlencode('SQL Error: '.$dbo->error));
		else $msg = urlencode('Broadcast Deleted Successfully.');out($ref,$msg);
	}
	if($act == 'restart'){
		$sql = "UPDATE tblbroadcasts SET nStatus = '-1' WHERE nStatus = '1';";
		$dbo->update($sql);
		remove_option('email_broadcasting');
		
		if(!$dbo->update($sql)){out($ref,'',urlencode('SQL Error: '.$dbo->error));}
		else{$msg = urlencode('Broadcast Restarted Successfully.');out($ref,$msg);}
		
	}
	if($act == 'unlock'){
		remove_option('email_broadcasting');
		$msg = urlencode('Broadcast Lock Removed Successfully.');out($ref,$msg);
	}
	
	
}
	if($type == 'emailTemplates'){
		
		if($act == 'addNew'){
			$c = 0;
			foreach ($_POST as $k=>$v) $_SESSION['emailAddTemplateForm'][$k] = $v;
			$errmsg = array();
			$title = $dbo->format($_POST["newTemplateTitle"]);
			$subject = $dbo->format($_POST["newTemplateSubject"]);
			$body = $dbo->format($_POST["newTemplateBody"]);
			$bodyhtml = $dbo->format($_POST["newTemplateBodyHtml"]);
			if (empty($title)){
				$c++;
				$et = 1;
			}
			if (empty($subject)){
				$c++;
				$es = 1;
			}
			if (empty($body)){
				$c++;
				$eb = 1;
			}
			if (empty($bodyhtml)){
				$c++;
				$ebh = 1;
			}
			
			if ($c == 0){
				$sql = "INSERT INTO `tblemailtemplates` 
				(`sSubject`, `sBody`, `sType`, `sTitle`, `sBodyHtml`) VALUES
('$subject', '$body', 'CUSTOM', '$title', '$bodyhtml');";
				
				$id = $dbo->insert($sql);
				if($id){
					unset($_SESSION['emailAddTemplateForm']);
					header("location:email_templates.php?msg=".urlencode('Email Template Added Successfully!')."&nEmail_ID=".$id);
				}
				else{header("location:email_templates.php?err=".urlencode($dbo->error));}
			}
			else{
				$str = '';
				$str .= ($et)?'&et=1':'';
				$str .= ($es)?'&es=1':'';
				$str .= ($eb)?'&eb=1':'';
				$str .= ($ebh)?'&ebh=1':'';
				header("Location: email_templates.php?err=".urlencode('There were errors with your template.')."&add=1".$str);
			}
			
			
			 
		}
		if($act == 'edit'){
			$c = 0;
			if (empty($_POST["sSubject"])){
				$c++;
				$es = 1;
			}
			if (empty($_POST["sBody"])){
				$c++;
				$eb = 1;
			}
			if (empty($_POST["sBodyHtml"])){
				$c++;
				$ebh = 1;
			}
			if ($c == 0){
				$sql = sprintf("UPDATE tblemailtemplates SET 
		sSubject='%s', sBody = '%s',sBodyHtml = '%s' WHERE nEmail_ID = '%s';", $dbo->format($_POST["sSubject"]), $dbo->format($_POST["sBody"]), $_POST["sBodyHtml"],$dbo->format($_POST["nEmail_ID"]) );
				$dbo->update($sql);
				header("location:email_templates.php?act=pcom&nEmail_ID=".$_POST["nEmail_ID"]);
			}
		}
		
		
	}
	
if($type == 'queryFilter'){
	//die(var_dump($_POST));
	if($act == 'saveFilter'){
		
		$filterConditions = array();
		$conditionAddedCount = 0;
		
		// Build Query
		
		// Select Fields
		$sql = "
		SELECT tblusers.*,
		tblaffiliates.sForename AS sAffForename,
		tblaffiliates.sSurname AS sAffSurname ";
		
		if(isset($_POST['login']) && $_POST['loginFilterCompare'] !='never'){
			$sql .=',MAX(tbluserlogins.nTimestamp) as lastLogin ';
		}
		
		// Joins
		$sql .="
		FROM tblusers 
		LEFT JOIN tblusers AS tblaffiliates ON tblusers.nAffiliate_ID = tblaffiliates.nUser_ID ";
		// Add Needed Inner Joins
		if(isset($_POST['level'])){
			// Add The Level Inner Join
			$sql .= 'INNER JOIN tbluserlevels ON tbluserlevels.nUser_ID = tblusers.nUser_ID ';
		}
		if(isset($_POST['login']) && $_POST['loginFilterCompare'] !='never'){
			$sql .= 'INNER JOIN tbluserlogins ON tbluserlogins.nUser_ID = tblusers.nUser_ID ';
		}
		
		// Where Clause
		$sql .= "WHERE ";
		// Level Filter
			// levelFilter Value (the level id)
			// Level Filter Compair
			if(isset($_POST['level'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tbluserlevels.nLevel_ID ".$_POST['levelFilterCompare']." ('".$_POST['levelFilterValue']."') ";
				$conditionAddedCount++;
			}
			if(isset($_POST['affiliate'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tblusers.nAffiliate = '".$_POST['affiliateFilterValue']."' ";
				$conditionAddedCount++;
			}
			if(isset($_POST['login'])){
				$date1 = $_POST['loginFilterValue'];
				$date2 = $_POST['loginFilterValue2'];
					
					$mdate1 = fMysqlTimestamp($chkSsettings->nDateFormat,$date1);
					$mdate2 = fMysqlTimestamp($chkSsettings->nDateFormat,$date2);
					
					$time1 = strtotime($mdate1);
					$time1a = $time1 + (60*60*24);
					$time2 = strtotime($mdate2);
					$time2a = $time2 + (60*60*24);
				
				if($conditionAddedCount > 0){$sql .=' AND ';}
				
				if($_POST['loginFilterCompare'] == '><'){
					
					$sql .= "tbluserlogins.nTimeStamp BETWEEN '$time1' AND '$time2a' ";
				}
				elseif($_POST['loginFilterCompare'] == 'never'){
					$sql .= "tblusers.nUser_ID NOT IN (SELECT nUser_ID FROM tbluserlogins) ";
				}
				elseif($_POST['loginFilterCompare'] == '>'){
					$sql .= "tbluserlogins.nTimeStamp '>' '".$time1a."' ";
				}
				elseif($_POST['loginFilterCompare'] == '<'){
					$sql .= "tbluserlogins.nTimeStamp '<' '".$time1."' ";
				}
				elseif($_POST['loginFilterCompare'] == '='){
					$sql .= "tbluserlogins.nTimeStamp BETWEEN '".$time1."' AND '".$time1a."' ";
				}
				else{}
				$conditionAddedCount++;
			}
			if(isset($_POST['emailStatus'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tblusers.nConfirmed = '".$_POST['emailStatusFilterValue']."' ";
				$conditionAddedCount++;
			}
			if(isset($_POST['optin'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tblusers.nUnsubscribed = '".$_POST['optinFilterValue']."' ";
				$conditionAddedCount++;
			}
			if(isset($_POST['join'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$date1 = $_POST['joinFilterValue'];
				$date2 = $_POST['joinFilterValue2'];
				
				$mdate1 = fStoreDate($chkSsettings->nDateFormat,$date1);
				$mdate2 = fStoreDate($chkSsettings->nDateFormat,$date2);
				
				if($_POST['joinFilterCompare'] == '><'){
					$sql .= "tblusers.nJoinDate BETWEEN '$mdate1' AND '$mdate2' ";
				}
				else{
					$sql .= "tblusers.nJoinDate ".$_POST['joinFilterCompare']." '$mdate1' ";
				}
				
				$conditionAddedCount++;
			}
			
			$sql .= "GROUP BY nUser_ID ";
			
			$newFilterName = $_POST['newFilterName'];
			
			//add_option('mqf_'.$newFilterName,$sql);
			
			if(!is_option('mqf_'.$newFilterName)){
				add_option('mqf_'.$newFilterName,$dbo->format($sql));
				$_SESSION['admin']['current_mqf_title'] = $newFilterName;
				$_SESSION['admin']['current_mqf_sql'] = $sql;
			}
			out($ref,'Query Filter Saved and is now active!');
	}
	if($act == 'loadFilter'){
		$filter = $_POST["loadFilter"];
		
		$query = get_option($filter);
		if($query){
			$_SESSION['admin']['current_mqf_title'] = $filter;
			$_SESSION['admin']['current_mqf_sql'] = $query;
			$message = 'Query Filter "'.str_replace('mqf_','',$filter).'" Loaded Successfully!';
			out($ref,$message);
		}
		else{$err = 'Failed To Load Query Filter "'.str_replace('mqf_','',$filter).'"';out($ref,'',$err);}
		
	}
	
}
	
pluginClass::action('admin_actions');



?>