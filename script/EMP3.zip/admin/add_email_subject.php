<?php
include_once ('../conn.php');
include_once ('../functions.php');


	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add Promo Email Subject';
	$css = <<<EOT
<!--page level css -->
<link href="css/pages/editor.css" rel="stylesheet" type="text/css"/>
<!--end of page level css-->
EOT;

if (isset ( $_POST['Submit'] )) {
	$c = 0;
	if ($_POST ["txtBody"] == '') {
		$c ++;
		$sb = 1;
	}
	if ($c == 0) {
		$sql = "INSERT INTO tblpromoemailsubject(sSubject, nPromoEmail_ID, nDisplay) VALUES ('" . $dbo->format ( $_POST["txtBody"] ) . "', " . $dbo->format($_POST['nPromoEmail_ID']) . ", 1)";
		if($dbo->insert($sql)){$qs = 'msg=Email subject line has been added successfully';}
		else{$qs = "There was an Error Saving your subject line.<br />{$dbo->error}";}
		header ( "location:email_subject.php?$qs" );
	}
}
require_once('header.php');
?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Affiliate System</a></li>
			<li><a href="email_subject.php">Promo Email Subjects</a></li>
			<li class="active"> Add Promo Email Subject</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form name="form1" id="form1" method="post" action="<?php echo $_SERVER ['PHP_SELF']; ?>"	>
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> Add Promotional Email Subject</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<?php 
			// First we need to check if there are any promo emails in the database
			// You can't add subject lines until some promo emails are entered first
			$sql = "SELECT nPromoEmail_ID, sTitle FROM tblpromoemails WHERE nActive = 1";
			$result = $dbo->select($sql);
			if ($result !== false) {
				$options = '';
				while ($objPromoEmail = $dbo->getobj($result)) {
					$options .= '<option value="' . $objPromoEmail->nPromoEmail_ID . '">' . $objPromoEmail->sTitle . '</option>';
				}
			?>
								<tr>
									<td>Promo email that this should belong to <span class="red">*</span></td>
									<td ><select name="nPromoEmail_ID" id="nPromoEmail_ID" class="required" style="width: 300px;">
											<option value="">Please choose</option>
											<?php echo $options ?>
										</select></td>
								</tr>
								<tr>
									<td >Subject <span class="red">*</span></td>
									<td ><input name="txtBody" type="text" value="" class="required" style="width: 300px;"></td>
								</tr>
								<?php } else { ?>
								<tr>
									<td  colspan="2"><b><span class="red">You must first enter some <a href="promotional_emails.php">Promo Emails</a> before you can insert Subject lines.</span></b></td>
								</tr>
								<?php } ?>
							</table>
						</div>
					</div>
					<input class="btn btn-primary btn-responsive" name="Submit" value="Submit" type="submit">
				</div>
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php require_once('footer.php'); ?>
<script type="text/javascript">
function cdel(w) {
	if(confirm("Delete Confirmation!..\n\n Are Sure that you want to delete this?.."))
	{
		return true;
	}
	else
	{
		return false;
	}
}	
	$(document).ready(function()
	{
		$("#form1").validate();
	});
	</script>
</body></html>