<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Upload New File';
	
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Content</li>
			<li><a href="file_management.php">Files</a></li>
			<li class="active">Upload New File</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Upload New File</h3>
				</div>
				<div class="panel-body">
					<table>
						<tr>
							<td>
							<!-- Start PlUpload Code / replaces fancy Upload -->
								
								<div id="uploader">
									<p>Your browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 suppor!WOW, Get a new browser.</p>
								</div>
								
								<!-- End PlUpload -->
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</section>
	</section>
	<!-- right-side --> 
</aside>
<?php require_once('footer.php'); ?>
<script type="text/javascript">
// Convert divs to queue widgets when the DOM is ready
$(function() {
	var filenames = new Array();
	$("#uploader").pluploadQueue({
		// General settings
		runtimes : 'gears,flash,silverlight,browserplus,html5',
		url : 'ajax/file_upload.php',
		max_file_size : '10000mb',
		chunk_size : '1mb',
		

		// Resize images on clientside if we can
		//resize : {width : 320, height : 240, quality : 90},

		// Specify what files to browse for
		filters : [
			{title : "All", extensions : "zip,pdf,jpg,jpeg,gif,bmp,png,html,htm,flv,mp4,mov"},
			{title : "Image", extensions : "jpg,jpeg,gif,png,bmp"},
			{title : "Document",extensions: "pdf,doc,docx,ppt,pptx,pps,ppsx"},
			{title : "Audio", extensions: "mp3,m4a,ogg,wav"},
			{title : "Video", extensions: "flv,mp4,m4v,mov,wmv,avi,mpg,ogv,3gp,3g2"},
			{title : "Compressed", extensions: "zip"}
			
		],

		// Flash settings
		flash_swf_url : '../includes/plupload/js/plupload.flash.swf',

		// Silverlight settings
		silverlight_xap_url : '../includes/plupload/js/plupload.silverlight.xap',
		
		// PreInit events, bound before any internal events
		preinit : {
		},

		// Post init events, bound after the internal events
		init : {
			FileUploaded: function(up, file, response) {
				// Called when a file has finished uploading
				var obj = jQuery.parseJSON(response.response);
				//console.log("my object: %o", obj);
				filenames.push(obj.name);
			},
			UploadComplete: function (up,file){
				var namestring = '';
				$.each(filenames,function(index,value){namestring +=('<br />'+value)});
				window.location.replace("file_management.php?msg=The Following File(s)Have Been Uploaded Successfully: "+namestring);
					},
			
			Error: function(up, args) {
				// Called when a error has occured
				//alert('[error] '+ args);
			}
		}
	});
});


</script>
<style>
#uploader{
	width:600px;
	}
</style>
<!-- Load Queue widget CSS and jQuery -->
<style type="text/css">
@import url(../includes/plupload/js/jquery.plupload.queue/css/jquery.plupload.queue.css);
</style>

<!-- Third party script for BrowserPlus runtime (Google Gears included in Gears runtime now) --> 
<script type="text/javascript" src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script> 

<!-- Load plupload and all it's runtimes and finally the jQuery queue widget --> 
<script type="text/javascript" src="../includes/plupload/js/plupload.full.js"></script> 
<script type="text/javascript" src="../includes/plupload/js/jquery.plupload.queue/jquery.plupload.queue.js"></script>
</body></html>