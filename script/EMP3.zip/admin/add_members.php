<?php 
	include_once('../conn.php');
	include_once('../functions.php');
	// RETRIEVE ADMIN INFO
	$objAdmin = $dbo->getobject("select * from tblusers where nUser_ID='". $_SESSION['admin']["nUser_ID"] . "'");
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add New Member';
	$css = <<<EOT
<!--page level css -->
<link href="vendors/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen" />
<!--end of page level css-->
EOT;

	if (isset($_GET['action']) && $_GET['action'] == 'add'){
	$c=0;

	if (trim($_POST["sForename"]) == "" )
	{
		$c++;
		$nm=1;
	}

	if (trim($_POST["sSurname"]) == "" )
	{
		$c++;
		$ln=1;
	}

	if(trim($_POST["sEmail"])=="")
	{
		$c++;
		$em=1;
	}

	if (!isValidEmail($_POST["sEmail"]) && $_POST["sEmail"]!="")
	{
		$c++;
		$em=2;
	}

	if (!isValidEmail($_POST["sPaypalEmail"]) && $_POST["sPaypalEmail"]!="")
	{
		$c++;
		$pem=2;
	}

	if (trim($_POST["sPassword"]) == "" )
	{
		$c++;
		$pwd=1;
	}
	if (trim($_POST["sPassword"]) != trim($_POST["sConfirmPass"]) )
	{
		$c++;
		$pwd=2;
	}

	if($c==0)
	{
		
		$today = date("Ymd");
		$time = date("g:i a"); 
		
		$sendConfirm = $_POST['sendConfirm'];
		
		$confirmstatus = ($sendConfirm == '0')?'1':'0';
		
		// insert user record
		$sql="INSERT INTO tblusers (sForename, sSurname, 
		sAddr1, 
		sAddr2, 
		sAddr3, 
		sTown, 
		sCounty, 
		sCountry, 
		sPostcode, 
		sEmail, 
		sTelephone, 
		sMobile, 
		nJoinDate, 
		sJoinTime, 
		sPassword, 
		nAffiliate,
		nAdmin, 
		nActive,
		nUnsubscribe, 
		sPaypalEmail, 
		nAffiliate_ID, 
		nCustomCommission,
		sComments,
		sCustomField1,
		sCustomField2,
		sCustomField3,
		sCustomField4,
		sCustomField5,
		sCustomField6,
		sCustomField7,
		sCustomField8,
		sCustomField9,
		sCustomField10,
		nConfirmed
		) VALUES (
		'" .$dbo->format($_POST["sForename"]) . "', 
		'" .$dbo->format($_POST["sSurname"]) . "', 
		'" .$dbo->format( $_POST["sAddr1"]) . "', 
		'" . $dbo->format($_POST["sAddr2"]) . "', 
		'" . $dbo->format($_POST["sAddr3"]) . "', 
		'" . $dbo->format($_POST["sTown"]) . "', 
		'" . $dbo->format($_POST["sCounty"]) . "', 
		'" . $dbo->format($_POST["sCountry"]) . "', 
		'" . $dbo->format($_POST["sPostcode"]) . "', 
		'" . $dbo->format($_POST["sEmail"]) . "', 
		'" . $dbo->format($_POST["sTelephone"]) . "', 
		'" . $dbo->format($_POST["sMobile"]) . "', 
		'$today', 
		'$time', 
		'" . $dbo->format($_POST["sPassword"]) . "', 
		'" . $dbo->format($_POST["nAffiliate"]) . "', 
		'" .$dbo->format( $_POST["nAdmin"]) . "', 
		'1',
		'".$dbo->format( $_POST["nUnsubscribe"])."', 
		'" . $dbo->format($_POST["sPaypalEmail"]) . "', 
		'" . $dbo->format($_POST["nAffiliate_ID"]) . "', 
		'" . $dbo->format($_POST["nCustomCommission"]) . "',
		'" . $dbo->format($_POST["sComments"]) . "',
		'" . $dbo->format($_POST["sCustomField1"]) . "',
		'" . $dbo->format($_POST["sCustomField2"]) . "',
		'" . $dbo->format($_POST["sCustomField3"]) . "',
		'" . $dbo->format($_POST["sCustomField4"]) . "',
		'" . $dbo->format($_POST["sCustomField5"]) . "',
		'" . $dbo->format($_POST["sCustomField6"]) . "',
		'" . $dbo->format($_POST["sCustomField7"]) . "',
		'" . $dbo->format($_POST["sCustomField8"]) . "',
		'" . $dbo->format($_POST["sCustomField9"]) . "',
		'" . $dbo->format($_POST["sCustomField10"]) . "',
		'".$confirmstatus."')
		";

		$nUser_ID = $dbo->insert($sql);
		if(!$nUser_ID){
			$msg = 'Error Adding Member:<br />'.$dbo->error;
			header("Location:add_members.php?err=$msg");exit;
			}
		
		// Get new user
		$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = $nUser_ID");
		
		pluginClass::action("user_Added",$objUser);
		
		if($sendConfirm == '1'){
			
			// Create A Verification Code and send to user.
			
			// Add The Confirm Entry
			$sql = "INSERT INTO `tbluserconfirm` 
			(`nConfirm_ID`, `nUser_ID`, `nAffiliate`, `nPaymentPlan_ID`, `nSignupTime`, `sSignupIp`) 
			VALUES (NULL, '$objUser->nUser_ID', '0', '0', '".time()."', '".$_SERVER['REMOTE_ADDR']."');";
						
			$confCode = md5($dbo->insert($sql));
			
			// Send It Out
			// It requires a global variable $nPaymentPlan_ID
			$nPaymentPlan_ID = '0';
						
			email_member_confirm($objUser,$confCode);
				
		}
		
		// Insert user level
		if (isset($_POST['nLevel_ID']) && is_numeric($_POST['nLevel_ID'])) {
			$sql = "INSERT INTO tbluserlevels (nUser_ID, nLevel_ID, nDateExpires, nDateActive) 
			VALUES ($nUser_ID,{$dbo->format($_POST['nLevel_ID'])},
			".fStoreDate($chkSsettings->nDateFormat,$dbo->format($_POST['nDateExpires'])).",
			 ".date(Ymd).")";
			$dbo->insert($sql);
			;
		}
		
		header("Location:manage_members.php?msg=User Added Successfully!");
	
	}
	else{$message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>Please Correct The Following '.$c.' Errors:</div>';}}
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> Add New Member </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Members</li>
			<li class="active">Add Members</li>
		</ol>
	</section>
	<section class="content"> <?php echo isset($message) ? $message : '' ?>
		<form name="f" id="f" method="post" action="add_members.php?action=add">
			<div class="col-md-12">
				<button type="submit" class="btn btn-primary">Add Member</button>
				&nbsp;
				<button type="button" class="btn btn-danger">Cancel</button>
				&nbsp; </div>
			<div class="col-lg-6">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> <i class="livicon" data-name="bell" data-loop="true" data-color="#fff" data-hovercolor="#fff" data-size="18"></i> Member Profile </h3>
						<span class="pull-right"> <i class="fa fa-fw fa-chevron-up clickable"></i> </span> </div>
					<div class="panel-body">
						<div class="form-group">
							<label class="control-label col-xs-3" for="firstName">First Name</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sForename" id="sForename" placeholder="First Name" value="<?php echo ($_SESSION['form']['sForename'])? $_SESSION['form']['sForename']: $objUser->sForename;?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3" for="lastName">Last Name</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" id="sSurname" name="sSurname" placeholder="Last Name" value="<?php echo ($_SESSION['form']['sSurname'])? $_SESSION['form']['sSurname']: $objUser->sSurname;?>" required>
							</div>
						</div>
						<div id="profileEdit" style="display:block">
							<div class="form-group">
								<label class="control-label col-xs-3" for="sEmail">Email</label>
								<div class="col-xs-9">
									<input type="email" id="sEmail" name="sEmail" class="form-control" placeholder="Email" value="<?php echo ($_SESSION['form']['sEmail'])? $_SESSION['form']['sEmail']: $objUser->sEmail;?>" required>
								</div>
							</div>
						</div>
						<!-- Multiple Radios -->
						<div class="form-group">
							<label class="col-xs-3 control-label" for="radios">Confirm Method</label>
							<div class="col-xs-9">
								<div class="radio">
									<label for="radios-0">
										<input id="sendConfirm_0" name="sendConfirm" value="0" checked="checked" type="radio">
										Admin Confirmed </label>
								</div>
								<div class="radio">
									<label for="radios-1">
										<input id="sendConfirm_1" name="sendConfirm" value="1" type="radio">
										Send Confirm Email </label>
								</div>
							</div>
						</div>
						<br />
						<!-- Passwords -->
						<div class="form-group">
							<label class="control-label col-xs-3" for="password"> Password </label>
							<div class="col-xs-9">
								<input type="password" class="form-control" name="sPassword" id="sPassword" placeholder="Password" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3" for="password"> Confirm Password </label>
							<div class="col-xs-9">
								<input type="password" class="form-control" name="sConfirmPass" id="sConfirmPass" placeholder="Password Again" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3">Address</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sAddr1" id="sAddr1" placeholder="Address" value="<?php echo ($_SESSION['form']['sAddr1'])? $_SESSION['form']['sAddr1']: $objUser->sAddr1;?>">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> Address 2</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sAddr2" id="sAddr2" placeholder="Address 2" value="<?php echo ($_SESSION['form']['sAddr2'])? $_SESSION['form']['sAddr2']: $objUser->sAddr2;?>" >
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> City</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sTown" id="sTown" placeholder="City" value="<?php echo ($_SESSION['form']['sTown'])? $_SESSION['form']['sTown']: $objUser->sTown;?>">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> State</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sCounty" id="sCounty" placeholder="State" value="<?php echo ($_SESSION['form']['sCounty'])? $_SESSION['form']['sCounty']: $objUser->sCounty;?>" >
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> Zipcode</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sPostcode" id="sPostcode" placeholder="Zipcode" value="<?php echo ($_SESSION['form']['sPostcode'])? $_SESSION['form']['sPostcode']: $objUser->sPostcode;?>" >
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> Country</label>
							<div class="col-xs-9">
								<?php
		if($_POST['country']=="")
		{
			$co7=$row->sCountry;
		}
		else
		{
			$co7=$_POST['country'];
		}
	
		$Selected = ($country) ? $country : (($_SESSION['form']['sCountry'])? $_SESSION['form']['sCountry']: $objUser->sCountry);
		//$CountryDropMenu = countrydm("sCountry",$Selected);
		//echo $CountryDropMenu;
		echo get_country_list('sCountry',$Selected,0);
		
		?>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> Telephone</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sTelephone" id="sTelephone" placeholder="Telephone" value="<?php echo ($_SESSION['form']['Telephone'])? $_SESSION['form']['sTelephone']: $objUser->sTelephone;?>"  />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-xs-3"> Mobile</label>
							<div class="col-xs-9">
								<input type="text" class="form-control" name="sMobile" id="sMobile" placeholder="Mobile Phone" value="<?php echo ($_SESSION['form']['Mobile'])? $_SESSION['form']['sMobile']: $objUser->sMobile;?>" >
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> <i class="livicon" data-name="doc-portrait" data-c="#fff" data-hc="#fff" data-size="18" data-loop="true"></i> Account Information </h3>
						<span class="pull-right"> <i class="fa fa-fw fa-chevron-up clickable"></i> </span> </div>
					<div class="panel-body">
						<div class="form-group">
							<label for="nAdmin" class="control-label"> Account Type </label>
							<select name="nAdmin" id="nAdmin" class="form-control select2">
								<option value="1" <?php echo ($objUser->nAdmin) ? 'selected' :''; ?>>Administrator</option>
								<option value="0" <?php echo (!$objUser->nAdmin) ? 'selected' :''; ?>>Customer</option>
							</select>
						</div>
						<div class="form-group">
							<label for="nJoinDate" class="control-label">Signup Date</label>
							<div class='input-group date'>
								<input name="nJoinDate" type="text" id="nJoinDate" class="col-sm-3 form-control" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd'));?>" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>" readonly="readonly"/>
								<span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span></div>
						</div>
						<div class="form-group">
							<label for="nAdmin" class="control-label"> Email Preference</label>
							<select name="nUnsubscribe" id="nUnsubscribe" class="form-control select2">
								<option value="0" <?php echo ($objUser->nUnsubscribe == '0') ? 'selected': '' ?>>Receive All</option>
								<option value="1" <?php echo ($objUser->nUnsubscribe == '1') ? 'selected': '' ?>>Receive None</option>
							</select>
						</div>
					</div>
					<!-- Hide This Box As Its Handled In The View Member Area Of The SIte -->
					<div class="memberInfoBox" style="display:none;">
						<div align="center"><strong>Membership Details</strong></div>
						<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
							<tr class="memberDataRow">
								<td width="123"><label for="nAdmin2">Membership Level</label></td>
								<td width="255"><span class="gridrow1">
									<select name="nLevel_ID" id="nLevel_ID" style="width:98%;">
										<option value="">Assign a level to this member</option>
										<?php 
				// Get all levels which user is not already assigned to
				$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels WHERE nActive=1 ORDER BY sLevel";
				$result = $dbo->select($sql);
				while ($objLevel = $dbo->getobj($result)) {
					echo '<option value="' . $objLevel->nLevel_ID . '">' . $objLevel->sLevel . '</option>';
				}
				?>
									</select>
									</span></td>
							</tr>
							<tr class="memberDataRow">
								<td width="123" class="">Expiration Date</td>
								<td width="255" ><span class="gridrow1">
									<input name="nDateExpires" id="nDateExpires" style="width: 50%;" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 month')));?>" readonly />
									<?php if($df==1)	echo "<span class=\"required\">Invalid date format (mm/dd/yyyy)</span>"; ?>
									</span></td>
							</tr>
						</table>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> <i class="livicon" data-name="doc-portrait" data-c="#fff" data-hc="#fff" data-size="18" data-loop="true"></i> Affiliate Information </h3>
						<span class="pull-right"> <i class="fa fa-fw fa-chevron-up clickable"></i> </span> </div>
					<div class="panel-body">
						<div class="form-group">
							<label for="nAdmin" class="control-label"> Referred By</label>
							<select name="nAffiliate_ID" class="form-control select2">
								<option value="">No Affiliate</option>
								<?php
		$sqlaf="select * from tblusers 
		where naffiliate=1 and nUser_ID != '" . $objUser->nUser_ID . "' 
		order by sforename";

		$resultaf = $dbo->select($sqlaf);
		if ($resultaf) {
			while($rowaf=$dbo->getobj($resultaf))
			{
				echo "<option value=\"" . $rowaf->nUser_ID . "\"";
			
				if($rowaf->nUser_ID==$objUser->nAffiliate_ID) echo "selected";
			
				echo ">" . $rowaf->sForename . " " . $rowaf->sSurname . "</option>";
			}
		}
		?>
							</select>
						</div>
						<div class="form-group">
							<label class="control-label" for="example-inline-checkbox1">Is Affiliate?</label>
							<input name="nAffiliate" type="checkbox" id="nAffiliate" value="1" 
			  <?php if($_SESSION['form']['nAffiliate']){if($_SESSION['form']['nAffiliate'] == 1){echo "checked";}}
			  else{if($objUser->nAffiliate==1) { echo "checked"; }} ?> />
						</div>
						<div class="form-group">
							<label class="control-label">Paypal Email</label>
							<input name="sPaypalEmail" id="sPaypalEmail" class="form-control" placeholder="Paypal Email" value="<?php echo ($_SESSION['form']['sPaypalEmail'])?$_SESSION['form']['sPaypalEmail']: $objUser->sPaypalEmail?>" />
						</div>
						<div class="form-group">
							<label class="control-label">Custom Commission %</label>
							<input name="nCustomCommission" id="nCustomCommission" class="form-control" value="<?php echo ($_SESSION['form']['nCustomCommission']) ?$_SESSION['form']['nCustomCommission']:$objUser->nCustomCommission?>" />
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> <i class="livicon" data-name="doc-portrait" data-c="#fff" data-hc="#fff" data-size="18" data-loop="true"></i> Admin Comments </h3>
						<span class="pull-right"> <i class="fa fa-fw fa-chevron-up clickable"></i> </span> </div>
					<div class="panel-body">
						<div>
							<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
								<tr class="memberDataRow">
									<td colspan="2" class=""><textarea name="sComments" id="comments" rows="5" style="width:99%" onKeyPress="showEdit('comments','edit')" ><?php echo $objUser->sComments ?></textarea></td>
								</tr>
							</table>
							<div id="commentsEdit" style="display:none" align="center">
								<input type="submit" value="Save Comments" />
								&nbsp;
								<input type="button" value="Cancel" onClick="showEdit('comments','show')" />
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> <i class="livicon" data-name="doc-portrait" data-c="#fff" data-hc="#fff" data-size="18" data-loop="true"></i> Additional Profile Details </h3>
						<span class="pull-right"> <i class="fa fa-fw fa-chevron-up clickable"></i> </span> </div>
					<div class="panel-body">
						<?php
			$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
			while($row2 = $dbo->getobj($objCustomFieldSettings)):
			if($row2->nCustomFieldSetting_ID ==1){$v = $objUser->sCustomField1;}
			elseif($row2->nCustomFieldSetting_ID ==2){$v = $objUser->sCustomField2;}
			elseif($row2->nCustomFieldSetting_ID ==3){$v = $objUser->sCustomField3;}
			elseif($row2->nCustomFieldSetting_ID ==4){$v = $objUser->sCustomField4;}
			elseif($row2->nCustomFieldSetting_ID ==5){$v = $objUser->sCustomField5;}
			elseif($row2->nCustomFieldSetting_ID ==6){$v = $objUser->sCustomField6;}
			elseif($row2->nCustomFieldSetting_ID ==7){$v = $objUser->sCustomField7;}
			elseif($row2->nCustomFieldSetting_ID ==8){$v = $objUser->sCustomField8;}
			elseif($row2->nCustomFieldSetting_ID ==9){$v = $objUser->sCustomField9;}
			else{$v = $objUser->sCustomField10;}
	?>
						<label class="control-label col-xs-3" for="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>"> <?php echo $row2->sCustomFieldName ?> </label>
						<div class="col-xs-9">
							<input type="text" class="form-control" name="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>" id="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>" value="<?php echo $v; ?>">
						</div>
						<?php endwhile; ?>
						<!-- END Panel-Body --> 
					</div>
				</div>
			</div>
			</div>
		</form>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</script> 
<!-- begining of page level js --> 
<!-- Back to Top--> 
<script type="text/javascript" src="vendors/countUp/countUp.js"></script> 
<!--datetime picker--> 
<script type="text/javascript" src="vendors/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script> 
<script type="text/javascript" src="vendors/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script> 
<script type="text/javascript">
	$(function() {
		
		$('#nJoinDate').datetimepicker({
			format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>',
			minView: 'month',
			endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?>', 
    		autoclose: true
		});
	});
<!-- end of page level js -->
</script>
</body></html>