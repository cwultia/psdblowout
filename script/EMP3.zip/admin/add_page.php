<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add New Page';
	$css = <<<EOT
<!--page level css -->
<link href="css/pages/editor.css" rel="stylesheet" type="text/css"/>
<!--end of page level css-->
EOT;
	
	//die(var_dump($_SESSION['form']));
	if($_SESSION['errors']){foreach($_SESSION['errors'] as $k=>$v){$$k = $v;}}
	// Lets Build Existing Video List
	$sql = "SELECT * FROM tblvideos";
	$res = $dbo->select($sql);
	if($res){
		while($row = $dbo->getobj($res)){
			$selects .= '<option value="[[video '.$row->nVideo_ID.']]" id="'.$row->sFileName.'">'.$row->sFileName.'</option>'."\n";
			}
		}
	if(get_option('use_mce') == '1'){
		$doc_base = $chkSsettings->sSiteURL .'/';
		if(usePageLevels($_GET['did'])) $doc_base .= 'member/';
	}
	
	require_once('header.php');
	/*if(get_option('use_mce') == '1'){
	$doc_base = $chkSsettings->sSiteURL .'/';
	if(usePageLevels($_GET['did'])) $doc_base .= 'member/';
?>
<script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script> 
<script type="text/javascript" src="common/js/tiny_mce/init.php?folder=<?php echo TEMPLATEFOLDER ?>&base=<?php echo $doc_base  ?>&linktype=r"></script>
<?php } ?>
<script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script> */?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Content</li>
      <li> <a href="page_management.php<?php echo $_SESSION['page_management_qs'] ?>">Pages</a> </li>
      <li class="active"> Add New Page </li>
    </ol>
  </section>
  <section class="content">
    <form name="form1" id="form1" method="post" action="actions.php?type=page">
      <div class="col-md-8"> <?php echo isset($message) ? $message : '' ?>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"> Add New Page</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover">
                <tr>
                  <th>File Name <font color="Red"> *</font></th>
                  <td><input name="pname" type="text" class="box" style="width:40%" value="<?php echo $_SESSION['form']['pname']; ?>" maxlength="255" onKeyUp="updateLinkName(this)"/>
                    <span class="red">
                    <?php
if ($pn == 1) {echo "[ Required ]";}
if ($lg == 1) {echo "<br>[ The page name length should not exceed 255 characters!... ]";}
if ($al == 1) {echo "<br>[ Page name already exists. Please select new name !... ]";}
?>
                    </span><br>
                    <?php echo $doc_base ?>index.php?page=<strong><span id="pagename"></span></strong></td>
                </tr>
                <tr >
                  <th>Menu Bar Name <font color="Red"> *</font></th>
                  <td ><input name="vpname" type="text" class="box" value="<?php echo $_SESSION['form']['vpname']; ?>" size="25" />
                    <span class="red">
                    <?php if ($vpn == 1) {echo "[ Required ]";} ?>
                    <?php if ($lgvpn == 1) {echo "<br>[ Visible page name should not exceed 255 characters ]";} ?>
                    </span></td>
                </tr>
                <tr >
                  <th>Status</th>
                  <td ><select name="nDisplay" id="nDisplay" class="select2">
                      <option value="1" selected>Active</option>
                      <option value="0">Inactive</option>
                    </select>
                    <input type="submit" name="Submit" value="Save" class="btn btn-success btn-responsive" /></td>
                </tr>
              </table>
            </div>
            <input type="hidden" name="did" value="<?php echo $_GET['did'] ?>"/>
            <input type="hidden" name="act" value="add" />
            <div class="bootstrap-admin-panel-content">
              <textarea class="tinymce_full" name="inpContent" rows="10"><?php echo $_SESSION['form']['inpContent']; ?></textarea>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <?php if (usePageLevels($_GET['did'])){ ?>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"> Access Rights</h3>
          </div>
          <div class="panel-body">
            <div class="row"  style="padding-bottom:5px;">Who can view this page? <font color="Red"> *</font><span class="red">
              <?php if ($pl == 1) {echo "At Least One Level Is Required<br />";} ?>
              </span>
              <?php
    $sql = "SELECT * FROM tblmembershiplevels  WHERE nActive='1' ORDER BY nOrder ASC , sLevel ASC";
    $rs = $dbo->select($sql);

    if (!empty($rs))
        while ($row = $dbo->getobj($rs)) {
			if(!$_SESSION['form']['pageLevel']){$_SESSION['form']['pageLevel'] = array();}
			$checked = (in_array($row->nLevel_ID,$_SESSION['form']['pageLevel']))? 'checked':'';
			$boxes .= '<input name="pageLevel[]" type="checkbox" value="'.$row->nLevel_ID.'" '.$checked.'/> '.$row->sLevel;
        }
    echo $boxes ?>
            </div>
            <div class="row" style="padding-bottom:5px;">Unavailable if joined after:
              <input name="nUnavailableForJoinedAfter_checkbox" type="checkbox" class="box" onClick="disable_enable_nUnavailableForJoinedAfter()" value="1" 
		<?php if ($_SESSION['form']['nUnavailableForJoinedAfter_checkbox']==1) {
        echo 'checked="checked"';
        $nUnavailableForJoinedAfter_disabled = "";

        $nUnavailableForJoinedAfter_month = $_SESSION['form']['nUnavailableForJoinedAfter_month'];
        $nUnavailableForJoinedAfter_year = $_SESSION['form']['nUnavailableForJoinedAfter_year'];

        ${"nUnavailableForJoinedAfter_month_" . $nUnavailableForJoinedAfter_month .
            "_selected"} = 'selected="selected"';
        ${"nUnavailableForJoinedAfter_year_" . $nUnavailableForJoinedAfter_year .
            "_selected"} = 'selected="selected"';

    } else {
        $nUnavailableForJoinedAfter_disabled = 'disabled="disabled"';
    } ?> />
              <select name="nUnavailableForJoinedAfter_month" <?php echo $nUnavailableForJoinedAfter_disabled; ?> >
                <option value=""></option>
                <option value="01" <?php echo $nUnavailableForJoinedAfter_month_01_selected ?>>January</option>
                <option value="02" <?php echo $nUnavailableForJoinedAfter_month_02_selected ?>>February</option>
                <option value="03" <?php echo $nUnavailableForJoinedAfter_month_03_selected ?>>March</option>
                <option value="04" <?php echo $nUnavailableForJoinedAfter_month_04_selected ?>>April</option>
                <option value="05" <?php echo $nUnavailableForJoinedAfter_month_05_selected ?>>May</option>
                <option value="06" <?php echo $nUnavailableForJoinedAfter_month_06_selected ?>>June</option>
                <option value="07" <?php echo $nUnavailableForJoinedAfter_month_07_selected ?>>July</option>
                <option value="08" <?php echo $nUnavailableForJoinedAfter_month_08_selected ?>>August</option>
                <option value="09" <?php echo $nUnavailableForJoinedAfter_month_09_selected ?>>September</option>
                <option value="10" <?php echo $nUnavailableForJoinedAfter_month_10_selected ?>>October</option>
                <option value="11" <?php echo $nUnavailableForJoinedAfter_month_11_selected ?>>November</option>
                <option value="12" <?php echo $nUnavailableForJoinedAfter_month_12_selected ?>>December</option>
              </select>
              &nbsp;
              <select name="nUnavailableForJoinedAfter_year" <?php echo $nUnavailableForJoinedAfter_disabled; ?> >
                <option value=""></option>
                <?php
    $i = 0;
    while ($i < 5) {
        $year = date(Y) - $i;
        echo "<option value='$year' " . ${"nUnavailableForJoinedAfter_year_" . $year .
            "_selected"} . ">$year</option>";
        $i++;
    }

?>
              </select>
            </div>
          </div>
        </div>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"> Drip Feed Settings</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <tr >
                <th>Days Until Available</th>
                <td><input name="naccessdays" type="text" class="box digits" value="<?php echo
isset($_SESSION['form']['naccessdays']) ? $_SESSION['form']['naccessdays'] : 0; ?>" size="5" maxlength="5" />
                  <br><font color="Red">*</font>How many days until user can view this page?<font color="Red">&nbsp; </font></td>
              </tr>
              <tr >
                <th>Dynamic Menu Bar Name?</th>
                <td ><input name="nDynamicPage" type="checkbox" class="box" value="1" <?php echo
    $_SESSION['form']['nDynamicPage'] ? 'checked="checked"' : '' ?> />
                  <small>(This will replace "Menu Bar Name" with a month and year dynamically generated according to the member's join date)</small></td>
              </tr>
              <tr >
                <th valign="top" >Email member?
                  <div id="sendemailtext" style="display:none">Email content</div></th>
                <td  ><input type="checkbox" name="nconfemail" <?php echo isset($_SESSION['form']['nconfemail']) ?
'checked="checked"' : '' ?> value="1" onChange="toggle(this,'emailoption')"/>
                  Send email when page is active?
                  <div id="sendemailbody" style="display:none">
                    <textarea name="sconfemailcontent" class="tinymce_full" cols="40" rows="8" style="width:100px;"><?php echo $_SESSION['form']['sconfemailcontent'] ?></textarea>
                  </div></td>
              </tr>
            </table>
            </div>
          </div>
        </div>
        <?php } ?>
        
        <!--  <table width="100%" border="0" cellpadding="0" cellspacing="1" >
                  <tr >
                    <td colspan="2" >Social Media Settings</td>
                  </tr>
                  <tr >
                    <td width="35%" >Integrate Facebook Comments?</td>
                    <td width="65%" ><input name="fbcomments" type="checkbox" id="fbcomments" value="1" <?php echo ($_SESSION['form']['fbcomments'] == '1') ? 'checked':''; ?> /></td>
                  </tr>
                </table>
                <br> -->
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"> Video Settings</h3>
          </div>
          <div class="panel-body">
            <div class="row">Add Video To Post?
              <select name="videoact" id="videoact" onChange="videoaction()">
                <option selected>No Video</option>
                <option value="new">Add New Video</option>
                <option value="existing">Use Existing Video</option>
              </select>
              <select name="existingvids" id="existingvids" onChange="getExistingEmbed(this)" style="display:none;">
                <option value="">-- Select Video --</option>
                <?php echo $selects ?>
              </select>
              <select name="newsel" id="newsel" onChange="newVideoOpt()" style="display:none;">
                <option selected>Select A Method</option>
                <option value="upload">Upload New Video</option>
                <option value="remote">From Url</option>
              </select>
              <div id="uploader" style="display:none"> <?php echo '<form action="ajax/video_upload.php" method="post" id="uploaderForm">' ?>
                <p>Your browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 suppor!WOW, Get a new browser.</p>
                <?php echo '</form>'; ?> </div>
              <div id="remote" style="display:none;"> URL <span style="color: red">*</span>
                <input type="text" name="sVideoURL" id="sVideoURL" style="width: 250px;" class="url required" />
                <small>e.g. http://www.somewebsite.com/uploads/video123.flv</small>
                <input name="Submit" type="button" value="Add Video" id="remoteVideo" onClick="addRemote();">
                <span id="ajaxError" class="error"></span> </div>
            </div>
            <br>
            <div id="embedTable" style="display:none">
              <hr>
              <div class="row" style="text-align:center">Video Embed Codes</div>
              <div class="row">
                <div id="embedCodes"></div>
              </div>
            </div>
          </div>
        </div>
        <?php echo pluginClass::filter("page_new_sidebar");?> </div>
      <div style="clear:both;"></div>
      <div class="col-md-12"> <?php echo pluginClass::filter("page_new_bottom");?> </div>
    </form>
  </section>
  <!-- right-side --> 
</aside>
<?php
$_SESSION['form'] = '';
unset($_SESSION['errors']);
require_once('footer.php');
if(get_option('use_mce') == '1'){
		$doc_base = $chkSsettings->sSiteURL .'/';
		if(usePageLevels($_GET['did'])){$doc_base .= 'member/';}
?>
<script  src="vendors/tinymce/js/tinymce/tinymce.min.js" type="text/javascript" ></script>
<script type="text/javascript" src="common/js/tiny_mce/init.php?folder=<?php echo TEMPLATEFOLDER ?>&base=<?php echo $doc_base  ?>&linktype=r"></script>
<?php }
?>
<!-- Load Queue widget CSS and jQuery -->
<style type="text/css">
@import url(../includes/plupload/js/jquery.plupload.queue/css/jquery.plupload.queue.css);
</style>

<!-- Third party script for BrowserPlus runtime (Google Gears included in Gears runtime now) --> 
<script type="text/javascript" src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script> 
<!-- Load plupload and all it's runtimes and finally the jQuery queue widget --> 
<script type="text/javascript" src="../includes/plupload/js/plupload.full.js"></script> 
<script type="text/javascript" src="../includes/plupload/js/jquery.plupload.queue/jquery.plupload.queue.js"></script> 
<script type="text/javascript" language="JavaScript">
var IE = false;
</script> 
<![if IE]> 
<script type="text/javascript"> IE = true;</script> 
<![endif]> 
<script type="text/javascript" src="common/js/add_page.php.js"></script>
</body></html>