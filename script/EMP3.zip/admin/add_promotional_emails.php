<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add Promo Email Templates';
	$css = <<<EOT
<!--page level css -->
<link href="css/pages/editor.css" rel="stylesheet" type="text/css"/>
<!--end of page level css-->
EOT;
	
	if(isset($_POST[Submit]))
	{
		$c=0;
		if($_POST[txtContent]=="")
		{
			$c++;
			$sb=1;
		}
		if($c==0)
		{
			if ($_POST['nSortOrder'] == '') {
				$nSortOrder = 0;
			} else {
				$nSortOrder = $dbo->format($_POST['nSortOrder']);
			}
			$sql = "INSERT INTO tblpromoemails(sEmailText, sTitle, nSortOrder, nActive) VALUES (
			'" . $dbo->format($_POST["txtContent"]) . "', 
			'" . $dbo->format($_POST['sTitle']) . "', 
			$nSortOrder,1)";
			
			if($dbo->insert($sql)){$msg = 'msg=Email Added Successfully';}
			else{$msg = "err=Database Error:$dbo->error";}
			header("location:promotional_emails.php?$msg");exit;
		}
	}
	
	require_once('header.php');
?> 

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliate System</a></li>
	  <li><a href="promotional_emails.php">Promo Email Templates</a></li>
      <li class="active"> Add Promo Email Templates</li>
    </ol>
  </section>
  <section class="content">
  <div class="col-md-12">
  <?php echo isset($message) ? $message : '' ?>
  <form name="form1" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"> Add Promotional Email</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover">
		<tr>
			<td class="gridrow1" width="250">Email Title <span class="red">*</span></td>
			<td class="gridrow2"><input type="text" name="sTitle" class="required" style="width: 250px;"></td>
		</tr>
		<tr>
			<td class="gridrow1">Sort Order</td>
			<td class="gridrow2"><input type="text" name="nSortOrder" style="width: 50px;"></td>
		</tr>
		<tr>
			<td valign="top" class="gridRow1">Email Body <span class="red">*</span></td>
			<td valign="middle" class="gridRow2">
			<input name="button2" type="button"  class="inputSubmitb" onClick="InsertText(document.form1.txtContent,'#AFFILIATE LINK#');"  value="Insert Affiliate Link" />
			<br /><br />
			<textarea name="txtContent" cols="58" rows="12" class="required"></textarea></td>
		</tr>
      </table>
</div>
<input class="btn btn-primary btn-responsive" name="Submit" value="Submit" type="submit">
</div></div>

</form>
</div>
  </section>
  <!-- right-side --> 
</aside>
<?php require_once('footer.php'); ?>
<script type="text/javascript">
	// SCRIPT USED TO INSERT THE STRING INTO THE TEXTAREA
	function InsertText(input, insTexte){
startTag = '';
endTag = '';
	if (input.createTextRange)
	{
		var text;
		input.focus(input.caretPos);
		input.caretPos = document.selection.createRange().duplicate();
		if(input.caretPos.text.length>0)
	{
		input.caretPos.text = startTag + input.caretPos.text + endTag;
	}
	else
	{
		input.caretPos.text = startTag + insTexte +  endTag;
	}
	}
else input.value += startTag + insTexte + endTag;}
	$(document).ready(function(){$("#form1").validate();});
</script>
</body></html>