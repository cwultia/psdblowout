<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add Promo Graphics';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
	
	if ( isset($_POST['Submit']) )
	{
		$c = 0; // lk - where is this being used?
		$ty = $_FILES['imgfile']['type'];
		$pieces = explode("/", $ty); // lk - what is the 'pieces[]' array used for? maybe ( pieces[0] == 'image' ) ?
		
		if ( ($ty == 'image/jpeg') || ($ty == 'image/pjpeg') || ($ty == 'image/gif') || ($ty == 'image/png') )
		{
			$dbo->insert("INSERT INTO tblpromographics(sdescription) VALUES ('image')",1);
			$rm = $dbo->getrow("SELECT * FROM tblpromographics ORDER BY npromographic_id DESC");
			
			$imgfile = $_FILES['imgfile']['tmp_name'];
			
			if ( $imgfile != '' )
			{
				copy($imgfile, '../promotional_pic/' . $rm['nPromoGraphic_ID'] . '.jpg');
			}
			
			header("location:promotional_graphics.php?act=adsus");
		}
		else
		{
			header("location:promotional_graphics.php?act=a&im=1");
		}}

require_once('header.php');
?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Affiliate System</a></li>
			<li><a href="promotional_graphics.php">Promo Graphics</a></li>
			<li class="active"> Add Promo Graphics</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form name="frm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?act=a" enctype="multipart/form-data">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> Add Promotional Graphics</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<td width="81" valign="top" nowrap="nowrap" >Graphic <font color="Red"> *</font></td>
									<td width="851" valign="middle" ><input name="imgfile" type="file" class="submit" size="45" />
										<span class="red">
										<?php if ($_GET['im'] == 1) { echo "[ Please upload JPG / GIF format images ]"; } ?>
										</span></td>
								</tr>
							</table>
						</div>
					</div>
					<input class="btn btn-primary btn-responsive" name="Submit" value="Submit" type="submit" />
				</div>
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php require_once('footer.php'); ?>
</body></html>