<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Admin Login Log';
	$css = <<<EOT
<!--page level css -->


<!--end of page level css-->
EOT;

	// Get total number of records
	$sql2 = "SELECT COUNT(*) AS nCount FROM tbladminlogins ";
	$number = $dbo->getval($sql2); // Number of records
	// Setup Options for Members per Page listing
	$aMPP = array('5', '10', '15', '20', '25', '50', '100');
	$mpp = (empty($_GET['mpp'])) ? 25 : $_GET['mpp'];
			
	// Start Paging
	/*********************************************************/
	include_once('paging.php');
	$objPaging = new Paging();
			
	$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
	unset($_GET['start']);
		 	
	$objPaging->Total_Records_Per_Page = $mpp; 
	$objPaging->Total_Records = $number;
	$index = $start ;
	$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
	$objPaging->prepare_ParameterString($_GET);
	$objPaging->set_Start_Item($indexupto); 	 		 	
	$objPaging->Has_First_Last = true;	
	$navigator = $objPaging->Create_Paging();
	$pageinfo = $objPaging->get_PageInfo();	 	
	$counter = 0;  
	$sql .= " LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
			/*********************************************************/
//die($sql);
	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Admin Logs</li>
      <li class="active">Admin Logins</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Admin Logins</h3>
        </div>
        <div class="panel-body">
        <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
            <div class="table-responsive">
            
              <table class="table table-striped table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Admin User</th>
                    <th>Date / Time</th>
                    <th>Ip Address</th>
                    <th>Browser</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
			$sql = "
SELECT tbladminlogins. * , tblusers.sEmail
FROM tbladminlogins
LEFT JOIN tblusers ON tblusers.nUser_ID = tbladminlogins.nUser_ID
ORDER BY `tbladminlogins`.`nTimestamp` DESC"
;

$result = $dbo->select($sql);
					while ($row = $dbo->getobj($result)){
				?>
                  <!-- MEMBER LISTING -->
                  <tr>
                    <td ><a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID; ?>" title="Member Details"><strong> <?php echo $row->sEmail; ?> </strong></a></td>
                    <td><?php echo date("F j, Y, g:i a",$row->nTimestamp); ?> &nbsp; </td>
                    <td><a href='http://www.ip-tracker.org/locator/ip-lookup.php?ip=<?php echo $row->sIp ?>' target="_blank"><?php echo $row->sIp ?></a></td>
                    <td><?php echo $row->sBrowser ?></td>
                  </tr>
                  <?php 
					}
				
				?>
                </tbody>
              </table>
              
            </div>
            <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</body></html>