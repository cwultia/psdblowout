<?php
	include_once('../conn.php');
	include_once('../functions.php');
	include_once('../includes/functions-time.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Advanced Site Settings';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
	
	
	// Check for pear
	
	$use_mce = get_option('use_mce');
	$usepath = get_option('protected_usepath');
	
	if ( isset($_POST['Update']) ){
		if($use_mce != $_POST['use_mce'])  update_option('use_mce',$_POST['use_mce']); $use_mce = $_POST['use_mce'];
		
		if($_POST['usepath'] && $_POST['usepath'] == '1'){
			if(is_option('protected_usepath')){update_option('protected_usepath',$_POST['usepath']);}
			else{add_option('protected_usepath',$_POST['usepath']);}
			
		}
		else{
			if(is_option('protected_usepath')){remove_option('protected_usepath');}
		}
		
		// Error checking on smtp settings
		$err = 0;
	}

	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>General Settings</li>
			<li class="active">Advanced Settings</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Advanced Site Settings</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<th colspan="2" align="center">Editor Options</th>
								</tr>
								<tr>
									<th>Use TinyMce Editor<font style="color:red">&nbsp;</font></th>
									<td><p>
											<label>
												<input name="use_mce" type="radio" id="use_mce_0" value="1" <?php echo ($use_mce == '1') ? ' checked="CHECKED"' : '' ?> />
												Yes</label>
											&nbsp;
											<label>
												<input type="radio" name="use_mce" value="0" id="use_mce_1" <?php echo ($use_mce == '0') ? ' checked="CHECKED"' : '' ?> />
												No</label>
											<br>
										</p></td>
								</tr>
								<tr>
									<th colspan="2" align="center"><span style="text-align:center">Video And File Protection</span></th>
								</tr>
								<tr>
									<th>Location Type</th>
									<td><p>
											<label>
												<input name="usepath" type="radio" id="usepath_0" value="0" <?php if(!is_option('protected_usepath'))echo 'checked="CHECKED"'; ?>>
												Site Url</label>
											&nbsp;
											<label>
												<input type="radio" name="usepath" value="1" id="usepath_1" <?php if(is_option('protected_usepath') || get_option('protected_usepath') == '1')echo 'checked="CHECKED"'; ?>>
												Site Path</label>
											<br>
										</p></td>
								</tr>
							</table>
						</div>
						<input type="submit" name="Update" value="Save Changes" class="btn btn-primary btn-responsive" />
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">
        	function toggleSmtp(radio){
				
				if(radio.value == 'smtp'){
					document.getElementById('smtp_settings').style.display = 'block'
				}
				else{
					document.getElementById('smtp_settings').style.display = 'none'
				}
			}
        </script>
</body></html>