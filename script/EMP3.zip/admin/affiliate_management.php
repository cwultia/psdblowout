<?php
include_once('../conn.php');
include_once('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Manage Affiliate Settings';
	$css = <<<EOT
<!--page level css -->


<!--end of page level css-->
EOT;


	// Validate amounts entered
	
	if ( isset($_POST['Update']) ){
		$c = 0;
		
		// VALIDATION FOR PERCENTAGE
		
		if (isset($_POST['nPercentage']) && $_POST['nPercentage'] > 100)
		{
			$c++;
			$gpnp1 = 1;
		}
		
		if (isset($_POST['nPercentage']) && !is_numeric($_POST['nPercentage']))
		{
			$c++;
			$gpnp2 = 1;
		}
		
		if ($_POST['paypal'] == "" && $_POST['check'] == '')
		{
			$c++;
			$op = 1;
		}
		if (!is_numeric($_POST['nCookieExpiry']) && $_POST['nCookieExpiry'] != '' && !$_POST['nCookieNeverExpires']) {
			$c++;
			$ce = 1;
		}
		
		if ($c == 0)
		{
			$chkPaypal = ($_POST['paypal'] == 1) ? 1 : 0;
			$chkCheck = ($_POST['check'] == 1) ? 1 : 0;
			$chkHideAffiliateProgram = ($_POST['hideAffiliateProgram'] == 1) ? 1 : 0;
			$chkHideCustomerData = ($_POST['hideCustomerData'] == 1) ? 1 : 0;
			$chkAutoEnroll = ($_POST['nAutoEnroll'] == 1) ? 1 : 0;
			
			$sql = "UPDATE tblaffiliatesettings SET 
			scommissiontype='Percentage', 
			npercentage=" . $dbo->format($_POST['nPercentage']) . ", 
			npaypal=$chkPaypal, 
			ncheck=$chkCheck,
			nHideAffiliateProgram=$chkHideAffiliateProgram,
			nHideCustomerData=$chkHideCustomerData,
			nAutoEnroll = $chkAutoEnroll";
			
			$dbo->update($sql);
			
			$sql = "UPDATE tblsitesettings SET 		
						ncookieexpiry='".$dbo->format($_POST['nCookieExpiry'])."', 
						ncookieneverexpires='".$dbo->format($_POST['nCookieNeverExpires'])."'";
			$dbo->update($sql);
	
			// Deactivate / Reactivate the affiliates page
			$sqlTakeAffiliateFolderID="SELECT nDirectory_ID FROM tbldirectories WHERE sDirectoryName = 'Affiliates'";		
			$rsTakeAffiliateFolderID = $dbo->select($sqlTakeAffiliateFolderID);
			if(!empty($rsTakeAffiliateFolderID)) {
				$rwTakeAffiliateFolderID = $dbo->getobj($rsTakeAffiliateFolderID);
			}		
			
			if(isset($_POST['hideAffiliateProgram'])) {
				$sql = "UPDATE tblpages SET nDisplay = 0 WHERE nDirectory_ID = $rwTakeAffiliateFolderID->nDirectory_ID";
			} else {
				$sql = "UPDATE tblpages SET nDisplay = 1 WHERE nDirectory_ID = $rwTakeAffiliateFolderID->nDirectory_ID";
			}			
		
			$dbo->update($sql);
			$message = '<p class="success">Affiliate settings have been updated.</p>';
		}
	}
	
	$objAffiliateSettings = $dbo->getrow("SELECT * FROM tblaffiliatesettings");
	$rw = $dbo->getobject("SELECT * FROM tblsitesettings");
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a> </li>
			<li>Affiliate System</li>
			<li class="active">Affiliate Settings</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form action="affiliate_management.php" name="form" method="post">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"> Affiliate System Settings</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<td><label for="hideAffiliateProgram" >Disable Affiliate Program:</label>
										<input type="checkbox" value="1" name="hideAffiliateProgram" id="hideAffiliateProgram" <?php if ($objAffiliateSettings['nHideAffiliateProgram'] == 1) { echo 'checked="checked"'; } ?> style="margin-left:3px;margin-bottom:0px" /></td>
								</tr>
								<tr>
									<td >Auto Enroll Members:
										<input name="nAutoEnroll" type="checkbox" id="nAutoEnroll" value="1" <?php if ($objAffiliateSettings['nAutoEnroll'] == 1) { echo 'checked="checked"'; } ?> >
										<label for="nAutoEnroll"></label></td>
								</tr>
								<!-- added ability to Hide Customers Name and Email Address from Commisions Repport -->
								<tr>
									<td ><label for="hideCustomerData" >Hide Member's Email Address from Affiliate Commissions and Referrals Report:</label>
										<input type="checkbox" value="1" name="hideCustomerData" id="hideCustomerData" <?php if ($objAffiliateSettings['nHideCustomerData'] == 1) { echo 'checked="checked"'; } ?> style="margin-left:3px;margin-bottom:0px" /></td>
								</tr>
								<tr>
									<td >Enable Export Of Affiliate Referrals
										<input name="export_affiliates" type="checkbox" id="export_affiliates" value="1" disabled>
										<label for="export_affiliates">Coming Soon ...</label></td>
								</tr>
								<tr>
									<td >Affiliate Cookie Expiry: &nbsp;
										<?php 
											if($_POST['nCookieNeverExpires'] == 1 || $rw->nCookieNeverExpires == 1){ 
												$checked =  "checked";
												$disabled = "disabled";
											} 
										?>
										<input <?php echo $disabled?> name="nCookieExpiry" id="nCookieExpiry" type="text" value="<?php echo ($_POST['nCookieExpiry'] ? $_POST['nCookieExpiry'] : $rw->nCookieExpiry);?>" size="10" />
										Days
										<input  <?php echo $checked?> id="nCookieNeverExpires" name="nCookieNeverExpires" type="checkbox" id="nCookieNeverExpires" value="1" onClick="if(this.checked==true){document.getElementById('nCookieExpiry').value=90;document.getElementById('nCookieExpiry').disabled=true}else{ document.getElementById('nCookieExpiry').disabled=false}"/>
										<label for="nCookieNeverExpires">Cookie Never Expires</label>
										<?php if ($ce == 1) { ?>
										<span class="red">[ INVALID ] (Numbers only.)</span>
										<?php } ?></td>
								</tr>
								<tr>
									<td class="gridHeader"><b>Percentage of each sale <font color="Red"> *</font></b></td>
								</tr>
								<tr>
									<td ><input name="nPercentage" type="text" size="10" value="<?php echo $objAffiliateSettings['nPercentage']; ?>" />
										%
										<?php if ($gpnp1 == 1) { echo '<span class="error">[ Percentage value must not exceed 100 ]</span><br />'; } ?>
										<?php if ($gpnp2 == 1) { echo '<span class="error">[ Only numeric values are allowed ]</span>'; } ?></td>
								</tr>
								<tr>
									<td class="gridHeader"><b> Payment Methods <font color="Red"> *</font>
										<?php if ($op == 1) { echo '<span class="error">[ Please select a payment method ]</span>'; } ?>
										</b></td>
								</tr>
								<tr>
									<td ><input type="checkbox" name="paypal" value="1" <?php if ($objAffiliateSettings['nPaypal'] == 1) { echo 'checked="checked"'; } ?> />
										Paypal </td>
								</tr>
								<tr>
									<td ><input type="checkbox" name="check" value="1" <?php if ($objAffiliateSettings['nCheck'] == 1) { echo 'checked="checked"'; } ?> />
										Check </td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<input type="submit" name="Update" value="Save Changes" class="btn btn-responsive btn-primary" />
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</body></html>