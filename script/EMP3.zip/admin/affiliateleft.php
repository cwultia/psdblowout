<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
<tr><td class="sideHeader">&nbsp;Affiliate Management </td></tr>
<tr><td class="sideRow"><img src="images/ss.jpg" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="affiliate_management.php">Affiliate Options</a></td></tr>
<tr><td class="sideRow"><img src="images/dollor.gif" alt="" align="absmiddle" border="">&nbsp;<a class="opt" href="pay_affiliates.php">Pay Affiliates</a></td></tr>
<tr><td class="sideRow"><img src="images/dollor.gif" alt="" align="absmiddle" border="">&nbsp;<a class="opt" href="pay_affiliates_files.php">Affiliates Files</a></td></tr>
<tr><td class="sideRow"><img src="images/emmail.gif" alt="" align="absmiddle" border="">&nbsp;<a class="opt" href="email_members.php">Email Affiliates</a></td></tr>

<tr><td class="sideRow"><img src="images/export.jpg" alt="" align="absmiddle" border="" />&nbsp;<a class="opt" href="export_affiliates.php">Export Affiliates</a></td></tr>
</table>


<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
<tr><td class="sideHeader">&nbsp;Promotion tools </td></tr>
<tr><td class="sideRow"><img src="images/th.jpg" alt="" align="absmiddle" border="" />&nbsp;<a class="opt" href="email_subject.php">Email Subject Lines</a></td></tr>
<tr><td class="sideRow"><img src="images/th.jpg" alt="" align="absmiddle" border="">&nbsp;<a class="opt" href="promotional_emails.php">Promotional Emails</a></td></tr>
<tr><td class="sideRow"><img src="images/th.jpg" alt="" align="absmiddle" border="">&nbsp;<a class="opt" href="promotional_graphics.php">Promotional Graphics</a></td></tr>
</table>

<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
<tr><td class="sideHeader">&nbsp;Reports </td></tr>
<tr><td class="sideRow"><img src="images/pay.jpg" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="unpaid_commissions.php">Unpaid Commissions</a></td></tr>
</table>
