<?php
	require('../../conn.php');
	require('../../functions.php');
	
	function remoteFileOpen($url){
		
		// Curl is the preferred method of remote files
		if(function_exists('curl_init')){
			
			$ch = curl_init();
			$timeout = 5;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			//curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$data = curl_exec($ch);
			curl_close($ch);
			return $data;
			
		}
		else{
			
			return file_get_contents($url);
			
		}
	}
	
	echo remoteFileOpen($_GET['url']);
?>