<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Autoresponder Settings';
	$css = <<<EOT
<!--page level css -->

<!--end of page level css-->
EOT;
	
	
	$objAutoresponder = $dbo->getobject("SELECT * FROM tblautoresponders LIMIT 1;");
	if ( isset($_POST['Update']) )
	{
		$active = ($_POST['nActive'] == 1)?1:0;
		if($objAutoresponder){
			$sql = "UPDATE tblautoresponders SET 
					sAutoresponderName='".$dbo->format($_POST['sAutoresponderName'])."', 
					sAutoresponderURL='".$dbo->format($_POST['sAutoresponderURL'])."', 
					sHiddenFields='".htmlentities($_POST['sHiddenFields'])."', 
					sFormName='".$dbo->format($_POST['sFormName'])."', 
					sFormEmail='".$dbo->format($_POST['sFormEmail'])."',
					nActive='".$dbo->format($active)."'
					WHERE nAutoresponder_ID=".$objAutoresponder->nAutoresponder_ID.";";
					$dbo->update($sql);
		}else{
			$sql = "INSERT INTO tblautoresponders (
						sAutoresponderName, sAutoresponderURL, sHiddenFields, sFormName, sFormEmail, nActive 
				)VALUES('".$dbo->format($_POST['sAutoresponderName'])."', 
						'".$dbo->format($_POST['sAutoresponderURL'])."',
						'".htmlentities($_POST['sHiddenFields'])."',
						'".$dbo->format($_POST['sFormName'])."',
						'".$dbo->format($_POST['sFormEmail'])."',
						'".$dbo->format($active)."');";
						$dbo->insert($sql);
		}
		
		$message = "<p class='success'>Auto responder settings have been updated successfully</p>";}
	$objAutoresponder = $dbo->getobject("SELECT * FROM tblautoresponders LIMIT 1;");
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Emails</li>
			<li class="active">Autoresponder Settings</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">3rd Party Autoresponder Settings</h3>
				</div>
				<div class="panel-body">
					<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<tr>
								<th>Autoresponder Name:<font color="Red"> *</font></th>
								<td ><input type="text" name="sAutoresponderName" value="<?php echo ($objAutoresponder)?$objAutoresponder->sAutoresponderName:''; ?>" size="35" class="required"></td>
							</tr>
							<tr>
								<th>Autoresponder Post URL:<font color="Red"> *</font></th>
								<td ><input type="text" name="sAutoresponderURL" value="<?php echo ($objAutoresponder)?$objAutoresponder->sAutoresponderURL:''; ?>" size="35" class="required url"></td>
							</tr>
							<tr valign="top">
								<th>Hidden Form Fields:</th>
								<td ><textarea name="sHiddenFields" cols="50" rows="10"><?php echo ($objAutoresponder)?html_entity_decode($objAutoresponder->sHiddenFields):''; ?></textarea></td>
							</tr>
							<tr>
								<th>Name Field Name:<font color="Red"> *</font></th>
								<td ><input type="text" name="sFormName" value="<?php echo ($objAutoresponder)?$objAutoresponder->sFormName:''; ?>" size="35" class="required">
									&lt;input type=&quot;text&quot; name=&quot;<strong>name</strong>&quot;</td>
							</tr>
							<tr>
								<th>Email Field Name:<font color="Red"> *</font></th>
								<td ><input type="text" name="sFormEmail" value="<?php echo ($objAutoresponder)?$objAutoresponder->sFormEmail:''; ?>" size="35" class="required">
									&lt;input type=&quot;text&quot; name=&quot;<strong>email</strong>&quot;</td>
							</tr>
							<tr>
								<th>Active:</th>
								<td ><input type="checkbox" name="nActive" value="1" size="20" <?php echo ($objAutoresponder)?$objAutoresponder->nActive?'checked="checked"':'':''; ?>></td>
							</tr>
						</table>
						</div>
						<input type="submit" name="Update" value="Save Settings" class="btn btn-primary btn-responsive" />
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
</body></html>