<?php error_reporting(0) ?><div id="footer"><span style="padding: 0 10px;">Copyright &copy; 2006-<?php echo date('Y');  ?> <a href="http://www.easymemberpro.com/" target="_blank">EasyMemberPro</a>. All rights reserved.</span></div>
<div id="dialog-confirm" title="Session Expiration Warning" style="display:none;">
<p> <span class="countdown"></span></p>
</div>