<?php
// Check if the constant has been defined... if not, set it to FALSE (and don't include the conn.php script).
if ( !defined('CREATE_ZIP_SILENTLY') ) // lk - the 'CREATE_ZIP_SILENTLY' constant is defined in the 'cron.php' script.
{
	include_once('../conn.php');
	include_once('inc_config.php');
	include_once('inc_functions.php');
	define('CREATE_ZIP_SILENTLY', false);
}
require_once('common/php/pclzip.lib.php');
setlocale(LC_TIME, $Taal);
$x = 0;
	
	if ($_POST['tonen'] == '')
	{
		$tonen = $TonenDefault;
	}
	else
	{
		$tonen = $_POST['tonen'];
	}
	
	if ( !is_array($_POST['tabel']) )
	{
		// Get the list of tables in the database '$dbName' and remove the tables from '$NotTable' of that list
		$tabellen = getTableList($dbName);
	}
	else
	{
		foreach($_POST['tabel'] as $key => $value) $tabellen[] = $key;
	}
	
	// Generate a filename for the dump-file and the ZIP-file
	$today = 'backup-' . date('m-d-Y');
	$ZIPfile_name = $DIR . $today . '.zip';
	
	// Check if the ZIP file already exists, if so - delete it.
	if ( file_exists($ZIPfile_name) )
	{
		unlink($ZIPfile_name);
	}
	
	foreach ($tabellen as $tabel)
	{
		if ($tabel != '')
		{
			// Generate a filename for the dump-file and the ZIP-file
			// $today = "backup-".date("m-d-Y");
			$file_name = $DIR . $tabel . $extensie;
			// $ZIPfile_name = $DIR .  $today . '.zip';
			
			// Check if the directory to store the dump-files exist
			checkDir($DIR);
			checkDir($DIR . $tabel);
			
			// Check to see if it's necessary to make a dump-file at this moment
			$Files				= getBackupDates($DIR . $tabel. '/');
			$temp				= each($Files);
			$FileChangeDate		= $temp[0];
			$TableChangeDate	= getTableStatus($tabel);
			
			//if ( ($FileChangeDate < $TableChangeDate) || ($_POST['Alles'] == 'true') )
			if ( ($FileChangeDate < $TableChangeDate) || ($_POST['Alles'] == 'true') || (CREATE_ZIP_SILENTLY) )
			{
				// Check if an old back-up should be removed
				checkNumberBackups($DIR . $tabel.'/');
				
				// Check if the dump-file already exist
				checkFile($file_name);
				
				// Write the header to the dump-file
				setTekst($file_name, $KopTekst);
					
				// Write the structure of the table to the dump-file (if selected so in the config-file)
				if($StructuurSchrijven) { $defenitie = getDefenitie($tabel); setTekst($file_name, $defenitie); }
						
				// Write the data of the table to the dump-file (if selected so in the config-file)
				if($DataSchrijven) { $data = getData($tabel); setTekst($file_name, $data); }
				
				// Write the footer to the dump-file
				setTekst($file_name, $Footer);
				
				// Get the filesize of the dump-file  
				$grootte = filesize($file_name) / 1024;
				
				// Maak ZIP-file
				$archive	= new PclZip($ZIPfile_name);
				$v_list		= $archive->add($file_name);
				unlink($file_name);
				
				// Put filenames and sizes in an array
				if($tonen) { $kolomen[0][$x] = $tabel; $kolomen[1][$x] = number_format($grootte,1) ." Kb"; $x++;}
				
			} else {
				// Put filenames and 'no backup' in an array
				if($tonen) { $kolomen[0][$x] = $tabel; $kolomen[1][$x] = "No back-up"; $kolomen[2][$x] =  date("d M H:i:s", fileatime($file_name)); $x++;}
			}
		}	
	}
	
	// If the ZIP file is being created silently, then we do not want any output.
	if ( !(CREATE_ZIP_SILENTLY) )
	{
		// Show the results on the screen (is selected so)
		header("location:backup_database.php?act=suss&s=1");
		//if($tonen) { echo setTable(0, "Tables from <b>". ucfirst($dbName) ."</b>", $kolomen); }
	}
?>