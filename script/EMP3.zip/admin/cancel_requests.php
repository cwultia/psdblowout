<?php
include_once('../conn.php');
include_once('../functions.php');

$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Cancellation Requests';
	$css = <<<EOT
<!--page level css -->


<!-- daterange picker -->
<link href="vendors/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->

EOT;



	// Get updated site data
	$chkSsettings = $dbo->getobj($dbo->select("SELECT * FROM tblsitesettings"));
	
	function cancelType($i){
		switch ($i) {
		case 0:
			return "Admin Approved";
			break;
		case 1:
			return "Member Auto Cancel";
			break;
	}
		}
	// Setup Options for Members per Page listing
	$aMPP = array('5', '10', '15', '20', '25', '50', '100');
	$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];
	
	// Main query
	$mainquery = "SELECT tblcancellations. * , tblusers.sForename, tblusers.sSurname, tblusers.sSurname,tbluserlevels.nLevel_ID, tblmembershiplevels.sLevel
	FROM tblcancellations
	LEFT JOIN tblusers ON tblusers.nUser_ID = tblcancellations.nUser_ID
	LEFT JOIN tbluserlevels ON tbluserlevels.nUserLevel_ID = tblcancellations.nUserLevel_ID
	LEFT JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID";
			
	if($_GET['act'] == 'p'){
		// process the cancellation
		admin_cancel_level($_GET['lid'],$_GET['id']);
		header("Location: cancel_requests.php");
		exit;
		}
	if($_GET['act'] == 'd'){
		
		$sql = "DELETE FROM `tblcancellations` WHERE `tblcancellations`.`nCancellation_ID` = ".$_GET['id']." LIMIT 1";
		$dbo->Delete($sql);
		header("Location: cancel_requests.php?msg=Request Deleted Successfully");
		exit;
		}		
			
			
			
	require_once('header.php');
	?>

	
   <aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Members</li>
      <li class="active">Cancel Requests</li>
    </ol>
  </section>
  <section class="content">
	<!-- Begin Members -->
    <div class="col-md-12"> 
      <!-- BEGIN SAMPLE TABLE PORTLET-->
      <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Pending Cancellation Requests </div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
				<tr>
					<th>First name</th>
					<th>Last Name</th>
					<th>Membership</th>
                    <th>Request Date</th>
					<th>Comment</th>
					<th colspan="2">Actions</th>
				</tr>
                </thead>
                <tbody>
                <?php
				$sql = $mainquery . " WHERE nStatus = '0';";
				//die($sql);
				$result = $dbo->select($sql);
				$nr = $dbo->nr($result);
				if($nr){
					while($objPending = $dbo->getobj($result)){ ?>
						<tr>
                        <td><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sForename?></a></td>
						<td><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sSurname?></a></td>
						<td><?php echo $objPending->sLevel?></td>
						<td><?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$objPending->nRequest_date))?></td>
						<td><?php echo $objPending->sComment?></td>
						<td><a href="cancel_requests.php?act=p&id=<?php echo $objPending->nCancellation_ID?>&lid=<?php echo $objPending->nUserLevel_ID?>">Process</a></td>
						<td><a href="cancel_requests.php?act=d&id=<?php echo $objPending->nCancellation_ID?>">Delete</a></td>
						</tr>
						<?php
						}
					}
				else{?><tr><td colspan="7">No Pending Requests ...</td></tr><?php }
				?>
               </tbody>
            </table>
                    <div class="row">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-12"> 
    <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Completed Cancellation Requests </div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>

<table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
				<tr>
					<th>First name</th>
					<th>Last Name</th>
					<th>Membership</th>
					<th>Cancel Date</th>
                    <th>Cancel Type</th>
					<th colspan="2">Comment</th>
				</tr>
			</thead>
            <tbody>
                <?php
				$sql = $mainquery . " WHERE nStatus != '0';";
				//die($sql);
				$result = $dbo->select($sql);
				$nr = $dbo->nr($result);
				
				if($result){
						while($objPending = $dbo->getobj($result)){ ?>
						<tr>
                        <td><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sForename ?></a></td>
						<td><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sSurname?></a></td>
						<td><?php echo $objPending->sLevel?></td>
						<td><?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$objPending->nProcess_date))?></td>
						<td><?php echo cancelType($objPending->nProcess_type)?></td>
						<td><?php echo $objPending->sComment ?></td>
						</tr>
						<?php
						}
					}
				else{echo '<tr><td colspan="7">No Completed Cancellations ...</td></tr>';}
				?>
                </tr>
                </tbody>
          </table>
		  <div class="row">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
		
 </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript"> 
		function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=0';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}
	
      
      function toggle(id){
		var ele = document.getElementById(id);
		if(ele.style.display == 'none'){ele.style.display = 'block'}
		else{ele.style.display = 'none'}
		}
    </script>
	</body>
</html>