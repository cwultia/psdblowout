<?php

error_reporting(0);

include 'common/php/ofc/open-flash-chart.php';

include_once('../conn.php');

include_once('../functions.php');

	$type = $_GET['data'];

	if($type=='membership')

	{	

		//$title = new title( "Number of New/Cancelled Members Over The Past 30 Days" );

		//$title = new title( "New Members Over The Past 30 Days" );

		$now_date = date('Ymd');

		// this will be first day showed on chart it can be increased or decreased as necessary

		$last_month_stamp = strtotime("-30 days", time());

		$last_month_date = date('Ymd', $last_month_stamp);		

		

		$date = $last_month_date;

		$stamp = $last_month_stamp;

		$list = array();

		$max = 0;

		//first we create array with all days and 0 values for joned and canceled users

		while($date <= $now_date) {			

			$list[$date] = array('join' => 0, 'canceled' => 0);

			$stamp = $stamp + 86400;

			$date = date('Ymd',$stamp);

		}

		//get new users

		$sql = "SELECT COUNT(*) as nCount,  nJoinDate FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_month_date AND tblusers.nAdmin = 0 GROUP BY nJoinDate";

		$rs = $dbo->select($sql);

		//update $list array with retrived data 

		$tcount = 0;

		while ($row = @$dbo->getassoc($rs)) {

			$join_date = $row['nJoinDate'];

			$count = $row['nCount'];

			$tcount =$tcount + $count;

			$list[$join_date]['join'] = $count;

			if ($max < $count) {

				$max = (int) $count;

			}

		}

	$title = new title( "$tcount New Members Over The Past 30 Days");
		//array with data for chart joined bar

		$data_join = array();

		//array with data for chart cancelled accounts bar

		//$data_canceled = array();

		//data for x axis (dates)

		$x_labels = array();

		foreach ($list as $date => $value) {

			$data_join[] = (int) $value['join'];

			//$data_canceled[] = (int) $value['canceled'];

			$x_labels[] = (string) substr($date, 6,2);

		}

		

		//create new bar (joined users)

		$bar = new bar_glass();

		//set bar color

		$bar->colour('#009933');

		//bar description and description's text size

		$bar->key('Joined', 12);

		//set array with values

		$bar->set_values( $data_join );

		

		//create second bar (cancelled accounts)

		//$bar2 = new bar_glass();

		//$bar2->colour('#FF0000');

		//$bar2->set_key('Cancelled', 12);

		//$bar2->set_values( $data_canceled );

		

		//create x axis

		$x = new x_axis();

		$x->set_colours('#666666','#cccccc');

		

		//set some little left side offset

		$x->set_offset( 10 );

		//set data for labels on x axis

		$x->set_labels_from_array( $x_labels );

		//create y axis

		$y = new y_axis();

		$y->set_colours('#666666','#cccccc');

		//we calculate max value for y axis

		$max = (substr($max, 0, 1) + 1) * pow(10,(strlen($max)-1));

		$grade = pow(10,(strlen($max)-1));

		

		//echo "MAX#$max#$total#" .(substr($total, 0, 1) + 1) . '#' . pow(10,(strlen($total)-1)) . '#';

		//set range of y axis

		$y->set_range( 0, $max, $grade);

		//now create new chart	

		$chart = new open_flash_chart();

		//set background color

		$chart->set_bg_colour('ffffff');

		

		//add x axis

		$chart->set_x_axis( $x );

		//add y axis

		$chart->set_y_axis( $y );

		//set title

		$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );

		$chart->set_title( $title );

		//add first bar

		$chart->add_element( $bar );

		//add second bar

		//$chart->add_element( $bar2 );

		

		//set x legend

		$x_legend = new x_legend( 'Days of Month' );

		$x_legend->set_style( '{font-size: 15px;  font-family: Verdana;color: #000000}' );

		$chart->set_x_legend( $x_legend );

		

		//set y legend

		$y_legend = new y_legend( 'Number' );

		$y_legend->set_style( '{font-size: 15px;  font-family: Verdana;color: #000000}' );

		$chart->set_y_legend( $y_legend );

		

		//output JSON string

		echo $chart->toString();

	}

	elseif($type=='revenue'){

		$now_date = date('Y-m-d');
		$tomorrow = date('Y-m-d',strtotime('+1 Day',time()));

		// this will be first day showed on chart it can be increased or decreased as necessary

		$last_month_stamp = strtotime("-30 days", time());

		$last_month_date = date('Y-m-d', $last_month_stamp);		

		$date = $last_month_date;

		$stamp = $last_month_stamp;

		$list = array();

		$max = floatval(0.00);

		//first we create array with all days and 0 values for the revenue

		while($date <= $now_date) {			

			$list[$date] = array('revenue' => 0);

			$stamp = $stamp + 86400;

			$date = date('Y-m-d',$stamp);

		}

		//get  revenue

		$sql = "SELECT SUM(nSaleAmount) as nCount,  dDateTime FROM tbltransactions WHERE ntransactiontype_id = 1 and dDateTime >= '$last_month_date' AND dDateTime < '$tomorrow' GROUP BY YEAR(dDateTime), MONTH(dDateTime) , DAY(dDateTime) ASC";

		$rs = $dbo->select($sql);

		//update $list array with retrived data 

		$total = 0;

		while ($row = @$dbo->getassoc($rs)) {

			$dDateTime = substr($row['dDateTime'],0,10);

			$count = floatval($row['nCount']);
			// Fix
			//$count = (int)$row['nCount'];

			$list[$dDateTime]['revenue'] = $count;

			$total += $count;

			if ($max < $count) {

				$max = $count;

			}

		}

		

		//$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);

		//$titlestring = "Revenue Generated Over The Past 30 Days - ".number_format($total,2).' '.$chkSsettings->sCurrencyFormat;
$titlestring = number_format($total,2).' '.$chkSsettings->sCurrencyFormat." Generated Over The Past 30 Days";


	$title = new title( $titlestring );

		//die();

		//array with data for chart joined bar

		$data_revenue = array();

		

		//data for x axis (dates)

		$x_labels = array();

		foreach ($list as $date => $value) {

			$data_revenue[] = $value['revenue'];			

			$x_labels[] = (string) substr($date, 8,2);

		}

		

		//create new bar (joined users)

		$bar = new bar_glass();

		//set bar color

		$bar->colour('#009933');

		//bar description and description's text size

		$bar->key('Revenue', 12);

		//set array with values

		$bar->set_values( $data_revenue );

		$bar->set_tooltip('$'."#val#" );

		

	

		

		//create x axis

		$x = new x_axis();

		$x->set_colours('#666666','#cccccc');

		

		//set some little left side offset

		$x->set_offset( 10 );

		//set data for labels on x axis

		$x->set_labels_from_array( $x_labels );

		//create y axis

		$y = new y_axis();

		$y->set_colours('#666666','#cccccc');

		//we calculate max value for y axis

		$max = (substr((int)$max, 0, 1) + 1) * pow(10,(strlen((int)$max)-1));

		$grade = pow(10,(strlen($max)-1));

		

		//echo "MAX#$max#$total#" .(substr($total, 0, 1) + 1) . '#' . pow(10,(strlen($total)-1)) . '#';

		//set range of y axis

		$y->set_range( 0, $max, $grade);

		//now create new chart	

		$chart = new open_flash_chart();

		//set background color

		$chart->set_bg_colour('ffffff');

		

		//add x axis

		$chart->set_x_axis( $x );

		//add y axis

		$chart->set_y_axis( $y );

		//set title

		$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );

		$chart->set_title( $title );

		//add first bar

		$chart->add_element( $bar );

		$chart->set_number_format(2, 1, 0, 0);

		

		

		//set x legend

		$x_legend = new x_legend( 'Days of Month' );

		$x_legend->set_style( '{font-size: 15px;  font-family: Verdana;color: #000000}' );

		$chart->set_x_legend( $x_legend );

		

		

		

		//set y legend

		$y_legend = new y_legend( 'Amount ($)' );

		$y_legend->set_style( '{font-size: 15px;  font-family: Verdana;color: #000000}' );

		$chart->set_y_legend( $y_legend );

		

		//output JSON string

		echo $chart->toString();

		

	}

	else{

		$title = new title( 'Total Number of Paid/Free Members');

		$pie = new pie();

		$pie->set_alpha(0.6);

		$pie->set_start_angle( 35 );

		$pie->add_animation( new pie_fade() );

		$pie->set_tooltip( '#val# of #total#<br>#percent# of 100%' );

		$pie->set_colours( array('#a020f0','#1C9E05') );

		

		//get free members

		$free=$dbo->getval("SELECT COUNT(*) FROM tblusers, tbluserlevels,tblmembershiplevels WHERE tblusers.nUser_id = tbluserlevels.nUser_ID AND tbluserlevels.nLeveL_ID = tblmembershiplevels.nLevel_ID and tblusers.nActive = 1 AND  LOWER(tblmembershiplevels.sLevel) = 'free' AND tblusers.nAdmin=0");

		if(!$free)

			$free=0;	

			//echo $free;

					

		//get paid members

		$paid=$dbo->getval("SELECT COUNT(*) FROM tblusers, tbluserlevels,tblmembershiplevels WHERE tblusers.nUser_id = tbluserlevels.nUser_ID AND tbluserlevels.nLeveL_ID = tblmembershiplevels.nLevel_ID and tblusers.nActive = 1 AND  LOWER(tblmembershiplevels.sLevel) != 'free' AND tblusers.nAdmin=0");

		if(!$paid)

			$paid=0;		

		//	echo $paid;

		$pie->set_values(

			 array (

			 new pie_value((int) $free,  "Free"),

   			 new pie_value((int) $paid,  "Paid")

			)	

		);

		$chart = new open_flash_chart();

		$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );

		$chart->set_title( $title );

		$chart->add_element( $pie );

		$chart->set_bg_colour('ffffff');	



		$chart->x_axis = null;



		echo $chart->toPrettyString();

	}

	

	

?>