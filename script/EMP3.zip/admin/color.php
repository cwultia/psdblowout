<?php
include_once('../inc.php');
global $dbo;	

?>

<html>
<head>
<title> 
<?php echo $admintitle?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color:;
}
-->
</style>
<link href="style.css" rel="stylesheet" type="text/css">
<?php include('inc-head.php') ?>
<script language=JavaScript src="common/js/picker/picker.js"></script>
</head>
<?php

if(isset($_POST[mcat]))
$_SESSION[mcat]=$_POST[mcat];

$act=$_GET[act];
$id=$_GET[id];
$id = $dbo->format($id);

if($act=="d")
{
$dbo->delete("delete from lcd_font where id='$id'");
$msg="Style Deleted!..";
$act="deleted";
}

if($act=="Add" && isset($_POST[Addit]))
{
$dbo->insert("insert into lcd_font(name,font,color,size) values('".$dbo->format($_POST[name])."','".$dbo->format($_POST[font])."','".$dbo->format($_POST[input0])."','".$dbo->format($_POST[size])."')",1);

$msg="Style Added!..";
$act="";
unset($act);
}

if($act=="Up")
{
$dbo->update("update lcd_font set name='".$dbo->format($_POST[name])."',font='".$dbo->format($_POST[font])."',color='".$dbo->format($_POST[input0])."',size='".$dbo->format($_POST[size])."' where id='".$dbo->format($_POST[dd])."'");
$msg="Style Updated!..";
$act="";
unset($act);
}

if($act=="e")
{
$rw=$dbo->getobject("select * from lcd_font where id='$id'");
}


?>
<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td valign="top"> 
      <?php include_once('top.php'); ?>
    </td>
  </tr>
  <tr> 
    <td valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="176" valign="top" bgcolor="#E1E1E1"> 
            <?php include("l.php");?>
          </td>
          <td align="center" valign="top"> <table width="100%" border="0" cellspacing="0" cellpadding="6">
              <tr> 
                <td height="300" valign="top"> 
                  <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" class="black-text">
                    <tr> 
                      <td valign="top"><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="white-text">
                          <tr> 
                            <td height="24" bgcolor="#CCCCCC" class="bodytxt">&nbsp;Style 
                              Listing <font color="#ffffff" size="1" face="Verdana, Arial, Helvetica, sans-serif"><b> 
                              <?php echo "[ $msg ]"?>
                              </b></font>&nbsp;&nbsp;</td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td valign="top" class="brdr"><table width="100%" border="0" cellspacing="1" cellpadding="0">
                          <tr align="center" valign="middle" class="bodytxt"> 
                            <td width="58%" height="24" bgcolor="#ebebeb" class="black">ITEM</td>
                            <td width="22%" height="24" bgcolor="#ebebeb"><b>ACTIONS</b></td>
                            <td width="20%" height="24" bgcolor="#ebebeb">APPROVE</td>
                          </tr>
                          <?php
							$c=1;
							$sql="SELECT * FROM lcd_font order by id";
							$result=$dbo->select($sql);
							while($row=$dbo->getobj($result)){
								$c++;
								if($c%2==0) $clr="#e0e0e0";
								else $clr="#E4E4E4";
							?>
                          <tr valign="middle" bgcolor="<?php echo $clr?>"> 
                            <td height="24" bgcolor="#ebebeb" class="bodytxt-small"> 
                              <li> 
                                <?php echo $row->name?>
                            </td>
                            <td height="24" align="center"  class="black">[ <a href="<?php echo $_SERVER['PHP_SELF']; ?>?act=e&id=<?php echo $row->id?>" class="admin">EDIT</a> 
                              ] &nbsp;[ <a href="<?php echo $_SERVER['PHP_SELF']; ?>?act=d&id=<?php echo $row->id?>" class="admin">DEL</a> 
                              ]</td>
                            <td align="center"  class="black"> 
                              <?php if ($row->status==0) { ?>
                              [ <a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=1&projid=<?php echo $row->id?>" class="admin" > 
                              disapprove</a><strong> </strong>] 
                              <?php } else { ?>
                              [ <a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=0&projid=<?php echo $row->id?>" class="admin"> 
                              Approve</a> ] 
                              <?php }?>
                            </td>
                          </tr>
                          <?php
					}
					?>
                          <tr valign="middle" align="center"> 
                            <td height="24" colspan="3" bgcolor="#ebebeb" class="llinks"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?act=a" class="admin">Add 
                              New Style</a></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
                  <?php
			if($act=="a")
			{
			?>
                  <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" class="black-text">
                    <tr> 
                      <td valign="top"><table width="100%"  border="0" cellpadding="2" cellspacing="2" class="white-text">
                          <tr> 
                            <td height="24" bgcolor="#CCCCCC" class="bodytxt">&nbsp;Add 
                              Style</td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td valign="top" class="brdr"><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="black-text">
                          <tr> 
                            <td valign="top"><table width="100%" border="0" cellspacing="2" cellpadding="0" class="bodytxt">
                                <form name=tcp_test method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?act=Add" enctype="multipart/form-data">
                                  <tr bgcolor="#f4f4f4"> 
                                    <td width="35%" align="right" class="black">Name 
                                      :</td>
                                    <td><input name="name" type="text" class="box" size="35"> 
                                    </td>
                                  </tr>
                                  <tr class="black"> 
                                    <td align="right" bgcolor="#f4f4f4">Font :</td>
                                    <td bgcolor="#f4f4f4">
									<select name="font">
									<option value="">Select Font</option>
									<option value="Arial">Arial</option>
									<option value="Verdana">Verdana</option>
									<option value="Helvetica">Helvetica</option>
									<option value="sans-serif">sans-serif</option>
									</select>
									</td>
                                  </tr>
                                  <tr class="black"> 
                                    <td align="right" bgcolor="#f4f4f4">Color 
                                      : </td>
                                    <td bgcolor="#f4f4f4"><input type="Text" name="input0">&nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['input0'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif"></a></td>
                                  </tr>
                                  <tr class="black"> 
                                    <td align="right" bgcolor="#f4f4f4">Size :</td>
                                    <td bgcolor="#f4f4f4"><input name="size" type="text" class="box" size="10"></td>
                                  </tr>
                                  <tr bgcolor="#f4f4f4"> 
                                    <td align="right"><b></b></td>
                                    <td> <input name="Addit" type="submit" class="Submit" value="Add it.."> 
                                    </td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
                  <?php
			}
			?>
                  <br> 
                  <?php
			if($act=="e")
			{
			?>
                   
                  <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" class="black-text">
                    <tr> 
                      <td valign="top"><table width="100%"  border="0" cellpadding="2" cellspacing="2" class="white-text">
                          <tr> 
                            <td height="24" bgcolor="#CCCCCC" class="bodytxt">&nbsp;Update 
                              Style</td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td valign="top" class="brdr"><table width="100%" border="0" cellspacing="1" cellpadding="0" class="bodytxt">
                          <form name=tcp_test method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?act=Up" enctype="multipart/form-data">
                            <tr bgcolor="#f4f4f4"> 
                              <td align="right" class="black">Name :</td>
                              <td><input name="name" type="text" class="box" size="35" value=<?php echo $rw->name;?>>
                                <input type="hidden" name="dd" value="<?php echo $rw->id?>"> 
                              </td>
                            </tr>
                            <tr class="black"> 
                              <td align="right" bgcolor="#f4f4f4">Font :</td>
                              <td bgcolor="#f4f4f4"> 
<select name="font">
<option value="">Select Font</option>
<option value="Arial" <?php if($rw->font=="Arial") { echo "selected"; }?>>Arial</option>
<option value="Verdana" <?php if($rw->font=="Verdana") { echo "selected"; }?>>Verdana</option>
<option value="Helvetica" <?php if($rw->font=="Helvetica") { echo "selected"; }?>>Helvetica</option>
<option value="sans-serif" <?php if($rw->font=="sans-serif") { echo "selected"; }?>>sans-serif</option>
</select> 
								</td>
                            </tr>
                            <tr class="black"> 
                              <td align="right" bgcolor="#f4f4f4">Color : </td>
                              <td bgcolor="#f4f4f4">
							  <input type="text" name="input0" value=<?php echo $rw->color;?>>
                                &nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['input0'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif"></a></td>
                            </tr>
                            <tr class="black"> 
                              <td align="right" bgcolor="#f4f4f4">Size :</td>
                              <td bgcolor="#f4f4f4"><input name="size" type="text" class="box" size="10" value=<?php echo $rw->size;?>></td>
                            </tr>
                            <tr bgcolor="#f4f4f4"> 
                              <td width="35%" align="right"><b></b></td>
                              <td> <input name="Submit" type="submit" class="Submit" id="Submit" value="Update.."> 
                              </td>
                            </tr>
                          </form>
                        </table></td>
                    </tr>
                  </table>
                  <?php
			}
			?>
                 
                </td>
              </tr>
            </table></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td> <table width="100%" border="0" cellspacing="0" cellpadding="0">
       
        <tr> 
          <td> 
            <?php include_once('b.php'); ?>
          </td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
