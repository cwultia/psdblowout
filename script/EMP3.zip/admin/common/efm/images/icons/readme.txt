mini icons - famfamfam.com
Contact: mjames@gmail.com