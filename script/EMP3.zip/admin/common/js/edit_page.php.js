	
	
	function insMergeCode() {
		oList = document.getElementById('category');
		if (oList.selectedIndex == 0) return;
		var sCode = oList.options[oList.selectedIndex].value;
		oUtil.obj.insertHTML(sCode)
	}
	function disable_enable_nUnavailableForJoinedAfter() {
		if(document.form1.nUnavailableForJoinedAfter_checkbox.checked){
			document.form1.nUnavailableForJoinedAfter_month.disabled=false;
			document.form1.nUnavailableForJoinedAfter_year.disabled=false;
		}
		else{
			document.form1.nUnavailableForJoinedAfter_month.disabled=true;
			document.form1.nUnavailableForJoinedAfter_year.disabled=true;
		}
	}
	function toggle(ele,set){
		if(set == 'emailoption'){
			if(ele.checked == 1){
				document.getElementById('sendemailtext').style.display = 'block';
				document.getElementById('sendemailbody').style.display = 'block';
			}
			else{
				document.getElementById('sendemailtext').style.display = 'none';
				document.getElementById('sendemailbody').style.display = 'none';
				}
			}
	}
	function setDirectoryAction(sAction) {
		oForm = document.forms.form1;
		oList = document.getElementById('directory');
		if (oList.selectedIndex == 0 || oList.options[oList.selectedIndex].value == did) {
		 	alert ("Nothing to do!");
		 	return;
		 }
		 oForm.directoryaction.value = sAction;
		 oForm.directorynew.value = oList.options[oList.selectedIndex].value;
		 oForm.submit();
	}
	function disable_enable_nUnavailableForJoinedAfter(){
		if(document.form1.nUnavailableForJoinedAfter_checkbox.checked){
			document.form1.nUnavailableForJoinedAfter_month.disabled=false;
			document.form1.nUnavailableForJoinedAfter_year.disabled=false;
		}
		else{
			document.form1.nUnavailableForJoinedAfter_month.disabled=true;
			document.form1.nUnavailableForJoinedAfter_year.disabled=true;}
		}
	function videoaction(){
		if($('#videoact').val() == "new"){
			$('#newsel').show();
			$('#existingvids').attr('selectedIndex', 0).hide();
		}
		else if($('#videoact').val() == "existing"){
			$("#newsel").attr('selectedIndex', 0).hide();
			$('#existingvids').show();
			$('#remote').hide();
			$('#uploader').hide()
		}
		else{
			$("#newsel").attr('selectedIndex', 0).hide();
			$('#existingvids').attr('selectedIndex', 0).hide();
			$('#remote').hide();
			$('#uploader').hide()
			// Clear Select Values
		}
	}
	function newVideoOpt(){
		if($('#newsel').val() == 'upload'){
			//document.getElementById('uploader').style.display = 'block';
			$('#remote').hide();
			$('#uploader').show()
			$('#uploader').pluploadQueue({
				// General settings
				runtimes : 'gears,flash,silverlight,browserplus,html5',
				url : 'ajax/video_upload.php',
				max_file_size : '10000mb',
				chunk_size : '1mb',
				// Resize images on clientside if we can
				//resize : {width : 320, height : 240, quality : 90},
				// Specify what files to browse for
				filters : [{title : "Video files", extensions : "flv,mp4,mov"}],
				// Flash settings
				flash_swf_url : '../includes/plupload/js/plupload.flash.swf',
				// Silverlight settings
				silverlight_xap_url : '../includes/plupload/js/plupload.silverlight.xap',
				// PreInit events, bound before any internal events
				preinit : {},
				// Post init events, bound after the internal events
				init : {
				FileUploaded: function(up, file, response) {
					// Called when a file has finished uploading
					var obj = jQuery.parseJSON(response.response);
					console.log("my object: %o", obj)
					document.getElementById('uploader').style.display = 'none';
					document.getElementById('embedTable').style.display = 'block';
					var curhtml = document.getElementById('embedCodes').innerHTML;
					var newhtml = '[[video '+obj.id+']] - '+obj.name+'<br />';
					document.getElementById('embedCodes').innerHTML = newhtml;
					if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, ele.value);tinyMCE.activeEditor.focus();}
					else{tinyMCE.activeEditor.selection.setContent(ele.value);}
				},
				Error: function(up, args) {
					// Called when a error has occured
					//alert('[error] '+ args);
				}
			}
		});
			// Client side form validation
			$('#uploaderForm').submit(function(e) {
			var uploader = $('#uploader').pluploadQueue();
			
			uploader.init();
			uploader.bind('FilesAdded', function(up, files) {});
	
			// Files in queue upload them first
			if (uploader.files.length > 0) {
				// When all files are uploaded submit form
				uploader.bind('StateChanged', function() {
					if (uploader.files.length === (uploader.total.uploaded + uploader.total.failed)) {
						$('form')['name'].submit();
					}
				});
				uploader.start();
			}
			else {alert('You must queue at least one file.');}
			return false;
		});
			return;
		}
		if(document.getElementById('newsel').value=='remote'){
			$('#remote').show();
			$('#uploader').hide();
		}
		else{
			$('#remote').hide();
			$('#uploader').hide()
		}
	}	
	function getExistingEmbed(ele){
		var ele2 = document.getElementById('embedCodes');
		document.getElementById('embedTable').style.display = 'block';
		var curhtml = ele2.innerHTML;
		if(curhtml.indexOf(ele.options[ele.selectedIndex].id) == -1){
			var newhtml = curhtml+'<span>'+ele.value+' - '+ele.options[ele.selectedIndex].id+'</span><br />';
			if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, ele.value);tinyMCE.activeEditor.focus();}
			else{tinyMCE.activeEditor.selection.setContent(ele.value);}
			ele2.innerHTML = newhtml;
		}
	}
	function addRemote(){
		//var dataString = 'sVideoURL='+ remoteVideo.elements["sVideoURL"].value;
		var dataString = "sVideoURL=" + $("#sVideoURL").val();
		$.ajax({
			type: "POST",
			url: "ajax/video_remote.php",
			data: dataString,
			success: function(response) {
				var obj = jQuery.parseJSON(response);
		  		if(obj.error){
					$('#ajaxError').html(obj.error.message);
				}
				else{
					$('#remote').hide()
					$('#embedTable').show()
		  			$('#embedCodes').append(obj.data.message+'<br />');
		  			$("#newsel").attr('selectedIndex', 0);
		  			$("#sVideoURL").val('');
		  			if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, '[[video '+obj.id+']]');tinyMCE.activeEditor.focus();}
					else{tinyMCE.activeEditor.selection.setContent('[[video '+obj.id+']]');}
			  }
			}
		});
		return false;
	}
	function updateLinkName(ele){
		document.getElementById('pagename').innerHTML = ele.value.replace(/\s/g, "");
	}
	