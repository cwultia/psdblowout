// JavaScript Document
	// jquery form errors
	errEqualTo='&nbsp;Please enter the same value again!';
	errRequired='&nbsp;The field is mandatory!';
	errRemote='';
	errEmail='&nbsp;Please enter a valid email address!';
	errUrl='&nbsp;Please enter a valid URL!';
	errDate='&nbsp;Please enter a valid date!';
	errDateISO='';
	errNumber='&nbsp;Please enter a valid amount (e.g. 10.00)!';
	errDigits='&nbsp;Please insert a number!';
	errLinkv='';
	errCreditCard='';				
	errAccept='';
	errMaxLength='';
	errMinLength='&nbsp;Please enter at least 6 characters!';
	errRangeLength='';
	errRangeValue='';
	errMaxValue='&nbsp;The max value is 100,000!';
	errMinValue='';
	
	page_title = document.title;
	
	function getServerTime() {

		var monthNames = new Array("January", "February", "March", 
		"April", "May", "June", "July", "August", "September", 
		"October", "November", "December");

		var strTime = $('#serverTime').val();
		var time = new Date( strTime );

		time.setSeconds( time.getSeconds() + 20 );

		var strTime = monthNames[ time.getMonth() ] + ' ' + time.getDate() + ', ' + time.getFullYear()+ ', '+time.getHours();
		
		if( time.getMinutes()<10 ){
			strTime = strTime+':0'+time.getMinutes();
		} else {
			strTime = strTime+':'+time.getMinutes()
		}
		
		
		$('#clock').html(strTime);
		$('#serverTime').val(time.toString());
		setTimeout(getServerTime, 20000);
	}
	
	// admin menus
	/*jQuery(function(){
		$("ul.sf-menu").supersubs({ 
			minWidth:    5,   	// minimum width of sub-menus in em units 
			maxWidth:    50,   	// maximum width of sub-menus in em units 
			extraWidth:  1     	// extra width can ensure lines don't sometimes turn over 
								// due to slight rounding differences and font-family 
			}).superfish();
	});*/
	
	function redirect(url){window.location = url;}
	function keepAlive(maxIdle,lastActive){
		var unix = getCookie('LAST_ACTIVITY');
		var expireTime = lastActive + maxIdle;
		var timeRemaining = expireTime - unix;
		var alertTime = timeRemaining - 58;
		setTimeout(displayKeepAlive,alertTime*1000);
	}
	function playNotify(){
		var audio = new Audio('common/js/timeout-notify.mp3');
		audio.play();
	}
	function displayKeepAlive(){
		playNotify();
		$.fn.countdown = function (callback, duration) {
   			var Message = '<span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 20px 0;"></span>'+
			'Your Session will expire in '+ duration + 
			' seconds ...<br/>Stay Logged In?';
   			
    		var container = $(this[0]).html(Message);
    		countdown = setInterval(function () {
			if (--duration) {
					var Message = '<span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 20px 0;"></span>'+
					'Your Session will expire in '+ duration + 
					' seconds ...<br/>Stay Logged In?';
					container.html(Message);
					// New Nofity Alert and settings
					if(($("#dialog-confirm").data('bs.modal') || {}).isShown){
						var toggle_title = 'Attention Required ...';
		
						if(document.title == page_title){document.title = toggle_title;}
						else{document.title = page_title;}
					
					if(duration >=5 ){
						if(duration % 5 ===0){playNotify();}
					}
					else{playNotify();}
					}
					else{document.title = page_title;}
				}
			else {
					clearInterval(countdown);
					var Message = '<span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 20px 0;"></span>'+
					'Your Session Has Expired.';
					container.html(Message);
					callback.call(container);   
				}
    		// Run interval every 1000ms (1 second)
    	}, 1000);
		};
		$('#dialog-confirm').on('show.bs.modal', function() {
        	$("#keepAlive_Stay").click(function(e) {
					jQuery.ajax({url: 'ajax/functions.php?act=keep-alive',method: 'GET'})
					.done(function (response) {
						if( response == 'session-expired' ) {
							keepAliveLogout('expired');
							return;
						}
						result = jQuery.parseJSON(response);
						clearInterval(countdown);
						document.cookie="LAST_ACTIVITY="+result.lastActivity;
						keepAlive(result.maxIdle,result.lastActivity);
					})
					$('#dialog-confirm').modal('hide');
			});
			$("#keepAlive_Out").click(function(e) {keepAliveLogout()});
		});
		$('#dialog-confirm').modal('show');
		

		// Use p.countdown as container, pass redirect, duration, and optional message
		$(".countdown").countdown(sessionExpired, 60);

		// Function to be called after 5 seconds
		function sessionExpired () {keepAliveLogout('expired');}
		
	}
	function keepAliveLogout(type){
		
		baseName = window.location.pathname.substring(window.location.pathname.lastIndexOf("/")+1) || "index.php";
		qs = window.location.search;
		redirectUrl = encodeURIComponent(baseName+qs);
		//alert(redirectUrl);
			jQuery.ajax({url: 'ajax/functions.php?act=keep-alive&v=false&type='+type+'&redirect='+redirectUrl,method: 'GET'})
			.done(function (response) {
				result = jQuery.parseJSON(response);
				//console.log(result);
				redirect(result);
			})	
	}
	
	// Close Button For Notification Messages
	function closeNotify(ele){$(ele).parent().hide(1000);}
	
	function updateSupportEmail(id,lkey){
				$('#'+id+'_message').html('');
				email = $('#'+id).val();
				url = "http://licensing.easymemberpro.com/remote.php?cmd=UPDATE-EMAIL&key="+lkey+'&email='+email;
				$.ajax({ type: "GET",   
         			url: "ajax/ajax-proxy.php?url="+url ,   
         			async: false,
         			success : function(data){
						if(data == 'SUCCESS'){
							// Clear the license data for pageload.
							$.get( "ajax/functions.php?act=clearLicenseData");
					
							$('#'+id+'_message').html('<span class="success">Registered Support Email Updated Successfully</span>');
							
						}
						else{$('#'+id+'_message').html('<span class="error">FAILED:'+data+'</span>');}
        			}
				});
			}
	// Quick Start Guide Coding
	function completeQs(button){
				$.ajax({
					url: "ajax/functions.php?act=qs&funct=complete&step="+button.name,
					type:"get",
					success: function(data){
						$('#QS_'+button.name).html(data);
						$('#QS_'+button.name+'_go').hide();
						$('#QS_'+button.name+'_done').show();
					}
				});
			}
	function resetQs(button){
				$.ajax({
					url: "ajax/functions.php?act=qs&funct=reset&step="+button.name,
					type:"get",
					success: function(data){
						$('#QS_'+button.name).html(data);
						$('#QS_'+button.name+'_go').show();
						$('#QS_'+button.name+'_done').hide();
					}
				});
			}	
	function doQS(step){
				var obj = {}
				
				obj.settings = 'script_settings.php';
				obj.email = 'email_settings.php';
				obj.levels = 'member_levels.php';
				obj.processors = 'payment_processors.php';
				obj.plans = 'payment_plans.php?action=reset';
				obj.pages = 'page_management.php';
				obj.content = 'page_management.php?did=1&view=2';
	
				window.location = obj[step];
				
			}
	function disableQS(){
				$.ajax({
					url: "ajax/functions.php?act=qs&funct=hide",
					type:"get",
					success: function(data){
						$('#quickStartList').hide();
					}
				});
			}

	function getCookie( strCookieName ) {
		if ( document.cookie.length > 0 ) {
			strStart = document.cookie.indexOf( strCookieName + "=" );
			if ( strStart != -1 ) {
				strStart = strStart + strCookieName.length + 1;
				strEnd = document.cookie.indexOf(";",strStart);
				if ( strEnd == -1 ) strEnd = document.cookie.length;
				return unescape( document.cookie.substring( strStart, strEnd ));
			}
		}
		return false;
	}			