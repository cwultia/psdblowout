<?php
	include_once('../../../../conn.php');
	error_reporting(0);
	// This is the init file to load the tinymce file editor.
	// Some things must be set here to function properly.
	
	// $folder is the layout folder. Used To Load Css Into The Editor.
	$folder = $_GET['folder'];
	
	// Becuase the editor resides in the admin dir, we need to set a base url.
	// The base url defines where the particular editor content will be displayed.
	// This is important when setting links, and images, ect ...
	$base = $_GET['base']; 
	
	// Basetype is used to define whether to use absolute links, or relative links.
	// Relative Links are good for webpages, while absolute links must be used for html emails.
	$basetype = $_GET['linktype']; // a for absolute, or r for relative
	// This is used to turn off css inclusion.
	$css = $_GET['css'];
	
	if($_GET['css'] == 'no'){$css = 'no';}
	else{$css = 'yes';}
	
	header("content-type: application/x-javascript");
	if(!isset($base) || $base == ''){echo "alert('error: no document base specified. Please Contact Support.');";}
	?>
    
    // TinyMCE Full
        $(function() {tinymce.init({
            selector: ".tinymce_full",
            relative_urls : <?php echo ($basetype == 'r')?'true':'false' ?>,
        	remove_script_host : <?php echo ($basetype == 'r')?'true':'false' ?>,
        	document_base_url : '<?php echo $base ?>',
        	file_browser_callback : EMPFileBrowser,
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor"
            ],
            toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
            toolbar2: "print preview media | forecolor backcolor emoticons",
            image_advtab: true,
            
            templates: [{
                title: 'Test template 1',
                content: 'Test 1'
            }, {
                title: 'Test template 2',
                content: 'Test 2'
            }]
        });
	});

	
	function EMPFileBrowser(field_name, url, type, win) {
	  var width = $(document).width();
	  var height = screen.height;
	  
	  var popwidth = (width * 0.8);
	  var popheight = (height * 0.6);
	  tinyMCE.activeEditor.windowManager.open({
	      
		  file : "<?php echo $chkSsettings->sSiteURL ?>/admin/common/efm/efm-browser.php?field=" + field_name + "&url=" + url + "&type=" + type +"",
	      title : 'EMP File Manager',
	      width : popwidth,
	      height : popheight,
	      resizable : "yes",
	      inline : "yes",
	      close_previous : "yes"
	  }, {
	      window : win,
	      input : field_name
	  });
	  return false;
	}