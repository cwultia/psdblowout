// JavaScript Document

	$('#ReactivateLevel').on('show.bs.modal', function(e) {
		//get data-id attribute of the clicked element
		var id = $(e.relatedTarget).data('level-id');
		if( $(e.relatedTarget).data('href') == '#ReactivateLevel'){
			$(e.currentTarget).find('input[name="nAssignedLevel_ID"]').val(id);
			$('#datepicker').datetimepicker({
		format: pickerFormat,
		minView: 'month',
		endDate: pickerEnd, 
    	autoclose: true
	});
			
		}
	});
	$('#addPayment').on('show.bs.modal', function(e) {
		//get data-id attribute of the clicked element
		var id = $(e.relatedTarget).data('row');
		var row = JSON.parse($("#row_"+id).html());
		
		$("#payment_LevelName").html(row.sLevel);
		$("#payment_PlanName").html(row.sPlanName);
		$("#payment_userLevelId").val(row.nUserLevel_ID);
		$("#paymentPlanId").val(row.nPaymentPlan_ID);
		
		if(row.nOneTimePayment == '0'){
			$("#payment_LevelIdentifier").html('Subscription');
			$("#payment_LevelIdentifier2").html('Subscription');
			$("#recurring-instructions").show();
			$("#onetime-instructions").hide();
		}
		
		$("#payment_LevelIdentifierValue").html(row.sTransactionNumber);
		
		$("#expirePeriod").html(row.nRegularPeriod+' '+row.sRegularPeriod);
		$("#currentExpireDate").html(row.formattedExpireDate);
	});
	$('#sendEmail').on('show.bs.modal', function(e) {
		var id = $(e.relatedTarget).data('user-id');
		//populate the textbox
		$( "#sendEmailToId" ).val(id);
	});
	$('#recentEmail').on('show.bs.modal', function(e) {
		var id = $(e.relatedTarget).data('email-id');
		$.getJSON( "ajax/functions.php?act=loadRecentEmail&id="+id,function(data){
			$('#recentEmail_Subject').html(data.sSubject);
			$('#recentEmail_Message').html(data.sBodyHtml);
			});
	});
	$('#editLevel').on('show.bs.modal', function(e) {
		var id = $(e.relatedTarget).data('id');
		var modalId = $(e.relatedTarget).data('modal');
		var ddiv = $('#LevelEdit_'+id).html();
		// Insert The data into the dialog element
		$("#model-form-container").html(ddiv);
		// Assign Txn id for Auto Suggest
		$("#Model-Form input[name=DateActive]").attr('id','datepicker');
		$("#Model-Form input[name=DateExpires]").attr('id','datepicker1');
		
		$( "#EditLevelId" ).val(id);
		$('#datepicker').datetimepicker({
		format: pickerFormat,
		minView: 'month',
		endDate: pickerEnd, 
    	autoclose: true
	});
	$('#datepicker1').datetimepicker({
		format: pickerFormat,
		minView: 'month',
		endDate: pickerEnd, 
    	autoclose: true
	});
		
	});
	// Old Functions - May still be active
	
	// Resend Login Deatils Functions
	function resendLogin() {window.frames.runcode.location.replace('sendlogin.php?userid=<?php echo $user_id ?>');}
	function showResendMsg(type){
		if(type == 'msg'){$("#msgResend").addClass('green').html('Login Details Sent Successfully!');}
		else{$("#msgResend").addClass('error').html('Failed To Send Login Information!');}
	}
	// Used To Toggle Boxes For Editing
	function showEdit(box,act){
		if(box == 'profile'){
			if(act == 'edit'){
				$("#profileShow").hide();
				$("#profileEdit").show();
			}
			if(act == 'show'){
				$("#profileShow").show();
				$("#profileEdit").hide();
			}
		}
		if(box == 'account'){
			if(act == 'edit'){
				$("#accountShow").hide();
				$("#accountEdit").show();
			}
			if(act == 'show'){
				$("#accountShow").show();
				$("#accountEdit").hide();
			}
		}
		if(box == 'comments'){
			if(act == 'edit'){$("#commentsEdit").show();}
			if(act == 'show'){
				$("#comments").val('');
				$("#commentsEdit").hide();
			}
		}
		if(box == 'affiliate'){
			if(act == 'edit'){
				$("#affiliateShow").hide();
				$("#affiliateEdit").show();
			}
			if(act == 'show'){
				$("#affiliateShow").show();
				$("#affiliateEdit").hide();
			}
		}
		if(box == 'customfields'){
			if(act == 'edit'){
				$("#customfieldsShow").hide();
				$("#customfieldsEdit").show();
			}
			if(act == 'show'){
				$("#customfieldsShow").show();
				$("#customfieldsEdit").hide();
			}
		}
		return false;
	}
	
	function getPaymentPlansByLevel(level){
		levelId = $('#'+level.id).val();
		$.getJSON( "ajax/functions.php?act=getPaymentPlansByLevel&level="+levelId,function(data){
			//console.log(data);
			$('#paymentPlan').empty();
			$.each(data,function(index,value){
				$('#paymentPlan').append($("<option></option>").attr("value",value.nPaymentPlan_ID).text(value.sPlanName));
				
			});
			//
			});
	}
	
	
	// Used to Load Modal Box For Member Level Reactivate
			
	function editLevel(id){
		
		// This Function Grabs The Pre-defined html for the edit level dialog box.
		// It sets special functions, builds the dialog box, and wraps it all in a form
		// to send to actions.php
		
		// Grab The Populated Form
		var ddiv = document.getElementById("LevelEdit_"+id).innerHTML
		
		// Insert The data into the dialog element
		$("#model-form-container").html(ddiv);
		
		// Assign Txn id for Auto Suggest
		$("#Model-Form input[name=Txn]").attr('id','Txn');
		
		// Assign The Picker Class
		$("#Model-Form input[name=DateActive]").addClass('datepicker');
		$("#Model-Form input[name=DateExpires]").addClass('datepicker');
		
		// Register Picker
		$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		
		// Set the dialog title
		var title = $("#EditLevel h1.dialog-title").html()
		
		$( "#EditLevel" ).dialog('option','title',title).dialog( "open" );
		// Launch the Dialog Box
		$( "#EditLevel" ).dialog( "open" );
		
		$( "#EditLevelId" ).val(id);
		return false;
	}
	
		
	function setEmailType(){
		checked = $('input[name=emailType]:checked', '#sendEmailModal').val()
		
		if(checked == 'html'){tinyMCE.execCommand('mceAddEditor',true,'email_message');}
		else{tinyMCE.execCommand('mceRemoveEditor',true,'email_message');}
	}
	
	// Auto Suggest Lookup
	function lookup(inputString,file,suggestions,autosuggestionlist) {
    if(inputString.length == 0) {
        // Hide the suggestion box.
        $(suggestions).hide();
        
    } else {
        $.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
            if(data.length >0) {
                $(suggestions).show();
                $(autosuggestionlist).html(data);
            }
        });
    }}
	// Auto Suggest chosen
	function fill(thisValue,id,suggestions,thisValueId) {
		$(id).val(thisValue);
		$(suggestions+'Hidden').val(thisValueId);
		$(suggestions).hide();
	}