function initimages() {
//	if (navigator.appName == "Microsoft Internet Explorer") {
		standard = new MakeArray(9);
		over = new MakeArray(9);
		words = new MakeArray(9);
	
		standard[1].src="images/mm.jpg";
		standard[2].src="images/am.jpg";
		standard[3].src="images/pm.jpg";
		standard[4].src="images/ss.jpg";

		over[1].src="images/mm.jpg";
		over[2].src="images/am.jpg";
		over[3].src="images/pm.jpg";
		over[4].src="images/ss.jpg";

//	}
	
}

function MakeArray(n) {
	this.length = n+1;
	for (var i = 0; i<=n; i++) {
		this[i] = new Image();
	}
	return this;
}
if(navigator.userAgent.substring(0,9)>="Mozilla/3") initimages();

function msover(num) {
if(navigator.userAgent.substring(0,9)>="Mozilla/3") {
	if(num==1) RRp.src = over[1].src;
	else if(num==2) BBp.src = over[2].src;
	else if(num==3) CCp.src = over[3].src;
	else if(num==4) DDp.src = over[4].src;
}
}
   

function msout(num) {
if(navigator.userAgent.substring(0,9)>="Mozilla/3") {
	if(num==1) RRp.src = standard[1].src;
	else if(num==2) BBp.src = standard[2].src;
	else if(num==3) CCp.src = standard[3].src;
	else if(num==4) DDp.src = standard[4].src;
}
}

function clikker1(a,b,c,d,f,g,h,i) {
	if (a.style.display =='') {
		a.style.display = 'none';
	}
	else {
 		a.style.display='';
		b.style.display = 'none';
		c.style.display = 'none';
		d.style.display = 'none';


		f.src = over[1].src;
		g.src = standard[2].src;
		h.src = standard[3].src;
		i.src = standard[4].src;

	}
}

function clikker2(a,b,c,d,f,g,h,i) {
	if (a.style.display =='') {
		a.style.display = 'none';
	}
	else {
 		a.style.display='';
		b.style.display = 'none';
		c.style.display = 'none';
		d.style.display = 'none';

		f.src = standard[1].src;
		g.src = over[2].src;
		h.src = standard[3].src;
		i.src = standard[4].src;

	}
}

function clikker3(a,b,c,d,f,g,h,i) {
	if (a.style.display =='') {
		a.style.display = 'none';
	}
	else {
 		a.style.display='';
		b.style.display = 'none';
		c.style.display = 'none';
		d.style.display = 'none';


		f.src = standard[1].src;
		g.src = standard[2].src;
		h.src = over[3].src;
		i.src = standard[4].src;

	}
}

function clikker4(a,b,c,d,f,g,h,i) {
	if (a.style.display =='') {
		a.style.display = 'none';
	}
	else {
 		a.style.display='';
		b.style.display = 'none';
		c.style.display = 'none';
		d.style.display = 'none';

		f.src = standard[1].src;
		g.src = standard[2].src;
		h.src = standard[3].src;
		i.src = over[4].src;

	}
}

function nsloadingir() {
// setting up layers for Netscape 4.x and above
if(navigator.appName == "Netscape" && parseInt(navigator.appVersion)>=4) {
		document.layers["HeadTop"].top = 5;
		document.layers["Head1"].top = document.layers["HeadTop"].top+document.layers["HeadTop"].document.height-4;
		//document.layers["Head1"].top = 105;
		document.layers["Menu1"].top = document.layers["Head1"].top+document.layers["Head1"].document.height;
		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Menu2"].top = document.layers["Head2"].top+document.layers["Head2"].document.height;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Menu3"].top = document.layers["Head3"].top+document.layers["Head3"].document.height;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["Menu4"].top = document.layers["Head4"].top+document.layers["Head4"].document.height;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top-4;

		document.layers["HeadTop"].visibility = "show";
		document.layers["Head1"].visibility = "show";
		document.layers["Head2"].visibility = "show";
		document.layers["Head3"].visibility = "show";
		document.layers["Head4"].visibility = "show";
		document.layers["HeadBottom"].visibility = "show";

	}
	return true;
}

function nsloading() {
// setting up layers for Netscape 4.x and above
if(navigator.appName == "Netscape" && parseInt(navigator.appVersion)>=4) {
		document.layers["HeadTop"].top = 80;
		document.layers["Head1"].top = document.layers["HeadTop"].top+document.layers["HeadTop"].document.height-4;
		//document.layers["Head1"].top = 105;
		document.layers["Menu1"].top = document.layers["Head1"].top+document.layers["Head1"].document.height;
		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Menu2"].top = document.layers["Head2"].top+document.layers["Head2"].document.height;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Menu3"].top = document.layers["Head3"].top+document.layers["Head3"].document.height;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["Menu4"].top = document.layers["Head4"].top+document.layers["Head4"].document.height;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top-4;

		document.layers["HeadTop"].visibility = "show";
		document.layers["Head1"].visibility = "show";
		document.layers["Head2"].visibility = "show";
		document.layers["Head3"].visibility = "show";
		document.layers["Head4"].visibility = "show";
		document.layers["HeadBottom"].visibility = "show";

	}
	return true;
}

function nsmouseover(n) {
	if(parseInt(navigator.appVersion)>=4) {
		if(n==1) document.layers["Head1"].document.images[0].src = over[1].src;
		else if(n==2) document.layers["Head2"].document.images[0].src = over[2].src;
		else if(n==3) document.layers["Head3"].document.images[0].src = over[3].src;
		else if(n==4) document.layers["Head4"].document.images[0].src = over[4].src;

	}
	else if(parseInt(navigator.appVersion)==3){
		if(n==1) document.images["Head1"].src=over[1].src;
		else if(n==2) document.images["Head2"].src=over[2].src;
		else if(n==3) document.images["Head3"].src=over[3].src;
		else if(n==4) document.images["Head4"].src=over[4].src;
	}
}

function nsmouseout(n) {
	if(parseInt(navigator.appVersion)>3) {
		if(n==1) document.layers["Head1"].document.images[0].src = standard[1].src;
		else if(n==2) document.layers["Head2"].document.images[0].src = standard[2].src;
		else if(n==3) document.layers["Head3"].document.images[0].src = standard[3].src;
		else if(n==4) document.layers["Head4"].document.images[0].src = standard[4].src;
	}
	else if(parseInt(navigator.appVersion)==3){
		if(n==1) document.images["Head1"].src=standard[1].src;
		else if(n==2) document.images["Head2"].src=standard[2].src;
		else if(n==3) document.images["Head3"].src=standard[3].src;
		else if(n==4) document.images["Head4"].src=standard[4].src;
	}
}
function nsclikker1() {
if(parseInt(navigator.appVersion)>3) {
	if( document.layers["Menu1"].visibility == "hide") {
		document.layers["Menu1"].visibility = "show";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "hide";

		document.layers["Head2"].top = document.layers["Menu1"].top+document.layers["Menu1"].document.height;
		document.layers["Head3"].top = document.layers["Head2"].top+document.layers["Head2"].document.height-4;
		document.layers["Head4"].top = document.layers["Head3"].top+document.layers["Head3"].document.height-4;
		document.layers["HeadBottom"].top = document.layers["Head4"].top+document.layers["Head4"].document.height-4;

	}
	else {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "hide";


		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top-4;

	}
}
}
function nsclikker2() {
if(parseInt(navigator.appVersion)>3) {
	if( document.layers["Menu2"].visibility == "hide") {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "show";

		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "hide";


		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top+document.layers["Menu2"].document.height;
		document.layers["Head4"].top = document.layers["Head3"].top+document.layers["Head3"].document.height-4;
		document.layers["HeadBottom"].top = document.layers["Head4"].top+document.layers["Head4"].document.height-4;


	}
	else {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "hide";

		
		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top-4;

	}
}
}
function nsclikker3() {
if(parseInt(navigator.appVersion)>3) {
	if( document.layers["Menu3"].visibility == "hide") {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "show";
		document.layers["Menu4"].visibility = "hide";


		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Head4"].top = document.layers["Menu3"].top+document.layers["Menu3"].document.height;
		document.layers["HeadBottom"].top = document.layers["Head4"].top+document.layers["Head4"].document.height-4;


	}
	else {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "hide";

		
		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top-4;

	}
}
}

function nsclikker4() {
if(parseInt(navigator.appVersion)>3) {
	if( document.layers["Menu4"].visibility == "hide") {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "show";


		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top+document.layers["Menu4"].document.height;


	}
	else {
		document.layers["Menu1"].visibility = "hide";
		document.layers["Menu2"].visibility = "hide";
		document.layers["Menu3"].visibility = "hide";
		document.layers["Menu4"].visibility = "hide";

		
		document.layers["Head2"].top = document.layers["Menu1"].top-4;
		document.layers["Head3"].top = document.layers["Menu2"].top-4;
		document.layers["Head4"].top = document.layers["Menu3"].top-4;
		document.layers["HeadBottom"].top = document.layers["Menu4"].top-4;

	}
}
}
