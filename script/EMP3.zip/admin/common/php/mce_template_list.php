<?php
	include_once ('../../../conn.php');
	include_once ('../../../functions.php');
	
	 
	$sql = "SELECT * FROM `tblfiles` WHERE stype = 'jpg' OR stype = 'jpeg' OR stype = 'gif' OR stype = 'png'";
	$res = $dbo->select($sql);
	$js = 'var tinyMCETemplateList = new Array(
		// Name, URL, Desc
	["test","page-templates/test.html","This is a Test Html Template Page"],
	["test2","common/js/tiny_mce/templates/test2.html","This is a Test2 Html Template Page"]';
	$js = rtrim($js, ',').');';
	
	// Make output a real JavaScript file!
	header('Content-type: text/javascript'); // browser will now recognize the file as a valid JS file
	
	// prevent browser from caching
	header('pragma: no-cache');
	header('expires: 0'); // i.e. contents have already expired
	echo $js;
?>