<?php
	include_once '../conn.php';
	include_once '../functions.php';
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Manage Coupons';
	$css = <<<EOT
<!--page level css -->
<link href="vendors/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen" />
<!--end of page level css-->
EOT;

// Add Coupon to database
if ( isset($_POST['add']) ) {
	
	//$nExpiryDate = explode('/', $_POST['nExpiryDate']);
	//$nExpiryDate = $nExpiryDate[2] . $nExpiryDate[0] . $nExpiryDate[1];

	$sql = "INSERT INTO tblcoupons (
	sCouponCode,
	nExpiryDate,
	nQtyAvailable,
	bActive
	) VALUES (
	'" . $dbo->format($_POST['sCouponCode']) . "',
	" . $dbo->format(fStoreDate($chkSsettings->nDateFormat, $_POST['nExpiryDate'])) . ",
	" . $dbo->format($_POST['nQtyAvailable']) . ", 
	1
	)";		

	$dbo->insert($sql);
	
	$message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>The coupon code was added successfully</div>';}

// Update Member Levels
if ( isset($_POST['Update']) ) {
	//die(var_dump($_POST));
	foreach ($_POST as $key=>$value) {
		if (substr($key, 0, 12) == 'sCouponCode_') {
			$sql = "UPDATE tblcoupons SET sCouponCode='" . $dbo->format($value) . "' WHERE nCoupon_ID=" . substr($key, 12);
			$dbo->update($sql);
		}
		if (substr($key, 0, 12) == 'nExpiryDate_') {
			//$nExpiryDate = explode('/', $value);
			//$nExpiryDate = $nExpiryDate[2] . $nExpiryDate[0] . $nExpiryDate[1];
			$sql = "UPDATE tblcoupons SET nExpiryDate='" . $dbo->format(fStoreDate($chkSsettings->nDateFormat, $value)) . "' WHERE nCoupon_ID=" . substr($key, 12);
			//die($sql);
			$dbo->update($sql);
		}
		if (substr($key, 0, 14) == 'nQtyAvailable_') {
			$sql = "UPDATE tblcoupons SET nQtyAvailable='" . $dbo->format($value) . "' WHERE nCoupon_ID=" . substr($key, 14);
			$dbo->update($sql);
		}
	}
	
		// Update active/not active
		$sql = "UPDATE tblcoupons SET bActive=0";
		$dbo->update($sql);
		
		if (sizeof(($_POST['bActive']))) {	
			$values = implode(",", $_POST['bActive']);		
	
			$sql = "UPDATE tblcoupons SET bActive=1 WHERE nCoupon_ID IN (" . $values . ")";
			$dbo->update($sql);
			
			$message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>Coupon codes have been updated successfully</div>';
		}
	}

require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Payment Settings</li>
			<li class="active">Coupons</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title"> Add New Coupon </h3>
				</div>
				<div class="panel-body">
					<form name="form1"  id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<th>Coupon Code <font color="Red"> * </font></th>
									<td><input type="text" name="sCouponCode" id="sCouponCode" class="required uppercase_number"  style="width: 200px;" maxlength="10" /><br /><small>Must be capital letters and/or numbers only. Max of 10 characters. E.g. COUPON123</small></td>
								</tr>
								<tr>
									<th>Expiry Date</th>
									<td>
										<div class="col-sm-5">
             <div class='input-group date' id='coupon_expire'>
                 <input type="text" name="nExpiryDate" id="nExpiryDate" class="col-sm-3 form-control" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 year')));?>"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
									</td>
								</tr>
								<tr>
									<th>Qty Available <font color="Red"> * </font></th>
									<td ><input type="text" name="nQtyAvailable" id="nQtyAvailable" style="width: 50px;" class="required digits" maxlength="4" value="0" />
										<small>0 = Unlimited</small></td>
								</tr>
							</table>
						</div>
						<input type="submit" name="add" value="Add Coupon Code" class="btn btn-primary btn-responsive">
					</form>
				</div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title"> Existing Coupons </h3>
				</div>
				<div class="panel-body">
					<form name="form2" id="form2" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th>Coupon Code</th>
										<th>Expiry Date</th>
										<th>Qty Available</th>
										<th>Active?</th>
									</tr>
								</thead>
								<tbody>
									<?php
				$sql = "SELECT * FROM tblcoupons ORDER BY sCouponCode";
				$result = $dbo->select($sql);
				if ($result) {
					while ($row = $dbo->getobj($result)) {
						$pickers[] = $row->nCoupon_ID;
						$checked = ($row->bActive) ? 'checked="checked"' : '';
						
						?>
							<tr>
							<td ><input type="text" name="sCouponCode_<?php echo $row->nCoupon_ID ?>" value="<?php echo $row->sCouponCode ?>" style="width: 200px;" class="required" /></td>
							<td >
							<div class='input-group date'>
                 <input type="text" name="nExpiryDate_<?php echo $row->nCoupon_ID?>" id="nExpiryDate_<?php echo $row->nCoupon_ID?>" class="col-sm-3 form-control" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nExpiryDate);?>"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
			</td>
							
							<?php
							echo '
							</td>
							<td ><input type="text" name="nQtyAvailable_' . $row->nCoupon_ID . '" value="' . $row->nQtyAvailable . '" style="width: 50px" class="digits" /></td>
							<td  align="center"><input type="checkbox" name="bActive[]" value="' . $row->nCoupon_ID . '" ' . $checked . ' /></td>
						</tr>
						';
					}
				}
				else{echo '<tr><td colspan="4">No Coupons Exist.</td></tr>';}
				?>
								</tbody>
							</table>
						</div>
						<input type="submit" name="Update" value="Update Coupon Codes" class="btn btn-primary btn-responsive">
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<!--datetime picker-->
<script type="text/javascript" src="vendors/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="vendors/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
<script type="text/javascript">

		$(function() {
			$('#coupon_expire').datetimepicker({
		format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>',
		minView: 'month',
		endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?>', 
    	autoclose: true
	});
			
			<?php foreach ($pickers as $v){ ?>
				$('#nExpiryDate_<?php echo $v ?>').datetimepicker({
					format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>',
					minView: 'month',
					endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?>', 
    				autoclose: true
	});
					
			<?php } ?>
			$("#form1").validate();
			$("#form2").validate();
		});
		
		jQuery.validator.addMethod("uppercase_number", function(value, element) { 
		  return /^[A-Z0-9]*$/.test(value); 
		}, "Coupon code must contain capital letters and numbers only");
	</script> 
</body></html>