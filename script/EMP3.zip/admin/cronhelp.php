<?php
	include_once('../conn.php');
	ob_start();
	phpinfo(INFO_GENERAL);
	$out = ob_get_contents();
	ob_end_clean();
	//die($out);	
	$nStart = strpos($out, "Server API") + strlen("Server API");
	$nEnd = strpos($out, "\n", $nStart);
	$phpinstall = (strip_tags(substr($out, $nStart, $nEnd-$nStart)));
	
	//die($phpinstall);
		
	$cronfile = dirname(dirname(__FILE__))."/cron.php";
	$executable = is_executable($chkSsettings->sRootPath."/cron.php");
?>
<style>
	li {font-size:12pt; margin-bottom:5px}
</style>
<link rel="stylesheet" type="text/css" href="../admin/common/css/styles.css">
<div style="font-family:arial; margin-left:20px">
	<div style="font-size:18pt; margin-top:20px; margin-left:25px">Steps for setting up the Cron.php to run every night</div>
	<ul>
	  <li>Login to your site's <b>cPanel</b></li>
		<li>Click the <b>Cron jobs</b> icon</li>
		<li>Click <b>Standard</b> for the experience level</li>
		<?php if (strpos($phpinstall,'Apache')): ?>
			<li>Type: <span style="color:navy; font-weight:bold">lynx -dump <?php echo $sSiteURL ?>/cron.php</span> in the <b>Command to Run</b> field</li>
		<?php else: ?>
			<li>Type: <span style="color:navy; font-weight:bold"><?php echo PHP_BINDIR?>/php <?php echo $cronfile ?></span> in the <b>Command to Run</b> field</li>
		<?php endif; ?>
		<li>Select <b>0</b> for Minute(s)</li>
		<li>Select <b>0</b> for Hour(s) &mdash; the Cron will run at midnight (server time)<span style="color:red"> &lowast;</span></li>
		<li>Select <b>Every Day</b> for Day(s)</li>
		<li>Select <b>Every Weekday</b> for Weekday(s)</li>
		<li>Select <b>Every Month</b> for Month(s)</li>
		<li>Click <b>Save Crontab</b></li>
	</ul>
	<div style="margin-top:20px; margin-left:25px; color:red">&lowast; if you want the Cron to run at a different hour, select one of the other numbers (1 - 23)</div>
</div>
	

