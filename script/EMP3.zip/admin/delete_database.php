<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Delete Database Backups';
	$css = <<<EOT
<!--page level css -->

<!--end of page level css-->
EOT;
	
	if (isset($_POST['btnDelete'])) {
		if (!empty($_POST['del'])) {
			foreach ($_POST['del'] as $item) {
				unlink ('dump/'.$item);
			}
			$message = "<p class='success'>".count($_POST['del'])." file(s) deleted successfully</p>";
		}
	}
	function getBackupList() {
		$list = '';
		if ($handle = opendir('dump')) {
		    while (false !== ($file = readdir($handle))) {
		        if ($file != "." && $file != ".." && substr($file, strrpos($file,'.')+1) == 'gz') {
		            $list[] = $file;
		        }
		    }
		    closedir($handle);
		}
		if (!empty($list)) arsort($list);
		return $list;
	}
	require_once('header.php');
	?>
   <aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a> </li>
      <li>Database</li>
      <li class="active">Delete Backups</li>
    </ol>
  </section>
  <section class="content">
  <div class="col-md-12">
  	<?php echo isset($message) ? $message : '' ?>
	<form method="post" action="delete_database.php" onSubmit="return confirmDelete()">
	<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Database Management System</h3>
					</div>
					<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
	<?php
		// Get the list of all tables from the database '$dbName'
		$back = getBackupList();	
		$cells = 4;// Cells across (need to change cell width accordingly)
		if (!empty($back)) {	
			$i = 0;								
			foreach ($back as $item) {
				if ($i++ % $cells == 0) {
					if ($i == 1) 	echo "<tr>";
					else echo "</tr><tr>";
				}
			echo sprintf("<td><input type='checkbox' name='del[]' value='%s' id='%s' style='margin-bottom:0px; margin-right:5px'><label for='%s'>%s</label></td>", $item, $item, $item, $item);
		}	
			// Fill in missing table cells								 
			$start = ($i - intval($i / $cells) * $cells);
			if ($start > 0)
				for ($j = $start + 1; $j < $cells+1; $j++) echo "<td class='gridRow1'>&nbsp;</td>";
				echo "</tr>";									
		}
		else {
			echo "<tr><td>No Backups Found.</td></tr>";
		}
	?>
</table>
					</div>
					
					<input type="submit" name="btnDelete" value="Delete" class="btn btn-sm btn-primary btn-responsive">
			<input type="checkbox" id="checkAll" style="margin-left:10px" onClick="setChecks()">
			<label for="checkAll" style="padding-left:3px">Select All</label>
					</div></div>
					
	</form>
	
  
  </div>

</section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<style>
			LABEL {cursor:pointer}	
		</style>
		<script language="javascript" type="text/javascript" >
			function confirmDelete() {
				// Make sure something is checked
				oEl = document.getElementsByTagName('input');
				var bSelect = false;
				for (i=0; i<oEl.length; i++) {
					if (oEl[i].type == 'checkbox' && oEl[i].id != 'checkAll') bSelect |= oEl[i].checked;
				}
				
				if (bSelect) return confirm("Are you sure you want to delete the selected files?");	
				else return false;
			}
			
			function setChecks() {
				var bCheck = document.getElementById('checkAll').checked;
				oEl = document.getElementsByTagName('input');
				for (i=0; i<oEl.length; i++) {
					if (oEl[i].type == 'checkbox') oEl[i].checked = bCheck;
				}				
			}
			
		</script>
	</body>
</html>