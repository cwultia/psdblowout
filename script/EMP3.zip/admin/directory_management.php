<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Directory Management';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;
	
	function getRootFolder($folderId){
					
					if($folderId == '0' || $folderId == '1') return $folderId;
					
					// This is a sub folder.
					$parentId = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '$folderId';");
					
					if($parentId == '0' || $parentId == '1') return $parentId;
					
					// This is a second sub folder
					$subparentId = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '$parentId';");
					
					if($subparentId == '0' || $subparentId == '1') return $subparentId;
					else{
						
						// Something went wrong!
						die('something went wrong.');
						
						
					}
						
				}

	$ipp = (!empty($_GET['ipp'])) ? $_GET['ipp'] : 10;							// Items per Page
	$sort = (!empty($_GET['sort'])) ? $_GET['sort'] : 'nDirectory_ID';
	$sortdir = (!empty($_GET['sortdir'])) ? $_GET['sortdir'] : 'ASC';
	$start = (!empty($_GET['start'])) ? $_GET['start'] : 0;	

	// Set QueryString Values after post
	if (isset($_POST['Update'])) {
		$ipp = $_POST['ipp'];
		$sort = $_POST['sort'];
		$sortdir = $_POST['sortdir'];
		$start = $_POST['start'];
	}

	// Setup Options for Items per Page listing
	$aIPP = array('5', '10', '15', '20', '25', '50', '100');

	// Get Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels ORDER BY nOrder ASC , sLevel ASC";
	$rs = $dbo->select($sql);
	if(!empty($rs)) while ($row = $dbo->getarray($rs)){$aLevel[] = $row;}

	// Set directories that can't be deleted
	$nodelete = array('member');

 	$nopay = array('home', 'support', 'affiliates', 'profile-edit', 'affiliateemails', 'creport', 'graphics', 'sendemail', 'faq', 
	'contact', 'changepassword');

	/***************************/
	/* Process Folder Actions  */
	/***************************/
	//Add New Folder 
	if(isset($_POST['add_new_folder']))
	{
		// Process newFolder data, and remove invalid characters
		$invalids = '\'';
		
		$newFolder = str_replace($invalids,'',$_POST['newFolder']);
		
		
		$sql = "SELECT nLevel_ID FROM tbldirectories WHERE nDirectory_ID='" . $dbo->format($_POST["parentFolder"]) . "'";
		$rs = $dbo->select($sql);		
		$row = $dbo->getobj($rs);
		
		$sql2 = "SELECT nDirectory_ID FROM tbldirectories WHERE sDirectoryName = '".$dbo->format($newFolder)."' and nParent_ID='" . $dbo->format($_POST["parentFolder"]) . "'";
		$rs2 = $dbo->select($sql2);
		if (!empty($rs2)) 
			$message = "<span class='error'>Folder name already exists.  Please specify a new name.</span>";
		else {
		$sql = "insert into tbldirectories values('','" . $dbo->format($newFolder) . "','" . $dbo->format($newFolder) . "','" . ($row->nLevel_ID+1) . "','1','0','" . $dbo->format($_POST["parentFolder"]) . "')";
		$dbo->insert($sql, 1);
		$message = "<p class='success'>Folder has been added.</p>";
		}
	}
	
	// Update Folder
	if (isset($_POST['edit_folder']) && $_GET['act']=='modify' && isset($_GET['folderID'])) {
		
		if($_POST["parentFolder"]== $_GET['folderID']) $message = "<p class='success'>You can not add a folder to its own.</p>";
		else {
			
			// Update Directory Name
			$sql = "SELECT nLevel_ID FROM tbldirectories WHERE nDirectory_ID='" . $dbo->format($_POST["parentFolder"]) . "'";
			$rs = $dbo->select($sql);		
			$row = $dbo->getobj($rs);
			
			// Process newFolder data, and remove invalid characters
			$invalids = '\'';
		
			$newFolder = str_replace($invalids,'',$_POST['newFolder']);
				
			// hate this sprintf .. unnessessary. mysql uses its own type casting!
			/*$sql = sprintf("
			UPDATE tbldirectories 
			SET sDirectoryName = '%s', sDirectoryPath = '%s', nParent_ID = '%d' , nLevel_ID='%d'
			WHERE nDirectory_ID = '%s'", $dbo->format($newFolder), strtolower(str_replace(" ", "", $dbo->format($newFolder))),$dbo->format($_POST["parentFolder"]) ,($row->nLevel_ID+1),$dbo->format($_GET['folderID'])); */
				
			$sql = "
			UPDATE tbldirectories
			SET sDirectoryName = '".$dbo->format($newFolder)."', 
			sDirectoryPath = '".strtolower(str_replace(" ", "", $dbo->format($newFolder)))."', 
			nParent_ID = '".$dbo->format($_POST["parentFolder"])."' , 
			nLevel_ID='".($row->nLevel_ID + 1) ."' 
			WHERE nDirectory_ID = '".$dbo->format($_GET['folderID'])."'
			";
			//die($sql);
			$dbo->update($sql);
				
			// Need To Check If Directory Was Moved From Member to Main.
			// If so, any pages contained inside need to have level access rights removed.
				
			// Dont Forget Folders Go 3 Deep so we need to check parents up to 3 levels.
			// Main Id = 0, Member Id = 1 Both have parent of -1

			// New Folder Parent
			$newParent = $dbo->format($_POST["parentFolder"]);
				
				
			// Looking to see if new parent is associated with main or member.
				
			//die(var_dump(getRootFolder($newParent)));
				
			if(getRootFolder($newParent) == '0')
			{
					
					// This folder is going to the main directory!
					// Remove The Rights!
					$pids = '';
					
					$sql = "SELECT nPage_ID from tblpages WHERE nDirectory_ID = '".$dbo->format($_GET['folderID'])."';";
					$res = $dbo->select($sql);
					
					if($dbo->nr($res) >= 1)
					{
						
						while($row = $dbo->getobj($res)) $pids .= ' '.$row->nPage_ID.',';
						
						// Remove last comma.
						
						$pids = substr_replace($pids ,"",-1);
						
						// Lets Delete Em!
						$sql = "DELETE FROM tblpagelevels WHERE nPage_ID IN (".$pids." )";
						//die($sql);
						$dbo->delete($sql);
					}
					
				}
				
			$message = "<p class='success'>Folder has been updated.</p>";
		}
	}
	
	// DELETE FOLDER
	if ($_GET['act'] == 'del') {
		
		$sql = "SELECT nLevel_ID FROM tbldirectories WHERE nDirectory_ID='" . $dbo->format($_GET["did"]) . "'";
		$rs = $dbo->select($sql);		
		if(!empty($rs))
		$row = $dbo->getobj($rs);
		
		//if this directory has level 1
		if($row->nLevel_ID=='1')
		{		
				//Take the id of his childs folders , level 2
				$sql2 = "SELECT nDirectory_ID FROM tbldirectories WHERE nParent_ID='" . $dbo->format($_GET["did"]) . "' and nLevel_ID='2'";
				
				$rs2 = $dbo->select($sql2);		
				if(!empty($rs2))
				while($row2 = $dbo->getobj($rs2))
					$childFolders[]=$row2->nDirectory_ID;
				
				//delete childs pages for child folders
				$childFoldersId=implode(',',$childFolders);
				$sql3 = "delete FROM tblpages WHERE nDirectory_ID in (".$childFoldersId.")";
				$rs3 = $dbo->delete($sql3);						
				
				//delete his child folder , level2
				$sql4 = "DELETE FROM tbldirectories WHERE nDirectory_ID in (".$childFoldersId.")";
				$rs4 = $dbo->select($sql4);		

							
		}

		
		//delete childs pages for main folder
		$sql5 = "DELETE FROM tblpages WHERE nDirectory_ID ='".$dbo->format($_GET['did'])."'";
		$rs5 = $dbo->delete($sql5);	
		
		//delete main folder
		$sql = sprintf("DELETE FROM tbldirectories WHERE nDirectory_ID = '%s'", $dbo->format($_GET['did']));
		$dbo->delete($sql);
		$message = "<p class='success'>Folders and pages have been removed.</p>";
	}
	
	// UPDATE DIRECTORY DISPLAY
	if ($_GET['act'] == 'display') {
		$sql = sprintf("UPDATE tbldirectories SET bDisplay= '%s' WHERE nDirectory_ID = '%s'", $dbo->format($_GET['display']), $dbo->format($_GET['did']));		
		$dbo->update($sql);
	}
	
	// UPDATE MEMBERSHIP LEVEL
	if ( isset($_POST['Update']) ) {
		$dd = $_POST['dd'];				// nPage_ID
		$disp = $_POST['disp'];
		$mLvl = $_POST['mlevel'];		// nLevel_ID
		for ($i = 0; $i < count($_POST['dd']); $i++) {
			$sql = sprintf("UPDATE tbldirectories 
									SET nSortOrder = '%s'
									WHERE nDirectory_ID = '%s'", $dbo->format($disp[$i]), $dbo->format($dd[$i]));
			$dbo->update($sql);
		}
	}		

	require_once('header.php');
	$option=getFolders();
	//Put together QueryString
	$qs = sprintf("?start=%s&ipp=%s", $start, $ipp);			
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Content</li>
      <li class="active">Directories</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div style="color:navy">NOTE: Any active folder with at least 1 active page will appear in the menu as a drop-down</div>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Directory Management</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive"> 
            <!-- Start Content -->
            <form name="form1" method="post" action="directory_management.php">
              <input type="hidden" name="ipp" value="<?php echo $ipp?>" />
              <input type="hidden" name="sort" value="<?php echo $sort?>" />
              <input type="hidden" name="sortdir" value="<?php echo $sortdir?>" />
              <input type="hidden" name="start" value="<?php echo $start?>" />
              <input type="hidden" name="Update" value="1" />
              <table class="table table-striped table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Folder <a data-toggle="modal" data-href="#newFolder" href="#newFolder" > <img  style="margin-bottom:-9px;" src="images/folder_add.png" alt="Add Folder" title="Add Folder" border="0"/> </a></th>
                    <th>Page Count</th>
                    <th>Sort Order</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($option as $row  ){ ?>
                  <tr>
                    <td><?php
		if($row['nLevel_ID']=='1')echo "<img src='images/line.png' />";
		elseif($row['nLevel_ID']=='2')echo "<img src='images/line2.png' />"; ?>
                      <a href='page_management.php?did=<?php echo $row['nDirectory_ID']?>&start=0'><?php echo $row['sDirectoryName']?></a></td>
                    <td ><?php echo $row['pagecount'] ?></td>
                    <td ><span class="blue">
                      <input name="disp[]" type="text" class="box" size="3" value="<?php echo $row['nSortOrder'] ?>" />
                      <input type="hidden" name="dd[]" value="<?php echo $row['nDirectory_ID']; ?>" />
                      </span></td>
                    <td ><!-- Display -->
                      
                      <?php if ($row['bDisplay']) : ?>
                      <a href="directory_management.php<?php echo $qs ?>&display=0&did=<?php echo $row['nDirectory_ID'] ?>&act=display" class="bluenew" title="Display Page"> <img src="images/disp.jpg" alt="Display Page" width="16" height="16" border="0" class="iconspacing"></a>
                      <?php else : ?>
                      <a href="directory_management.php<?php echo $qs ?>&display=1&did=<?php echo $row['nDirectory_ID'] ?>&act=display" class="bluenew"  title="Don't Display"><img src="images/ddisp.jpg" alt="Don't Display" width="16" height="16" border="0" class="iconspacing"></a>
                      <?php endif; ?>
                      
                      <!-- Delete -->
                      
                      <?php if ($row['nDirectory_ID'] <= 4){ ?>
                      <img src="images/dropd.gif" alt="Cannot Delete this Page" width="16" height="16" border="0" />
                      <?php }else{?>
                      <a href="directory_management.php<?php echo $qs ?>&did=<?php echo $row['nDirectory_ID'] ?>&act=del" class="bluenew" OnClick="return cdel('<?php echo $row['sDirectoryName'] ?>');" title="Delete Directory"><img src="images/drop.jpg" alt="Delete Page" width="16" height="16" border="0" class="iconspacing"></a>
                      <?php } ?>
                      
                      <!-- Edit -->
                      
                      <?php if($row['nLevel_ID']!='0'){?>
                      <a href="#" title="Edit Directory" onClick="editDirectory(<?php echo $row['nDirectory_ID']?>, '<?php echo $row['sDirectoryName'] ?>','<?php echo $row['nParent_ID']?>')"> <img src="images/edit.jpg" alt="Edit Directory" width="16" height="16" border="0" class="iconspacing"></a>
                      <?php } ?></td>
                  </tr>
                  <?php } ?>
                  <tr>
                    <td colspan="4"><input type="submit" value="Update Sort" class="btn btn-primary btn-responsive"/></td>
                  </tr>
                </tbody>
              </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php require_once('footer.php');?>
<script src="vendors/modal/js/classie.js"></script> 
<script src="vendors/modal/js/modalEffects.js"></script>
<div class="modal fade in" id="newFolder" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
  <form action="" method="POST" id="formNewFolder" class="form-control">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title">Create New Directory</h4>
        </div>
        <div class="modal-body">
          <table class="table table-striped table-bordered table-hover">
            <tr>
              <th> Folder Name : </th>
              <td><input type="text" name="newFolder" class="required form-control" placeholder="Enter New Folder Name"/></td>
            </tr>
            <tr>
              <th>Folder Parent : </th>
              <td><select name="parentFolder" class="form-control select2">
                  <?php echo generateTreeFolder('','disabled');?>
                </select></td>
            </tr>
          </table>
        </div>
        <div class="modal-footer">
          <input type="hidden" name="add_new_folder" id="add_new_folder" />
          <button type="button" data-dismiss="modal" class="btn">Close</button>
          <input type="submit" name="submitBut" id="submitBut" value="Add" class="btn btn-primary btn-responsive"/>
        </div>
      </div>
    </div>
  </form>
</div>
<script type="text/javascript">
			function show(id)
			{
				if(document.getElementById(id))
						document.getElementById(id).style.display="";
				oForm = document.forms.formNewFolder;
				oForm.action="";
				oForm.submitBut.value="Add";
				oForm.parentFolder.selectedIndex='0';
				oForm.newFolder.value = "";
				document.getElementById('add_new_folder').name="add_new_folder";
			}
			function cdel(w) {
				var sMsg = "Are you sure you want to DELETE the directory\""+w+"\" \nand all the pages in it?";
				return confirm(sMsg);
			}
			
			function editDirectory(nID, sName,parentID) {
				if(document.getElementById('new_folder_div'))					
					document.getElementById('new_folder_div').style.display="";
				oForm = document.forms.formNewFolder;
				
				oForm.newFolder.value = sName;	
				for (opt in oForm.parentFolder.options)
				{
					
					if(oForm.parentFolder.options[opt].value==parentID)
					{
						rightindex=opt;
						break;
					}
				}		
				oForm.parentFolder.selectedIndex=rightindex;
				oForm.submitBut.value="Update";
				oForm.action="directory_management.php?act=modify&folderID="+nID;				
				document.getElementById('add_new_folder').name="edit_folder";
				oForm.newFolder.focus();
				
			}

			function openPopup(page) {	
				window.open(page,'','height=265,width=650,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');
			}
			
			function MM_openBrWindow(theURL,winName,features) {
				window.open(theURL,winName,features);
			}
			
			function updateIPP(oList) {
				var ipp = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=' + ipp;
				document.location = 'page_management.php' + qs;
			}
</script>
<link rel="stylesheet" type="text/css" href="common/css/styles.css" />
<style>
.iconspacing {
	margin-right:2px
}
</style>
<script type="text/javascript">				
$(document).ready(function() {
	$("#formNewFolder").validate();
});
</script>
</body></html>