<?php
include_once('../conn.php');
include_once('../functions.php');

if(isset($_POST['Update']))
{
$c=0;
if($_POST["txtBody"]==""){
$c++;
$sb=1;
}
if($c==0)
{
$sql = "update tblpromoemailsubject set ssubject='" . $dbo->format($_POST["txtBody"]) . "' where npromoemailsubject_id='" . $dbo->format($_POST["dd"])."'";

if($dbo->update($sql)){$qs = 'msg=Email Subject Updated Successfully';}
else{$qs = 'err=Database Error:'.$dbo->error;}

header("location:email_subject.php?$qs");

}
}

 
$rw=$dbo->getobject("select * from tblpromoemailsubject where npromoemailsubject_id='" . $dbo->format($_GET["id"])."'");


?>
<html>
<head>
<title><?php echo $admintitle; ?></title>
<?php include('inc-head.php') ?>
<script type="text/javascript">
function cdel(w) {
if(confirm("Delete Confirmation!..\n\n Are Sure that you want to delete this?.."))
{
	return true;
}
else
{
return false;
}
}
</script>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
    
    <tr>
      <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        <?php include_once('affiliateleft.php'); ?>      </td>
      <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"  valign="top" width="100%"><form name="frm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?id=<?php echo $_GET[id]?>" >
      <span style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">      </span>
      <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
        
          <tr>
            <td class="navRow1" nowrap="nowrap">Edit Email Subject Lines</td>
            <td width="100%" align="left">&nbsp;</td>
          </tr>
        
      </table>
      <table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
        
          <tr>
            <td class="gridHeader">Edit Email Subject Lines </td>
          </tr>
          
          <tr>
            <td valign="middle" class="gridRow2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="40%" valign="top">
                    <input name="txtBody" type="text" value="<?php echo $rw->sSubject?>" size="55">
                    <input type="hidden" name="dd" value="<?php echo $rw->nPromoEmailSubject_ID?>">
                    <span class="red">
                    <?php if($sb==1) { echo "[ Required ]"; }?>
                  </span></td>
                </tr>
            </table></td>
          </tr>
          
          
          <tr>
            <td class="gridFooter"><input class="inputSubmitb" name="Update" value="Save Changes" type="submit"></td>
          </tr>
        
      </table>
    </form>
    </td>
      </tr>
</table>
<?php include_once('b.php'); ?>
</body></html>