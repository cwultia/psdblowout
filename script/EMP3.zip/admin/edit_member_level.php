<?php
include_once '../conn.php';
include_once '../functions.php';
		

// Update Member Levels
	if ( isset($_POST['id']) ) {
			$sql = "
			UPDATE `tblmembershiplevels` 
			SET `sLevel` = '".$_POST['sLevel']."',
			`nActive` = '".$_POST['active']."',
			`nDisplayFront` = '".$_POST['display']."',
			`nTosRequired` = '".$_POST['requireTos']."',
			`sTosHtml` = '".storeHtmlToDb($_POST['tosHtml'])."',
			`sLevelDescription` = '".$_POST['sLevelDescription']."' 
			WHERE `tblmembershiplevels`.`nLevel_ID` =".$_POST['id']." LIMIT 1 ;";
			//die($sql);
			if($dbo->update($sql)){header("Location: member_levels.php?msg=".urlencode('Level Updated Successfully'));}
			else{header("Location: member_levels.php?err=".urlencode('There Was An Eror<br />'.$dbo->error));}
			
	}
else{
	// Check for Level Id
	if(!$_GET['id'] || $_GET['id'] == ""){header("Loction: member_levels.php?msg=No Member Level Selected");exit;}
	
	// Get the level data
	$sql = "SELECT * FROM tblmembershiplevels where nLevel_ID = '".$_GET['id']."'";
	$objLevel = $dbo->getobject($sql);
	$displaySettings = "none";
	$displayTosHtml = "none";
	if($objLevel->nTosRequired == 1){$tosChecked = "checked";$displayTosHtml = "block";}
	if($objLevel->nActive == 1){$activeChecked = "checked";$displaySettings = "block";}
	if($objLevel->nDisplayFront == 1){$displayChecked = "checked";}
	}

?>
<html>
<head>
    <title>Member Levels</title>
	<?php include ('inc-head.php')?>
		<script type="text/javascript">
		function toggle(ele1,ele2){
			if(ele1.checked){document.getElementById(ele2).style.display = 'block';}
			else{document.getElementById(ele2).style.display = 'none';}
		}
        </script>
        
        <?php
		if(get_option('use_mce') == '1'){
			$doc_base = $chkSsettings->sSiteURL .'/';
		
		?>
        <script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
        <script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base; ?>&linktype=r"></script>
		<?php } ?>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once 'top.php' ?>

    <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once 'settingsleft.php'; ?></td>

            <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">

                <!-- NAVIGATION -->

                <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td class="navRow1" nowrap="nowrap">Member Levels</td>
                    </tr>
                </table>
                
                <?php echo isset($message) ? $message : '' ?>

                <!-- ADD MEMBER LEVEL -->

                <form name="form1"  id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                    	<tr>
                            <td class="gridHeader" colspan="2">Edit Member Level<input name="id" type="hidden" value="<?php echo $objLevel->nLevel_ID ?>"></td>
                    	</tr>
                    	<tr>
                    		<td width="200" class="gridRow1">Level <font color="Red"> * </font> </td>
                    		<td class="gridRow1">
                    				<input name="sLevel" type="text" class="required" id="sLevel"  style="width: 200px;" value="<?php echo $objLevel->sLevel ?>"/>&nbsp;</td>
						</tr>
                    	<tr>
                    	  <td width="200" class="gridRow1">Description</td>
                    	  <td class="gridRow1"><textarea name="sLevelDescription" id="sLevelDescription" cols="60" rows="5"><?php echo $objLevel->sLevelDescription ?></textarea></td>
                  	  </tr>
                    	<tr>
                    	  <td width="200" valign="top" class="gridRow1">Require Tos?</td>
                    	  <td class="gridRow1"><input name="requireTos" type="checkbox" id="requireTos" onChange="toggle(this,'tosHtmlEditor')" value="1" <?php echo $tosChecked ?>>
                   	        <div id="tosHtmlEditor" style="display:<?php echo $displayTosHtml ?>">Terms Of Service Html <br>
                   	          <textarea name="tosHtml" id="tosHtml" cols="45" rows="5"><?php echo readHtmlFromDb($objLevel->sTosHtml) ?></textarea>
                   	        </div>
               	          <label for="requireTos"></label></td>
                  	  </tr>
							
					    <tr>
                     		<td class="gridRow1">Active?</td>
                     		<td class="gridRow1"><div style="width:50px; float:left"><input name="active" type="checkbox" id="active" onChange="toggle(this,'displaySettings')" value="1" <?php echo $activeChecked ?>></div>
                   		      <div id="displaySettings" style="width:80%; float:left; display:<?php echo $displaySettings ?>">Display on Front End?
                   		        <input name="display" type="checkbox" id="display" value="1" <?php echo $displayChecked ?>>
                   		      </div>
               		        </td>
                   		</tr>
					    <tr>
					      <td class="gridRow1">Upgrade - Coming Soon</td>
					      <td class="gridRow1"><select name="upgradeList" id="upgradeList">
				          </select></td>
			          </tr>
					    <tr>
					      <td class="gridRow1">Downgrade - Coming Soon</td>
					      <td class="gridRow1"><select name="downgradeList" id="downgradeList">
				          </select></td>
			          </tr>
					    <tr>
					      <td colspan="2" class="gridFooter"><input type="submit" name="add" value="Edit Member Level" class="inputSubmitb"></td>
				      </tr>
						</table>
                </form>
                
            <!-- Existing Member Level --></td>
        </tr>
    </table><?php include_once 'b.php'; ?>
    <script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form1").validate();
		});
	</script>
</body>
</html>
