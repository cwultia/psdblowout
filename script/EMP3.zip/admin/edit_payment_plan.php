<?php
	include_once '../conn.php';
	include_once '../functions.php';
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Edit Payment Plan';
	$css = <<<EOT
<!--page level css -->

<!--end of page level css-->
EOT;
	
	function showMoney($amount){
		$moneySymbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
		return $moneySymbol.number_format($amount,2).' '.$chkSsettings->sCurrencyFormat;
	}

	// Get payment plan details
	if ( isset($_GET['id']) && is_numeric($_GET['id']) ) {$nPaymentPlan_ID = $dbo->format($_GET['id']);} 
	elseif ( isset($_POST['nPaymentPlan_ID']) && is_numeric($_POST['nPaymentPlan_ID']) ){$nPaymentPlan_ID = $dbo->format($_POST['nPaymentPlan_ID']);}
	else {die("Invalid ID");}

	// Can We Edit This Payment Plan Safely?
	$can_edit = false;
	// Lets See If It Is Assigned To Any Active User levels.
	$sql = "SELECT COUNT(*) FROM tbluserlevels WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID." AND nActive = 1;";
	$c = $dbo->getval($sql);
	//die($sql);
	//die(var_dump($c));
	if($c == "0"){$can_edit = true;}

	// Send To View Only Page If Cannot Edit.
	//if(!$can_edit){header("Location: payment_plans_details.php?id=".$_GET['id']."&err=This Plan Has Active Memberships And Cannot Be Edited.");exit;}

	// Update Payment Plan
	if (!empty($_POST)) {
	
		if (isset($_POST['nOneTimePayment']) && $_POST['nOneTimePayment'] == '0'){
		
			// Update Recurring Plan OR Free Plan. TODO: Seperate.
			$trial1 = array();
			$trial2 = array();
			
			if(!$_POST['bTrial1']){
				// Trial Turned Off. Set data to zero
				// Use Trial Is defined By nPeriod Being Greater Than Zero.
				$trial1['nPeriod'] = 0;
				$trial1['sPeriod'] = 0;
				$trial1['nAmount'] = 0;
				$trial2['nPeriod'] = 0;
				$trial2['sPeriod'] = 0;
				$trial2['nAmount'] = 0;
			}
			else{
				// Trial One Selected. Validate Data.
				if ($_POST['nTrial1Period'] > 0) {
					
					// We Have A Good Trial One Completed.
					$trial1['nPeriod'] = $dbo->format($_POST['nTrial1Period']);
					$trial1['sPeriod'] = $dbo->format($_POST['sTrial1Period']);
					$trial1['nAmount'] = ($_POST['nTrialAmount1']=='' || !is_numeric($_POST['nTrialAmount1']))?'0':$dbo->format($_POST['nTrialAmount1']);
					
					// Lets Check For Trial 2.
					if(!$_POST['bTrial2']){
						
						$trial2['nPeriod'] = 0;
						$trial2['sPeriod'] = 0;
						$trial2['nAmount'] = 0;
					}
					else{
						// We Should Error Check.
						if ($_POST['nTrial2Period'] > 0) {
						
							// We Have A Good Trial One Completed.
							$trial2['nPeriod'] = $dbo->format($_POST['nTrial2Period']);
							$trial2['sPeriod'] = $dbo->format($_POST['sTrial2Period']);
							$trial2['nAmount'] = ($_POST['nTrialAmount2']=='' || !is_numeric($_POST['nTrialAmount2']))?'0':$dbo->format($_POST['nTrialAmount2']);
						}
						else {
							$trial2['nPeriod'] = 0;
							$trial2['sPeriod'] = 0;
							$trial2['nAmount'] = 0;
						}
					}
				} 
				else {
					$trial1['nPeriod'] = 0;
					$trial1['sPeriod'] = 0;
					$trial1['nAmount'] = 0;
					$trial2['nPeriod'] = 0;
					$trial2['sPeriod'] = 0;
					$trial2['nAmount'] = 0;
					
				}
			}
			
				
			if (isset($_POST['nTrialAmount2']) && is_numeric($_POST['nTrialAmount2'])) {} else {$trialamt2 = 0;}
			
			$sql = "UPDATE tblpaymentplans SET
			sPlanName = '" . $dbo->format($_POST['sPlanName']) . "', 
			sItemNumber = '" . $dbo->format($_POST['sItemNumber']) . "',
			nRegularAmount = '" . $dbo->format($_POST['nAmount']) . "',
			nRegularPeriod = '" . $dbo->format($_POST['nRegularPeriod']) . "',
			sRegularPeriod = '" . $dbo->format($_POST['sRegularPeriod']) . "', 
			nTrialAmount1 = '" . $trial1['nAmount'] . "',
			nTrial1Period = '" . $trial1['nPeriod'] . "',
			sTrial1Period = '" . $trial1['sPeriod'] . "', 
			nTrialAmount2 = '" . $trial2['nAmount'] . "',
			nTrial2Period = '" . $trial2['nPeriod'] . "',
			sTrial2Period = '" . $trial2['sPeriod'] . "', 
			nMembershipLevel_ID = '" . $dbo->format($_POST['nLevel_ID']) . "',
			nRecurTimes = '" . $dbo->format($_POST['nRecurTimes']) . "',
			nZooFunnel = '". $dbo->format($_POST['nZooFunnel']) ."' 
			WHERE nPaymentPlan_ID= '" . $nPaymentPlan_ID."';";
			
			//die($sql);
			//die(var_dump($_POST));
			if($dbo->update($sql)){pluginClass::action("payment_plan_Edited",$nPaymentPlan_ID);$message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>Payment plan has been updated successfully</div>';}
			else{$message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>There was an error Updating the Payment Plan<br />'.$dbo->error.'</div>';}
			
		}	
		// Update One Time Only plan
		else {
		
			$sql = "UPDATE tblpaymentplans SET
			sPlanName = '" . $dbo->format($_POST['sPlanName']) . "', 
			sItemNumber = '" . $dbo->format($_POST['sItemNumber']) . "',
			nRegularAmount = '" . $dbo->format($_POST['nAmount']) . "',
			nMembershipLevel_ID = '" . $dbo->format($_POST['nLevel_ID']) . "',
			nRegularPeriod = '".$dbo->format($_POST['nRegularPeriod'])."',
			sRegularPeriod = '".$dbo->format($_POST['sExpirePeriod'])."',
			nZooFunnel = '". $dbo->format($_POST['nZooFunnel'])."'"./*,
			ExpirePeriod = '".$dbo->format($_POST['nExpirePeriod'])."',
			sExpirePeriod = '".$dbo->format($_POST['sExpirePeriod'])."'"
			.*/" WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID;
			//die($sql);
			if($dbo->update($sql)){
				$message = '<div class="success">Payment plan has been updated successfully</div>';
				pluginClass::action("payment_plan_Edited",$nPaymentPlan_ID);
				
			}
			else{
				$message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>There was an error Updating the Payment Plan<br />'.$dbo->error.'</div>';
			}
		
		}

	}
	$objPaymentPlan = $dbo->getobject("SELECT * FROM tblpaymentplans WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID);
	
	$sProcessorName = $dbo->getval("SELECT sProcessorName FROM tblpaymentprocessors WHERE nPaymentProcessor_ID=" . $objPaymentPlan->nPaymentProcessor_ID);
	
	$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
	
	$level_name = get_level_name_by_level_id($objPaymentPlan->nMembershipLevel_ID);
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Payment Settings</li>
			<li><a href="payment_plans.php?level_id=<?php echo $objPaymentPlan->nMembershipLevel_ID ?>">Payment Plans</a></li>
			<li class="active">Edit Payment Plan</li>
		</ol>
	</section>
	<section class="content">
	   <div class="col-md-12"><?php echo isset($message) ? $message : '' ?>
	   
	   <?php if(!$can_edit){?><h4>Warning: Editing Payment Plans With Active Memberships Can Produce Unexpected Results.<br />
Proceed With Caution!</h4><?php } ?>
</div>
	   <?php
				// We need to load the form to a variable so we can filter it with plugin class
				ob_start();
				?>
	   <form name="form1" id="form1" method="post" action="edit_payment_plan.php?id=<?php echo $nPaymentPlan_ID ?>">
                <input type="hidden" name="nPaymentPlan_ID" value="<?php echo $objPaymentPlan->nPaymentPlan_ID ?>">
                <input type="hidden" name="nOneTimePayment" value="<?php echo $objPaymentPlan->nOneTimePayment ?>">
	<div class="col-md-12">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">Payment Plan Details</h3>
			</div>
			<div class="panel-body">
				<table class="table table-striped table-bordered table-hover">
                    	<tr>
                    	  <th>Plan Name <span style="color:red">*</span></th>
                    	  <td><input name="sPlanName" class="required" style="width: 200px;" value="<?php echo $objPaymentPlan->sPlanName ?>" maxlength="50">
                    	    <small><?php echo ($objPaymentPlan->nOneTimePayment == 0) ? '(e.g. "Free 7 Day Trial then $47/Month")' : '(e.g. "$97 One Time Only")'; ?></small></td>
                  	  </tr>
                    	<tr>
                    		<th>Processor</th>
                    		<td>
                    			<?php echo $sProcessorName; ?>
                    		</td>
						</tr>
						<tr>
							<th>Plan Type</th>
							<td>
								<?php echo (preg_match("/1/", $objPaymentPlan->nOneTimePayment)) ? "One Time Only" : "Recurring"; ?>
							</td>
                            
						</tr>
                        <?php if($sProcessorName != "Free"){?>
						<tr>
						  <th><?php echo $sProcessorName; ?> Product Number <font style="color:red"> * </font></th>
						  <td><input name="sItemNumber" class="required" id="sItemNumber" style="width: 200px;" value="<?php echo $objPaymentPlan->sItemNumber ?>" remote="ajax/functions.php?act=check_itemnumber&nPaymentPlan_ID=<?php echo $objPaymentPlan->nPaymentPlan_ID?>&sCurrentNum=<?php echo $objPaymentPlan->sItemNumber ?>" />
						    
						    <small>(This will uniquely identify your product in <?php echo $sProcessorName; ?>)</small><br>
<label for="sItemNumber" class="error" style="display: none">This item number is already in use for this processor</label></td>
					  </tr>
                      <?php if($sProcessorName == 'JvZoo'){?>
					  <?php }?>
                        <tr id="paymentSchedule">
                          <th colspan="2">Payment Schedule</th>
                          </tr>
                    	
					  <?php
						
						// Display different options for recurring/one time
						if ($objPaymentPlan->nOneTimePayment == 1) {
						?>
								<tr>
									<th colspan="2">
										One Time Payment Of <?php echo $currency_symbol ?>
									<input name="nAmount" value="<?php echo number_format($objPaymentPlan->nRegularAmount,2) ?>" maxlength="10" style="width: 50px;" class="number required">  <?php echo $chkSsettings->sCurrencyFormat ?> </td>
								</th>
                            <?php }
						else{ ?>
                                <tr>
                                  <td><p>
                                    <input name="bTrial1" type="checkbox" id="bTrial1" value="1" <?php echo ($objPaymentPlan->nTrial1Period > 0)?'checked':'' ?>>
                                    <label for="bTrial1"></label>
Use Trial Period?</p></td>
                                  <td>
                                    <div>&nbsp;<?php echo $currency_symbol ?>
                                      <input name="nTrialAmount1" value="<?php echo number_format($objPaymentPlan->nTrialAmount1,2) ?>" maxlength="10" style="width: 60px;" class="number">
                                      <?php echo $chkSsettings->sCurrencyFormat ?> For The First
                                      <input name="nTrial1Period" value="<?php echo $objPaymentPlan->nTrial1Period ?>" maxlength="10" style="width: 50px;" class="digits">
                                      <select name="sTrial1Period" style="width: 200px;">
                                        <option value="Days" <?php if($objPaymentPlan->sTrial1Period=='Days') echo ' selected' ?>>Days</option>
                                        <option value="Weeks" <?php if($objPaymentPlan->sTrial1Period=='Weeks') echo ' selected' ?>>Weeks</option>
                                        <option value="Months" <?php if($objPaymentPlan->sTrial1Period=='Months') echo ' selected' ?>>Months</option>
                                        <option value="Year" <?php if($objPaymentPlan->sTrial1Period=='Year') echo ' selected' ?>>Year</option>
                                      </select>
                                    </div>
                                    </td>
                                </tr>
                                 <?php if($sProcessorName == 'Paypal'){ ?>
                                <tr>
                                  <td><p>
                                    <input name="bTrial2" type="checkbox" id="bTrial2" value="1" <?php echo ($objPaymentPlan->nTrial2Period > 0)?'checked':'' ?>>
                                    <label for="bTrial2"></label>
Second Trial Period?</p></td>
                                  <td><div>&nbsp;<?php echo $currency_symbol ?>
                                    <input name="nTrialAmount2" class="number" id="nTrialAmount2" style="width: 60px;" value="<?php echo number_format($objPaymentPlan->nTrialAmount2,2) ?>" maxlength="10"/>
                                    <?php echo $chkSsettings->sCurrencyFormat ?> For The Next
                                    <input name="nTrial2Period" class="digits" id="nTrial2Period" style="width: 50px;" value="<?php echo $objPaymentPlan->nTrial2Period ?>" maxlength="10">
  <select name="sTrial2Period" id="sTrial2Period" style="width: 200px;">
    <option value="Days" <?php if($objPaymentPlan->sTrial2Period=='Days') echo ' selected' ?>>Days</option>
    <option value="Weeks" <?php if($objPaymentPlan->sTrial2Period=='Weeks') echo ' selected' ?>>Weeks</option>
    <option value="Months" <?php if($objPaymentPlan->sTrial2Period=='Months') echo ' selected' ?>>Months</option>
    <option value="Year" <?php if($objPaymentPlan->sTrial2Period=='Year') echo ' selected' ?>>Year</option>
  </select>
                                  </div></td>
                                </tr> 
									<?php } ?>
						<?php
						 ?>
						
								<tr>
									<td><input name="regular" type="checkbox" id="regular" checked disabled>
									  <label for="checkbox"></label>
								    Regular Schedule <font style="color:red"> * </font></td>
									<td>
										<?php echo $currency_symbol ?> <input name="nAmount" value="<?php echo number_format($objPaymentPlan->nRegularAmount,2) ?>" maxlength="10" style="width: 60px;" class="number required">
										<?php echo $chkSsettings->sCurrencyFormat ?> Every
                                        <input name="nRegularPeriod" value="<?php echo $objPaymentPlan->nRegularPeriod ?>" maxlength="10" style="width: 50px;" class="digits required"> <select name="sRegularPeriod" style="width: 200px;" class="required">
<option value="Days" <?php if($objPaymentPlan->sRegularPeriod=='Days') echo ' selected' ?>>Days</option>
										  <option value="Weeks" <?php if($objPaymentPlan->sRegularPeriod=='Weeks') echo ' selected' ?>>Weeks</option>
										  <option value="Months" <?php if($objPaymentPlan->sRegularPeriod=='Months') echo ' selected' ?>>Months</option>
										  <option value="Year" <?php if($objPaymentPlan->sRegularPeriod=='Year') echo ' selected' ?>>Year</option>
									    </select> 
										For 
										<input name="nRecurTimes" value="<?php echo $objPaymentPlan->nRecurTimes ?>" 
                                        maxlength="10" style="width: 50px;" class="digits required">
                                        <span id="RecurPeriod"><?php echo $objPaymentPlan->sRegularPeriod ?></span> <?php echo ($sProcessorName == 'JvZoo')?' (36 Max)':'Use 0 for Unlimited';?></td>
								</tr>
								
						<?php } ?>
                        
                        <?php } ?>
						
                    </table>
			
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title"><?php echo ($sProcessorName=='Free')?'Confirmation':'Payment' ?> Success Options<?php if($nPaymentPlan_ID ==1){echo ' (Cannot Modify)';}?></h3>
			</div>
			<div class="panel-body">
				<table class="table table-striped table-bordered table-hover">
                        <tr>
                          <th colspan="2">
                          Activate Access To Membership Level:
                            
                            <?php
							if($nPaymentPlan_ID !=1){?>
                            <select name="nLevel_ID" style="width: 200px; color:black !important;font-weight:normal !important" class="required">
                              <option value="">Please choose a member level</option>
                              <?php
                    				$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels WHERE nActive=1 ORDER BY sLevel";
                    				$result = $dbo->select($sql);
                    				while($row = $dbo->getobj($result))
                    				{
                    					if ($objPaymentPlan->nMembershipLevel_ID == $row->nLevel_ID)
                   							echo '<option value="' . $row->nLevel_ID . '" selected>' . $row->sLevel . '</option>';
                   						else
                   							echo '<option value="' . $row->nLevel_ID . '">' . $row->sLevel . '</option>';
                    				}
                    			?>
                            </select>
                            
                            <?php 
							
							}
							else{echo $level_name;}
								
							?>
                          </th>
                        </tr>
                        <tr>
                        <td  colspan="2">
						 <?php 
						if ($objPaymentPlan->nOneTimePayment == '1' || $sProcessorName == 'Free'){ 
						
							if($nPaymentPlan_ID == '1'){echo 'Never Expires';}
							else{
							
							?>
								
								
								
								Will Expire In <input name="nRegularPeriod" id="nRegularPeriod" style="width: 50px;" value="<?php echo $objPaymentPlan->nRegularPeriod ?>" maxlength="10"> 
									<small><font style="color:red">*</font></small>
								  <?php
								  $expire = $objPaymentPlan->sRegularPeriod;
								  if($expire == '0'){$n = 'selected';}
								  if($expire == 'Days'){$d = 'selected';}
								  if($expire == 'Weeks'){$w = 'selected';}
								  if($expire == 'Months'){$m = 'selected';}
								  if($expire == 'Year'){$y = 'selected';}
								  
								  
								  
								  
								  ?>
								  <select name="sExpirePeriod" id="sExpirePeriod" style="width: 200px;">
									<option value="Days" <?php echo $d ?>>Days</option>
									<option value="Weeks" <?php echo $w ?>>Weeks</option>
									<option value="Months" <?php echo $m ?>>Months</option>
									<option value="Year" <?php echo $y ?>>Years</option>
								  </select> 
								  
							<?php }
						
						}
						else{echo 'Set To Lifetime Access At End Of Term ';}
						
						
						 ?>  
                         </td>
                        </tr>
                       
                        </table>
			</div>
		</div>

	</div>
	 <?php if($sProcessorName !=='Free') { ?>
                 
                  
                       
	<div class="col-md-6">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">Payment Refund Options</h3>
			</div>
			<div class="panel-body">
				<table class="gridtable" width="100%" cellpadding="0" cellspacing="1">
                        <tr>
                          <td colspan="2" >Remove Access To Membership Level: <a href="member_levels.php" target="_blank"><?php echo $level_name; ?></a></td>
                        </tr>
                        <tr>
                          <td colspan="2" >Set Account Status: Keep Account Active</td>
                        </tr>
                    </table>
			
			</div>
		</div>

	</div>
	 <?php echo pluginClass::filter('payment_plan_edit_form'); ?>
                        <?php } ?>
						
	<div class="col-md-12"><input type="submit" name="update" value="Update Payment Plan" class="btn btn-primary btn-responsive"></div>
	</form>
	 <?php 
				$paymentplanform = ob_get_clean();
			  	$paymentplanform = pluginClass::filter("admin_edit_payment_plan_form",$paymentplanform);
			  	echo $paymentplanform;
				?>
    </section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
    
</body>
</html>