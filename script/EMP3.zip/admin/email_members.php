<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Email Members';
	$css = <<<EOT
	<!--page level css -->
<link href="vendors/modal/css/component.css" rel="stylesheet" />
<link href="css/pages/editor.css" rel="stylesheet" type="text/css"/>
<link href="vendors/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen" />
<!--end of page level css-->
EOT;
	
	// Get Level Select
	// GET Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels";
	$levelRes = $dbo->select($sql);
	
	$levelsel = "<select name='levelFilterValue' id='levelFilterValue'> onChange='getPaymentPlansByLevel(this)'>\n\t
	<option value = '0'>--- Choose Membership Level ---</option>\n\t";
	while($row = $dbo->getobj($levelRes)){$levelsel .= '<option value="'.$row->nLevel_ID.'">'.$row->sLevel.'</option>\n\t';}
	$levelsel .='</select>';
	
	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a> </li>
      <li>Members</li>
      <li class="active">Email Members</li>
    </ol>
  </section>
  <section class="content">
  <?php echo isset($message) ? $message : '' ?>
<?php echo (time() - get_option('emailCron_LastRun') > (60*60*24) )?'
<div class="col-md-12"><div class="notify-warning"><div class="notify-close, warning-close" onClick="closeNotify(this)"></div>Email Cron Has Not Run In 24 hours. Make sure your cron is setup correctly. <br/><a href="manage_crons.php">Manage Cron Jobs</a></div></div>':''
?>
    <?php 
	  		/// Inprogress Broadcasts
			$sql2 = "SELECT * FROM tblbroadcasts WHERE tblbroadcasts.nStatus = '1'";
			$res_progress = $dbo->select($sql2);
			if($dbo->nr($res_progress) > 0){
				$inProgress = true;
	?>
    <div class="col-md-12">
      <!-- BEGIN SAMPLE TABLE PORTLET-->
      <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Broadcasts In Progress </div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
              <tr>
                <th>Subject</th>
                <th>Start Date/Time</th>
                <th>Email Count</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
			
			while($row = $dbo->getobj($res_progress)){
				$ajaxCalls[] = $row->nBroadcast_ID;
				$row->sentCount = $dbo->getval("SELECT COUNT(*) FROM tblemails WHERE nBroadcast_ID = '".$row->nBroadcast_ID."' AND nStatus = '1';");
				
				?>
              <tr>
                <td ><?php echo $row->sSubject?></td>
                <td ><?php echo $row->dStartTime?></td>
                <td ><span id="sentCount_<?php echo $row->nBroadcast_ID ?>"><?php echo $row->sentCount ?></span>/<?php echo $dbo->num_rows($row->sMemberQuery)?></td>
                <td ><form name="form1" method="post" action="actions.php?type=broadcast">
                    <input type="hidden" name="act" value="restart">
                    <input type="submit" name="button5" id="button5" value="Restart" class="btn btn-primary btn-responsive">
                  </form></td>
              </tr>
              <?php }
			  ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php
			if(isset($ajaxCalls)){
			echo '<script type="text/javascript">';
			foreach($ajaxCalls as $BID){
				echo 'setInterval(\'updateSentCount('.$BID.')\',15000);';	
			}
			echo '</script>';
		}}
			if(!$inProgress && is_option('email_broadcasting')){?>
    <div class="notify-warning">
      <div class="notify-close warning-close" onClick="closeNotify(this)"></div>
      There is a broadcast lock in effect!<br/>
      <form action="actions.php?type=broadcast" method="post">
        <input type="hidden" name="act" value="unlock" />
        <input type="submit" value="Unlock Broadcasts">
      </form>
    </div>
    <?php }?>
    <div class="col-md-12"> 
      <!-- BEGIN SAMPLE TABLE PORTLET-->
      <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Pending Broadcasts - <a data-toggle="modal" data-href="#newBroadcast" href="#newBroadcast">Add New</a></div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div class="col-md-6"> &nbsp; <?php echo $navigator; 	?> </div>
            <div class="col-md-6">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
              <tr>
                <th>Subject</th>
                <th>Delivery Date/Time</th>
                <th>Member Count</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
			// Load Pending Broadcasts
			$sql = "SELECT * FROM tblbroadcasts WHERE (nStatus = '0' OR nStatus = '-1') ORDER BY dScheduleTime ASC";
			$res = $dbo->select($sql);
			if($dbo->nr($res)){
			while($row = $dbo->getobj($res)){?>
              <tr>
                <td ><?php echo $row->sSubject?></td>
                <td ><?php echo ($row->dScheduleTime == '0000-00-00 00:00:00')?'Next Run':$row->dScheduleTime?></td>
                <td ><?php echo $dbo->num_rows($row->sMemberQuery)?></td>
                <td ><form name="form1" method="post" action="actions.php?type=broadcast" onSubmit="return confirmDelete('pending')">
                    <input class="btn btn-success btn-responsive" type="button" name="button2" id="button2" value="Edit" onClick="editBroadcast('<?php echo $row->nBroadcast_ID?>');">
                    <input type="hidden" name="nBroadcast_ID" value="<?php echo $row->nBroadcast_ID?>" >
                    <input type="hidden" name="act" value="del" >
                    <input type="submit" name="button" id="button" value="Delete" class="btn btn-danger btn-responsive">
                  </form>
                  <div style="display:none;">
                    <input type="hidden" id="broadcastSubject_<?php echo $row->nBroadcast_ID?>" value="<?php echo $row->sSubject?>" >
                    <textarea id="broadcastBody_<?php echo $row->nBroadcast_ID?>" ><?php echo $row->sBody?></textarea>
                    <textarea id="broadcastHtmlBody_<?php echo $row->nBroadcast_ID?>" style="display:none"> <?php echo $row->sBodyHtml?></textarea>
                    <input type="hidden" id="broadcastTime_<?php echo $row->nBroadcast_ID?>" value="<?php echo $row->dScheduleTime?>" >
                  </div></td>
              </tr>
              <?php }}
			else{ ?>
              <tr>
                <td colspan="4" >No Pending Broadcasts</td>
              </tr>
              <?php }
			 ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-12"> 
      <!-- BEGIN SAMPLE TABLE PORTLET-->
      <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Completed Broadcasts</div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
              <tr>
                <th>Subject</th>
                <th>Completed Date/Time</th>
                <th>Sent Count</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
			// Load Completed Broadcasts
			$sql3 = "SELECT * FROM tblbroadcasts WHERE tblbroadcasts.nStatus = '2'";
			//die($sql2);
			$res_complete = $dbo->select($sql3);
			if($dbo->nr($res_complete)){
				while($row = $dbo->getobj($res_complete)){
					$row->sentCount = $dbo->getval("SELECT COUNT(*) FROM tblemails WHERE nBroadcast_ID = '".$row->nBroadcast_ID."' AND nStatus = '1';");
					?>
              <tr>
                <td ><?php echo $row->sSubject?></td>
                <td ><?php echo $row->dSentTime?></td>
                <td ><?php echo $row->sentCount ?>/<?php echo $dbo->num_rows($row->sMemberQuery)?></td>
                <td ><form name="form1" method="post" action="actions.php?type=broadcast" onSubmit="return confirmDelete('completed')">
                    <input class="btn btn-success btn-responsive" type="button" name="button3" id="button3" value="Copy" onClick="cloneBroadcast('<?php echo $row->nBroadcast_ID?>');">
                    <input name="nBroadcast_ID" type="hidden" value="<?php echo $row->nBroadcast_ID?>" >
                    <input name="act" value="del" type="hidden" >
                    <input class="btn btn-danger btn-responsive" type="submit" name="button3" id="button4" value="Delete">
                  </form>
                  <div style="display:none;">
                    <input type="hidden" id="broadcastSubject_<?php echo $row->nBroadcast_ID?>" value="<?php echo $row->sSubject?>" >
                    <textarea id="broadcastBody_<?php echo $row->nBroadcast_ID?>" ><?php echo $row->sBody?></textarea>
                    <textarea id="broadcastBodyHtml_<?php echo $row->nBroadcast_ID?>"><?php echo readHtmlFromDb($row->sBodyHtml)?></textarea>
                  </div></td>
              </tr>
              <?php }
			}
			else{ ?>
              <tr>
                <td colspan="4" >No Completed Broadcasts</td>
              </tr>
              <?php }
			  ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>

<?php
require_once('footer.php');

	$filterName = 'None';
	if(isset($_SESSION['admin']['current_mqf_sql'])){
									$filterName = str_replace('mqf_','',$_SESSION['admin']['current_mqf_title']);
									$activeFilter = true;
								}
?>

<!-- New Broadcast Modal Window -->
<div id="newBroadcast" class="modal fade in" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form name="frm" method="post" action="actions.php?type=broadcast"  onSubmit="return checkthis()" id="Broadcast">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title">Create New Broadcast</h4>
				</div>
				<div class="modal-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
						<tr>
							<th>Email To: <font color="Red"> *</font></th>
							<td>
								<div id="broadcastQuery" style="display:block"> <span style="color:#C00">Active Filter:</span>
								<span id="activeFilterDisplay">

	 							<?php echo $filterName ?> - <a data-toggle="modal" data-href="#manageFilters" href="#manageFilters"> Manage Filters</a>
								<a href="javascript:void();" onClick="hideQueryBox()">Cancel</a>
								</span></div>
								<div id="broadcastQuerySet" style="display:<?php echo ($activeFilter)?'block':'none'?>">
									Member Query Set - <a href="javascript:void();" onClick="showQueryBox()">Clear Query</a>
								</div>
							</td>
							<td rowspan="6" valign="top" >
								<strong>Available Merge Codes</strong>
								First Name = [[FIRSTNAME]]<br />
								<br />
								Last Name = [[LAST NAME]]<br />
								<br />
								Username = [[USERNAME]] <br />
								<br />
								Password = [[PASSWORD]]<br /></td>
						</tr>
						<tr>
							<th>Send Email</th>
							<td>
									<label>
										<input name="schedule" type="radio" id="schedule_0" value="0" checked="checked" />
										Immediately</label>
									&nbsp;
									<label>
										<input type="radio" name="schedule" value="1" id="schedule_later" onClick="focusDateTime()"/>
										Send @ </label>
									<div class='input-group date'>
			<input name="scheduleDateTime" type="text" id="scheduleDateTime" class="col-sm-3 form-control" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i');?>"  readonly="readonly"/>
			  <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span></div>
									
								</td>
						</tr>
						<tr>
							<th>Subject: <font color="Red"> *</font></th>
							<td ><input name="subject" id="newSubject" type="text" size="75" style="width:485px;" value="<?php echo $_POST["subject"]; ?>" /></td>
						</tr>
						<tr>
							<th>Text Body <font color="Red">*</font></th>
							<td ><textarea name="txtBody" rows="10" class="mceNoEditor" id="newBody"><?php echo $_POST["txtBody"] ?></textarea></td>
						</tr>
						<tr>
							<th>Html Body <font color="Red">*</font></th>
							<td ><textarea name="htmlBody" cols="50" rows="24" id="newHtmlBody" class="tinymce_full"><?php echo $_POST["htmlBody"];?></textarea></td>
						</tr>
					</table>
					</div>
				</div>
				<div class="modal-footer">
					<div id="testEmailResult" style="display:inline"></div>&nbsp;&nbsp;
					
					<input name="act" type="hidden" id="act" />
					<input name="nBroadcast_ID" type="hidden" id="nBroadcast_ID" value="0" />
					<input name="filterName" type="hidden" id="filterName" value="<?php echo $_SESSION['admin']['current_mqf_title']?>" />
					<input name="queryType" type="hidden" id="queryType" value="saved" />
					<input type="hidden" name="sendEmailToId" id="sendEmailToId">
					<button type="button" data-dismiss="modal" class="btn">Close</button>
					<input class="btn btn-primary btn-responsive" name="Submit2" value="Send Test Email" type="button" id="testEmail" />
					<button type="submit" class="btn btn-primary btn-responsive"> Save Broadcast </button>
				</div>
			</div>
		</div>
	</form>
</div>

<!-- END New Broadcast Modal Window -->
<!-- Query Filter Modal Window -->
<div id="manageFilters" class="modal fade in" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
<div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title">Query Filter Manager</h4>
        </div>
        <div class="modal-body">
    		<div id="manageFilters_addNew" style="display:none;">
	<hr>
	<form name="f1" method="post" action="actions.php?type=queryFilter" onSubmit="return checkthis()" id="addNewForm">
		<strong>New Filter Name</strong>
		<input name="newFilterName" type="text" id="newFilterName" size="55">
		<p><strong>Filter Fields</strong><br>
			<input name="level" type="checkbox" id="level" value="1" onClick="showFilterFields(this)">
			<label for="level"></label>
			<label>Membership Level</label>
			<input name="affiliate" type="checkbox" id="affiliate" value="1" onClick="showFilterFields(this)">
			<label>Affiliate</label>
			<input name="login" type="checkbox" id="login" value="1" onClick="showFilterFields(this)">
			Last Login
			<input name="emailStatus" type="checkbox" id="emailStatus" value="1" onClick="showFilterFields(this)">
			Email Status
			<input name="optin" type="checkbox" id="optin" value="1" onClick="showFilterFields(this)">
			Opt-In Status
			<input name="join" type="checkbox" id="join" value="1" onClick="showFilterFields(this)">
			Join Date</p>
		<p>View Members Where
		<div id="filterContainer" style="margin-left:15px;">
			<div id="levelFilter" style="display:none;"> Membership Level <?php echo $levelsel ?>
				<select name="levelFilterCompare" id="levelFilterCompare">
					<option value="IN">Is Assigned</option>
					<option value="NOT IN">Not Assigned</option>
				</select>
				<label for="levelFilterValue"></label>
			</div>
			<div id="affiliateFilter" style="display:none;">Is Affiliate
				<label for="affiliateFilterValue"></label>
				<select name="affiliateFilterValue" id="affiliateFilterValue">
					<option value="1">True</option>
					<option value="0">False</option>
				</select>
			</div>
			<div id="loginFilter" style="display:none;">Last Login
				<label for="loginFilterCompare"></label>
				<select name="loginFilterCompare" id="loginFilterCompare" onChange="toggleFilterValue2(this);">
					<option value=">">After</option>
					<option value="<">Before</option>
					<option value="=">On</option>
					<option value="><">Between</option>
					<option value="never">Never</option>
				</select>
				<input name="loginFilterValue" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
				<span id="loginFilterBetween" style="display:none;"> And
				<input name="loginFilterValue2" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
				</span></div>
			<div id="emailStatusFilter" style="display:none;"> Account Status
				<label for="emailStatusFilterValue"></label>
				<select name="emailStatusFilterValue" id="emailStatusFilterValue">
					<option value="1">Confirmed</option>
					<option value="0">Unconfirmed</option>
				</select>
			</div>
			<div id="optinFilter" style="display:none;">Optin Status
				<label for="optinFilterValue"></label>
				<select name="optinFilterValue" id="optinFilterValue">
					<option value="0">Receive All</option>
					<option value="1">Receive None</option>
				</select>
			</div>
			<div id="joinFilter" style="display:none;">Joined
				<label for="joinFilterCompare"></label>
				<select name="joinFilterCompare" id="joinFilterCompare" onChange="toggleFilterValue2(this)">
					<option value=">">After</option>
					<option value="<">Before</option>
					<option value="=">On</option>
					<option value="><">Between</option>
				</select>
				<input name="joinFilterValue" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
				<span id="joinFilterBetween" style="display:none;"> And
				<input name="joinFilterValue2" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
				</span> </div>
		</div>
		</p>
		<input name="act" type="hidden" id="act2" value="saveFilter">
		<p>&nbsp;</p>
		<p>
			<input class="inputSubmit" name="submit2" value="Apply Filter" type="button" onClick="submitAddNew()">
			&nbsp;
			<input class="inputSubmit" name="cancel" value="Cancel" type="button" onClick="hideAddNew()">
		</p>
	</form>
</div>
			<div id="tableContainer" >
				<div align="right" style="padding:5px;">
					<a href="#" onClick="showAddNew()" class="btn btn-info btn-responsive btn-xs">Add New</a>
				</div>  
				<div id="tableRows">Loading Filters ...</div>
			</div>
		</div>
		<div class="modal-footer">
          <button type="button" data-dismiss="modal" class="btn">Close</button>
        </div>
	</div>
<!-- END Query Filter Modal Window -->
<!-- end of page level js -->
<script src="vendors/modal/js/classie.js"></script> 
<script src="vendors/modal/js/modalEffects.js"></script>
<!--datetime picker-->
<script type="text/javascript" src="vendors/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="vendors/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
<!-- end of page level js -->
<?php if(get_option('use_mce') == '1'){
		$doc_base = $chkSsettings->sSiteURL .'/'; ?>
<script  src="vendors/tinymce/js/tinymce/tinymce.min.js" type="text/javascript" ></script>
<script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
<?php } ?>
<script language="javascript" src="common/js/queryFilter.js"></script> 
<script type="text/javascript">
	// Set Global Variables
	var useQuery = false;
	function sendTestEmail(){
    		button = this;
			button.value = 'Sending Test Email ...';
			$("#testEmailResult").html('');
			tinyMCE.triggerSave();
			data = $('#Broadcast').serialize();
			
			jQuery.ajax({url: 'ajax/functions.php?act=test_email',type: 'POST',data: data})
			.done(function (response) {
    			result = jQuery.parseJSON(response);
				button.value = 'Resend Test Email';
				if(result.error){
					$("#testEmailResult").html('<span class=\'error\'>'+result.message+'</span>');
				}
				else{
					$("#testEmailResult").html('<span class=\'success\'>'+result.message+'</span>');
				}
				
			}).fail(function () {
    // Whoops; show an error.
			});
  		}
	$(function() {
		$('#newBroadcast').on('show.bs.modal', function(e) {
			$('#act').val('add');
			//$('#newBody').val('');
			//$('#newSubject').val('');
			//$('#newTitle').val('');
			//$('#schedule_0').prop('checked', true);
			//$('#scheduleDateTime').val('');
			showQueryBox();
			$("#testEmail").click(sendTestEmail);
		});
		$('#manageFilters').on('show.bs.modal', function(e) {
			$('#newBroadcast').modal('hide');
		});
		$('#manageFilters').on('hidden.bs.modal', function(e) {
			$('#newBroadcast').modal('show');
		});
	
		$('#scheduleDateTime').datetimepicker({
		 format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?> hh:ii', 
		<!-- endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?> - 00:00:00', -->
    	autoclose: true
	});
	
		$("#scheduleDateTime").focus(function(){
    		$("#schedule_0").prop("checked", false);
			$("#schedule_later").prop("checked", true);
		});
		
	 });
	function focusDateTime(){
		$("#scheduleDateTime").focus();
	}
	function checkthis() {
		var bValid = true;
		var re = /^\s*$/;
		var oForm = document.forms.frm;
		var n = 0;
		
		// use global var useQuery
		if(useQuery == true){
			if(!oForm.filterName.value.search(re)){
				alert("You Must Choose A Filter");
				return false;
			}
		}
		
		if (!oForm.subject.value.search(re)) {
			alert("Please enter a Subject");
			oForm.subject.focus();
			return false;
		}
		
		if (!oForm.txtBody.value.search(re)) {
			alert("Please fill in the body section");
			oForm.txtBody.focus();
			return false;
		}
		return true;	
	}
	function showQueryBox(){
		$("#broadcastQuery").show();
		$("#broadcastQuerySet").hide();
		$("#queryType").val('filter');
		useQuery = true;
	}
	function hideQueryBox(){
		$("#broadcastQuery").hide();
		$("#broadcastQuerySet").show();
		$("#queryType").val('saved');
		useQuery = false;
	}
	
	function cloneBroadcast(id){
		$('#act').val('add');
		$('#newSubject').val($('#broadcastSubject_'+id).val());
		$('#newBody').val($('#broadcastBody_'+id).val());
		$('#newHtmlBody').val($('#broadcastBodyHtml_'+id).val());
		
		tinyMCE.activeEditor.setContent($('#broadcastBodyHtml_'+id).val());
		$('#newBroadcast').modal('show');
	}
	function editBroadcast(id){
		// set global variable useQuery
		useQuery = true;
		$('#act').val('edit');
		$('#nBroadcast_ID').val(id);
		
		var title = 'Edit Broadcast Email';
		var sendTime = $('#broadcastTime_'+id).val();
		
		$("#broadcastQuerySet").show();
		$("#broadcastQuery").hide();
		
		if(sendTime == '0000-00-00 00:00:00') $('#schedule_0').prop('checked', true);
		
		else{
			$('#schedule_1').prop('checked', true);
			$('#scheduleDateTime').val(sendTime);
		}
		//$( "#newBroadcast" ).dialog('option','title',title).dialog( "open" );
		$('#newBroadcast').modal('show',true);
		
		$('#newBroadcast').on('shown.bs.modal', function(e) {
			$('#newBody').val($('#broadcastBody_'+id).val());
			$('#newHtmlBody').val($('#broadcastHtmlBody_'+id).val());
			$('#newSubject').val($('#broadcastSubject_'+id).val());
		
			tinyMCE.activeEditor.setContent($('#broadcastHtmlBody_'+id).val());
		
			//$( "#newBroadcast" ).dialog( "open" );
			// Test Email
			$("#testEmail").click(sendTestEmail);
		});
			
	}
	
	function updateSentCount(id){
		// This function will check to see how many emails have been sent, and update the field every 60 seconds
		$.ajax({
      		url: "ajax/functions.php?act=broadcasts_sent&id="+id,
      			type:"get",
      			success: function(data){$('#sentCount_'+id).html(data);}
		})
	}
	function confirmDelete(type){
		return confirm('Are you sure you want to delete this '+type+' broadcast?\nThis action cannot be reversed!');
	}
</script>
</body></html>