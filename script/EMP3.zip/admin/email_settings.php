<?php
	include_once('../conn.php');
	include_once('../functions.php');
	include_once('../includes/functions-time.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Email Settings';
	$css = <<<EOT
<!--page level css -->
<link href="css/pages/editor.css" rel="stylesheet" type="text/css"/>
<!--end of page level css-->
EOT;
	
	// Check for pear
	@include_once ('System.php');
	@include('Mail.php');
	
	if ( isset($_POST['Update']) ){
		
		
		// Error checking on smtp settings
		$err = 0;
		if($_POST['mail_method'] == 'smtp'){
			if($_POST['smtp_host'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Hostname';
			}
			if($_POST['smtp_port'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Port';
			}
			if($_POST['smtp_user'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Username';
			}
			if($_POST['smtp_password'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Password';
			}
			
			if($err == 0){
				// Lets test the SMTP connection.
				
				$smtp = @Mail::factory('smtp',array ('host' => $_POST['smtp_host'],'port' => $_POST['smtp_port'],'auth' => true,'username' => $_POST['smtp_user'],'password' => $_POST['smtp_password']));
 				$conn_res = @$smtp->getSMTPObject();
 				if (@PEAR::isError($conn_res)) {
					$err++;
					$errmsg[] = $conn_res->getMessage();
				}
			}
			
		}
		
		if (!isValidEmail ($_POST['sAdminEmail']) && $_POST['sAdminEmail'] == '') {
			$err++;
			$em = 1;
		}
		if (!isValidEmail ($_POST['sSupportEmail']) && $_POST['sSupportEmail'] == '') 	{
			$err++;
			$sem = 1;
		}
		
		if($err == 0){
			
			update_option('mail_method',$_POST['mail_method']);
			update_option('mail_seconds',$_POST['mail_seconds']);
			update_option('sEmailCanSpam',$_POST['sEmailCanSpam']);
			update_option('sHtmlEmailCanSpam',$_POST['sHtmlEmailCanSpam']);
			
			$email_powered_by = ($_POST['email_powered_by'] == '1')?1:0;
			
			if(get_option('email_powered_by') != $email_powered_by) update_option('email_powered_by',$dbo->format($_POST['email_powered_by']));
			
			if($_POST['mail_method'] == 'smtp'){
				
				update_option('smtp_host',$_POST['smtp_host']);
				update_option('smtp_port',$_POST['smtp_port']);
				update_option('smtp_user',$_POST['smtp_user']);
				update_option('smtp_password',$_POST['smtp_password']);
			}
			$sql = "UPDATE tblsitesettings SET 
			
			sAdminEmail = '".$dbo->format($_POST['sAdminEmail'])."', 
			sSupportEmail = '".$dbo->format($_POST['sSupportEmail'])."',
			sEmailFooter='".$_POST['sEmailFooter']."', 
			sHtmlEmailFooter='".$_POST['sHtmlEmailFooter']."';";
			if(!$dbo->update($sql)){$message = "Database Error: ".$dbo->error;}
			else{$message = "Email settings have been updated successfully";}
			
			header("Location: email_settings.php?msg=".urlencode($message));
		}
	}
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Emails</li>
			<li class="active">Email Settings</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Email Details</h3>
					</div>
					<div class="panel-body">
						<fieldset>
							<div class="form-group">
								<label class="col-md-2 control-label" for="name">System Email Address <font style="color:red"> * </font></label>
								<div class="col-md-10">
									<input name="sAdminEmail" type="text" value="<?php echo $chkSsettings->sAdminEmail;?>" class="form-control required" />
									<?php if ($em == 1) { ?>
									<span class="red">[ INVALID ]</span>
									<?php } ?>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-2 control-label" for="name">Support Email Address <font style="color:red">* </font></label>
								<div class="col-md-10">
									<input name="sSupportEmail" type="text" value="<?php echo $chkSsettings->sSupportEmail; ?>"  class="form-control required"/>
									<?php if ($sem == 1) { ?>
									<span class="red">[ INVALID ]</span>
									<?php } ?>
								</div>
							</div>
						</fieldset>
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Email Configuration</h3>
					</div>
					<div class="panel-body">
						<fieldset>
						<div class="form-group">
								<label class="col-md-2 control-label" for="email_powered_by">Use Powered By Link?</label>
								<div class="col-md-10">
								<input name="email_powered_by" type="checkbox" id="email_powered_by" value="1" <?php echo (get_option('email_powered_by'))?'checked':'' ?>>
								</div>
							</div>
							<div style="clear:both"></div>
							<div class="form-group">
								<label class="col-md-2 control-label" for="name">Send Email Using</label>
								<div class="col-md-10">
									<input name="mail_method" type="radio" id="php" value="php" <?php echo (get_option('mail_method') == 'php')?'checked="CHECKED"':''?> onChange="toggleSmtp(this)">PHP Mail&nbsp;
									<input type="radio" name="mail_method" value="smtp" id="smtp" <?php echo (class_exists('Mail', false))?'':' disabled title="This feature is not installed on this server. Ask your webhost to install this for you."' ?> 
                        <?php echo (get_option('mail_method') == 'smtp')?'checked="CHECKED"':''?>
                         onChange="toggleSmtp(this)">&nbsp;Pear Mail
									<div id="smtp_settings" style="margin-left:90px; display:<?php echo (get_option('mail_method') == 'smtp')?'block':'none'?>">
										<?php if($err){?>
										<div id="smtp_errors" class="error" >
											<p>Please Correct The Following Issues</p>
											<?php foreach ($errmsg as $v) {echo "$v <br />"; }
						?>
										</div>
										<?php
						
						
						 } ?>
										<table border="0" cellspacing="0" cellpadding="2">
											<tr>
												<td>SMTP Host</td>
												<td><label for="smtp_host"></label>
													<input name="smtp_host" type="text" id="smtp_host" value="<?php echo (isset($_POST['smtp_host']))?$_POST['smtp_host']:get_option('smtp_host')?>" size="50"></td>
											</tr>
											<tr>
												<td>SMTP Port</td>
												<td><input name="smtp_port" type="text" id="smtp_port" value="<?php echo (isset($_POST['smtp_port']))?$_POST['smtp_port']:get_option('smtp_port')?>" size="6"></td>
											</tr>
											<tr>
												<td>SMTP Username</td>
												<td><input name="smtp_user" type="text" id="smtp_user" value="<?php echo (isset($_POST['smtp_user']))?$_POST['smtp_user']:get_option('smtp_user')?>" size="50"></td>
											</tr>
											<tr>
												<td>SMTP Password</td>
												<td><input name="smtp_password" type="text" id="smtp_user" value="<?php echo (isset($_POST['smtp_password']))?$_POST['smtp_password']:get_option('smtp_password')?>" size="50"></td>
											</tr>
										</table>
									</div>
								</div>
							</div>
							<div style="clear:both"></div>
							<div class="form-group">
								<label class="col-md-2 control-label" for="name">Throttle Emails To</label>
								<div class="col-md-1">
									Send Every </div><div class="col-md-1"><input name="mail_seconds" type="text" id="mail_seconds" value="<?php echo get_option('mail_seconds')?>" size="3" class="form-control" style="display:inline" /></div><div class="col-md-8">Seconds</div>
									<div style="clear:both"></div><div class="col-md-2"></div><div class="col-md-8">
(0 for Unlimited [Not Recommended] )</div>
									
								</div>
								<div style="clear:both"></div>
								
							
						</fieldset>
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Can Spam Message / Unsubscribe</h3>
					</div>
					<div class="panel-body">
						<h4>The message you enter here will be appended to all broadast emails, use it to add canspam compliance and unsubscribe informaiton. <br>Use [[UNSUB_LINK]] to use the unsubscribe system. </h4>
						<div class="panel panel-success">
							<div class="panel-heading">
								<h3 class="panel-title">Plain Text Message</h3>
							</div>
							<div class="panel-body">
								<textarea name="sEmailCanSpam" rows="10" style="width:100%" id="sEmailCanSpam" data-autogrow><?php echo get_option('sEmailCanSpam'); ?></textarea>
							</div>
						</div>
						<div class="panel panel-success">
							<div class="panel-heading">
								<h3 class="panel-title">Html Message</h3>
							</div>
							<div class="panel-body">
								<textarea name="sHtmlEmailCanSpam" data-autogrow id="sHtmlEmailCanSpam" class="tinymce_full"><?php echo get_option('sHtmlEmailCanSpam'); ?></textarea>
							</div>
						</div>
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Email Footers</h3>
					</div>
					<div class="panel-body">
						<h4>The text you enter here will be appended to all outgoing emails, use it to add details of how to contact <br/>
							support or promotional links for example. </h4>
						<div class="panel panel-success">
							<div class="panel-heading">
								<h3 class="panel-title">Plain Text Footers</h3>
							</div>
							<div class="panel-body">
								<textarea name="sEmailFooter" rows="10" style="width:100%" data-autogrow><?php echo $chkSsettings->sEmailFooter ?></textarea>
							</div>
						</div>
						<div class="panel panel-success">
							<div class="panel-heading">
								<h3 class="panel-title">Html Footers</h3>
							</div>
							<div class="panel-body">
								<textarea name="sHtmlEmailFooter" rows="10" class="tinymce_full" id="sHtmlEmailFooter" data-autogrow><?php echo $chkSsettings->sHtmlEmailFooter ?></textarea>
							</div>
						</div>
						<input type="submit" name="Update" value="Save Changes" class="btn btn-primary btn-responsive" />
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
if(get_option('use_mce') == '1'){
	$doc_base = $chkSsettings->sSiteURL .'/'; ?>
<script  src="vendors/tinymce/js/tinymce/tinymce.min.js" type="text/javascript" ></script> 
<script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
<?php } ?>
<script type="text/javascript">
        	function toggleSmtp(radio){
				
				if(radio.value == 'smtp'){
					//document.getElementById('smtp_settings').style.display = 'block'
					$("#smtp_settings").show(1000);
				}
				else{
					//document.getElementById('smtp_settings').style.display = 'none'
					$("#smtp_settings").hide(1000);
				}
			}
        </script>
</body></html>