<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Promo Email Subjects';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
	
	if ($_GET['status'] != ''){
		$sql = "UPDATE tblpromoemailsubject SET ndisplay='" . $dbo->format($_GET['status']) . "' WHERE npromoemailsubject_id = '" . $dbo->format($_GET['projid'])."'";
		$dbo->update($sql);
	}
	
	
	if($_GET['act'] == 'd'){
		$dbo->delete("DELETE FROM tblpromoemailsubject WHERE npromoemailsubject_id = '" . $dbo->format($_GET['id'])."'");
		header("location:email_subject.php?act=dsus");
	}
	
	require_once('header.php');
				
	$sqlcs="SELECT * FROM tblpromoemailsubject order by npromoemailsubject_id";
	$resultcs=$dbo->select($sqlcs);
	if(!empty($resultcs)) $n=$dbo->nr($resultcs);
				
	$number = $n;                // record results selected from database 
	$displayperpage="10";                // record displayed per page 
	$pageperstage="10";                // page displayed per stage 
	$allpage=ceil($number/$displayperpage);        
	$allstage=ceil($allpage/$pageperstage);        // how many page will it be ? 
	if(trim($startpage)==""){$startpage=1;} 
	if(trim($_GET[nowstage])==""){$_GET[nowstage]=1;} 
	if(trim($_GET[nowpage])==""){$_GET[nowpage]=$startpage;} 
	$StartRow = 0;
	if (empty($_GET[nowpage])){
    	if($StartRow == 0){$_GET[nowpage] = $StartRow + 1;}
	}
	else{
    	$nowpage = $_GET[nowpage];
		$StartRow = ($nowpage - 1) * $displayperpage;
	}
	$c=1;
	$sql="SELECT P1.*, P2.sTitle FROM tblpromoemailsubject P1
	INNER JOIN tblpromoemails P2 ON P1.nPromoEmail_ID = P2.nPromoEmail_ID
	ORDER BY P1.sSubject limit $StartRow,$displayperpage";

	$result=$dbo->select($sql);
	if(!empty($result)){$num1 = $number = $dbo->nr($result);}


?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Affiliate System</li>
			<li class="active"> Promo Email Templates</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?> <span class="success">
			<?php if($_GET[act]=="upsus") { echo "Email subject line has been updated successfully<br><br>"; }?>
			<?php if($_GET[act]=="dsus") { echo "Email subject line has been deleted successfully <br><br>"; }?>
			</span>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title"> Email Subject Lines - <a href="add_email_subject.php"><strong>Add New</strong></a></h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead>
								<tr>
									<th>Subject Line</th>
									<th>Email This Is Linked To</th>
									<th colspan="3">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php
				if(!empty($result)){
					while($row=$dbo->getobj($result)){
			?>
								<tr>
									<td ><?php echo $row->sSubject;?></td>
									<td  width="250"><?php echo $row->sTitle;?></td>
									<td  align="center" width="10"><?php if ($row->nDisplay==0) { ?>
										<a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=1&projid=<?php echo $row->nPromoEmailSubject_ID?>" class="black"> <img src="images/adult_r.gif" alt="Not Active" width="16" height="16" border="0"></a>
										<?php } else { ?>
										<a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=0&projid=<?php echo $row->nPromoEmailSubject_ID?>" class=black> <img src="images/adult_off.gif" alt="Active" width="16" height="16" border="0"></a>
										<?php }?></td>
									<td  align="center" width="10"><a class="grid" href="edit_email_subject.php?act=e&amp;id=<?php echo $row->nPromoEmailSubject_ID;?>" title="Edit Email Subject"> <img src="images/edit.gif" alt="Edit Email Subject" border="0"></a></td>
									<td  align="center" width="10"><a class="grid" href="email_subject.php?act=d&amp;id=<?php echo $row->nPromoEmailSubject_ID;?>" title="Delete Email Subject"  OnClick="return cdel('employer');"> <img src="images/delete.gif" alt="Delete Email Subject" border="0"></a></td>
								</tr>
								<?php }
}
else{?>
								<tr>
									<td colspan="5" class="gridrow2"><strong>No Subject Lines Exist! - <a href="add_email_subject.php"><strong>Add New Subject Line </strong></a></strong></td>
								</tr>
								<?php }
?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">
function cdel(w) {
if(confirm("Are you sure that you want to delete this email subject line?"))
{
	return true;
}
else
{
return false;
}
}
</script>
</body></html>