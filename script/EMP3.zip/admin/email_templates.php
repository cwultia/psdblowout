<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Email Templates';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
	
	if ( isset($_POST['Update']) ){
		$c = 0;
		if (empty($_POST["sSubject"])){
			$c++;
			$es = 1;
		}
		if (empty($_POST["sBody"])){
			$c++;
			$eb = 1;
		}
		if (empty($_POST["sBodyHtml"])){
			$c++;
			$ebh = 1;
		}
		if ($c == 0)
		{
			$sql = sprintf("UPDATE tblemailtemplates SET 
	sSubject='%s', sBody = '%s',sBodyHtml = '%s' WHERE nEmail_ID = '%s';", $dbo->format($_POST["sSubject"]), $dbo->format($_POST["sBody"]), $_POST["sBodyHtml"],$dbo->format($_POST["nEmail_ID"]) );
			$dbo->update($sql);
			header("location:email_templates.php?nEmail_ID=".$_POST["nEmail_ID"].'&msg=Email Template Updated Successfuly!');
		}}
	 
	if(!is_numeric($_REQUEST["nEmail_ID"])) $_REQUEST["nEmail_ID"] = 5;
	
	$rw = $dbo->getobject("SELECT sSubject, sBody, sBodyHtml,sTags FROM tblemailtemplates WHERE nEmail_ID = '".$dbo->format($_REQUEST["nEmail_ID"])."';");
	
	// Some email templates are not in use, lets block them.
	$noload = '"MEMBER_UPGRADE", "MEMBER_SUBSCRIPTION_RENEWAL", "ADMIN_UPGRADE"';
	
	$query = "SELECT nEmail_ID, sTitle FROM tblemailtemplates WHERE sType NOT IN ($noload) ORDER BY sTitle";
	$res = $dbo->select($query);
	//die($query);
	$rwEmail = $chkSsettings;

	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Emails</li>
			<li class="active">Email Templates</li>
		</ol>
	</section>
	<section class="content">
		<?php if ($message) { echo $message; } ?>
		<div class="col-md-8">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title"> Email Templates </h3>
				</div>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-md-3 control-label" for="name">Load Template</label>
						<div class="col-md-9">
							<select name="nEmail_ID" id="nEmail_ID" onChange="window.location.href='?nEmail_ID='+this.value" class="form-control">
								<?php
										while( $row = $dbo->getobj($res)){
											$selected = "";
											if($_REQUEST["nEmail_ID"] == $row->nEmail_ID){
												$selected = "selected";
											}
										$noUseEmails = array('1','2','3','4','8','11','16');
										if(!in_array($row->nEmail_ID,$noUseEmails )){?>
								<option <?php echo $selected ?> value="<?php echo $row->nEmail_ID ?>"><?php echo $row->sTitle ?></option>
								<?php	
										}}
									?>
							</select>
						</div>
					</div>
					<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="f1">
						<input type="hidden" name="nEmail_ID" value="<?php echo $_REQUEST["nEmail_ID"]?>">
						<div class="form-group">
							<label class="col-md-3 control-label" for="sSubject">Subject <font color="Red"> * </font></label>
							<div class="col-md-9">
								<input name="sSubject" type="text" value="<?php echo stripslashes($rw->sSubject);?>" class="form-control">
							</div>
						</div>
						<br />
						<br />
						<div class="form-group">
							<label class="col-md-3 control-label" for="name">Text Body</label>
							<div class="col-md-9">
								<textarea name="sBody" cols="50" rows="10" class="form-control"><?php echo stripslashes($rw->sBody);?></textarea>
								<?php if ($eb == 1) { ?>
								<span class="red">[ INVALID ]</span>
								<?php } ?>
							</div>
						</div>
						<br />
						<br />
						<div class="form-group">
							<label class="col-md-3 control-label" for="name">Html Body</label>
							<div class="col-md-9">
								<textarea name="sBodyHtml" cols="50" rows="10" id="sBodyHtml" class="tinymce_full"><?php echo stripslashes($rw->sBodyHtml);?></textarea>
								<?php if ($eb == 1) { ?>
								<span class="red">[ INVALID ]</span>
								<?php } ?>
							</div>
						</div>
						<input type="hidden" name="nEmail_ID" value="<?php echo $_REQUEST["nEmail_ID"]?>">
						<input type="submit" name="Update" value="Save Changes" class="btn btn-primary btn-responsive" />
					</form>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title"> Available Tags </h3>
				</div>
				<div class="panel-body">
					<?php 
					$tags = unserialize($rw->sTags);
					foreach($tags as $k=>$v){echo '<p><strong>'.$k.'</strong> - '.$v.'</p>';}
					?>
				</div>
			</div>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
if(get_option('use_mce') == '1'){
	$doc_base = $chkSsettings->sSiteURL .'/'; ?>
<script  src="vendors/tinymce/js/tinymce/tinymce.min.js" type="text/javascript" ></script> 
<script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
<?php } ?>
</body></html>