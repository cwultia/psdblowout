<?php
require_once '../conn.php';
require_once '../functions.php';

	$page = $_GET['plugin'];
	$title = 'Add New Video';
	$title = pluginClass::filter("admin_expanded_title",$title);
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
require_once('header.php');
	?>
   <aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li class="active"> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
    </ol>
  </section>
  <section class="content">
  <div class="col-md-12">
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
		<?php include_once 'plugin-sidebar.php'; ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
        <?php echo isset($message) ? $message : '' ?>
        
        <?php 
		$k = $_GET['plugin'];
		$v = pluginClass::get_page($_GET['plugin']);
		if(is_callable(array($k,$v))){echo call_user_func(array($k,$v));}
		else{echo '<h1>Error: The Requested Page Could Not Be Loaded ...</h1>';}
		
		?>
        
        </td>
    </tr>
    </table>
	</div>
    </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
echo $javascript = pluginClass::filter("admin_expanded_javascript",$javascript);
?>
	</body>
    </html>