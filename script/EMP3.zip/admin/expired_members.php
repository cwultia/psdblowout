<?php
include_once ('../conn.php');
include_once ('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Expired Members';
	$css = <<<EOT
<!--page level css -->

<!-- daterange picker -->
<link href="vendors/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />

<!--end of page level css-->
EOT;

	// Permanently expire a user
	if (isset($_GET['action']) && $_GET['action']=='expire') {
		
		
		if ( isset($_GET['userid']) && is_numeric($_GET['userid']) && isset($_GET['levelid']) && is_numeric($_GET['levelid']))  {
			
		
				$nToday = date('Ymd');
				$sql = 'UPDATE tbluserlevels SET nActive = 0 WHERE nUser_ID=' . $_GET['userid'] . ' AND nLevel_ID=' . $_GET['levelid'];
				$dbo->update($sql);
				
				// Send email to user
				email_member_expiry($_GET['userid'], $_GET['levelid']);
		
				$bExpireSuccess = 1;
		}}
	
	// Setup Options for Members per Page listing
	$aMPP = array('5', '10', '15', '20', '25', '50', '100');
	$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];
	
	// Check If Expirations Are Handled Manually.
	$autoprocess = get_option('auto_process_expired');
	
	$nDateToday = date("Ymd");
	
	require_once('header.php');
	
	$sql = "SELECT U.sForename 
	FROM tblusers U 
	INNER JOIN tbluserlevels UL ON U.nUser_ID = UL.nUser_ID
	INNER JOIN tblmembershiplevels M ON M.nLevel_ID = UL.nLevel_ID
	WHERE U.nUser_ID > 1 AND UL.nDateExpires <= $nDateToday AND UL.nActive = 1;
	";
	
	$number = ($dbo->num_rows($sql)) ? $dbo->num_rows($sql) : 0; // Number of records
				
	// Start Paging
	/*********************************************************/
	include_once('paging.php');
	$objPaging = new Paging();
	
	$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
	unset($_GET['start']);
		
	$objPaging->Total_Records_Per_Page = $mpp; 
	$objPaging->Total_Records = $number;
	$index = $start ;
	$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
	$objPaging->prepare_ParameterString($_GET);
	$objPaging->set_Start_Item($indexupto); 	 		 	
	$objPaging->Has_First_Last = true;	
	$navigator = $objPaging->Create_Paging();
	$pageinfo = $objPaging->get_PageInfo();	 	
	$counter = 0;  
	
	$sql = "SELECT 
	U.nUser_ID,
	U.sForename,
	U.sSurname,
	U.nJoinDate,
	UL.nDateExpires,
	UL.nUserLevel_ID,
	M.nLevel_ID,
	M.sLevel,
	P.sPlanName
	FROM tblusers U 
	INNER JOIN tbluserlevels UL ON U.nUser_ID = UL.nUser_ID
	INNER JOIN tblmembershiplevels M ON M.nLevel_ID = UL.nLevel_ID
	INNER JOIN tblpaymentplans P ON P.nPaymentPlan_ID = UL.nPaymentPlan_ID
	WHERE U.nUser_ID > 1 AND UL.nDateExpires < $nDateToday AND UL.nActive = 1";
	
	switch ($_GET['sort']) {
		case 'fname':
			$sortfield = 'U.sForename';
			break;
		case 'lname':
			$sortfield = 'U.sSurname';
			break;
		case 'joindate':
			$sortfield = 'U.nJoinDate';
			break;
		case 'expirydate':
			$sortfield = 'UL.nDateExpires';
			break;
		case 'level':
			$sortfield = 'M.sLevel';
			break;
		case 'plan':
			$sortfield = 'P.sPlanName';
			break;
		default:
			$sortfield = 'UL.nDateExpires,U.sSurname';}

	$sql .= sprintf("ORDER BY %s %s ", $sortfield, $dbo->format($_GET['type'])); // Adding order by to main query
	
	$sql .= "LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
	/*********************************************************/
	
	$result = $dbo->select($sql);
	
	$qs = sprintf("?start=%s&mpp=%s", $start, $mpp);
	
	// Set Total Members Display
	$total_members = "Total Expired Members: <b>".$number."</b>";
	
	
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Members</li>
      <li class="active">Expired Members</li>
    </ol>
  </section>
  <section class="content">
  <?php if (isset($message))  echo $message ?>
	<h3>This page allows you to view all expired memberships that HAVE NOT been deactivated.</h3>
     <div class="col-md-12"> <div style="text-align:right">Members per page&nbsp;
                <select id='mpp' style='height:1.5em' onChange="updateMPP(this)">
                  <?php
								foreach ($aMPP as $val) {
									$selected = ($val == $mpp) ? 'selected' : '';;
									echo "<option value='$val' $selected>$val</option>";
								}
							?>
                </select></div></div>
          <!-- LISTING HEADER -->
           <div class="col-md-12"> 
      <!-- BEGIN SAMPLE TABLE PORTLET-->
      <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Member List </div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
            <tr> 
              <!-- FIRST NAME COLUMN -->
              <th><?php if ($_GET['sort'] == 'fname' && $_GET['type'] == 'asc') { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=fname&type=desc" class="bluenave">First</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=fname&type=asc" class="bluenave">First </a>
                <?php } ?>
                /
                <?php 	if ($_GET['sort'] == "lname" && $_GET['type'] == "asc") { 	?>
                <a href="expired_members.php<?php echo $qs?>&sort=lname&type=desc" class="bluenave">Last Name</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=lname&type=asc" class="bluenave">Last Name</a>
                <?php } ?></th>
              <th><?php if ($_GET['sort'] == "level" && $_GET['type'] == "asc") { 	?>
                <a href="expired_members.php<?php echo $qs?>&sort=level&type=desc" class="bluenave">Membership Level</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=level&type=asc" class="bluenave">Membership Level</a>
                <?php } ?></th>
              <!-- LAST NAME COLUMN --> 
              <!-- EMAIL COLUMN -->
              <th><?php 	if ($_GET['sort'] == "plan" && $_GET['type'] == "asc") { 	?>
                <a href="expired_members.php<?php echo $qs?>&sort=plan&type=desc" class="bluenave">Payment Plan</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=plan&type=asc" class="bluenave">Payment Plan</a>
                <?php } ?></th>
              <!-- JOIN DATE COLUMN -->
              <th><?php if ($_GET['sort'] == "joindate" && $_GET['type'] == "asc") { 	?>
                <a href="expired_members.php<?php echo $qs?>&sort=joindate&type=desc" class="bluenave">Join Date</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=joindate&type=asc" class="bluenave">Join Date</a>
                <?php } ?></th>
              <!-- EXPIRY DATE COLUMN -->
              <th><?php if ($_GET['sort'] == "expirydate" && $_GET['type'] == "asc") { 	?>
                <a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=desc" class="bluenave">Expiry Date</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=asc" class="bluenave">Expiry Date</a>
                <?php } ?></th>
              <!-- LEVEL NAME COLUMN -->
              <th><?php if ($_GET['sort'] == "expirydate" && $_GET['type'] == "asc") { 	?>
                <a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=desc" class="bluenave">Days Expired</a>
                <?php } else { ?>
                <a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=asc" class="bluenave">Days Expired</a>
                <?php } ?></th>
              <!-- AFFILIATE -->
              <th>
              	Actions
              </th>
            </tr>
            </thead>
            <tbody>
            <?php
				// Add Sort to QueryString
				$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['type']);
				if ($dbo->nr($result) !==0) {
					die(var_dump($dbo->nr($result)));
					while ($row = $dbo->getobj($result)) {
						
						$exptime = strtotime(fShowDate('4',$row->nDateExpires));
						$datediff = time() - $exptime;
						$daysExp =  floor($datediff/(60*60*24));
				?>
            <!-- MEMBER LISTING -->
            <tr>
              <td>
              	<a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID ?> " title="View Member Details"><?php echo $row->sForename; ?></a> <a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID ?> " title="View Member Details"><?php echo $row->sSurname; ?></a>
              </td>
              <td><?php echo $row->sLevel; ?></td>
              <td><?php echo $row->sPlanName ?></td>
              <td><?php echo fShowDate($chkSsettings->nDateFormat, $row->nJoinDate); ?>&nbsp;</td>
              <td>
              	<div id="showExpire_<?php echo $row->nUserLevel_ID ?>"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?></div>
                <div style="display:none" id="changeExpire_<?php echo $row->nUserLevel_ID ?>">
                  <form action="actions.php?type=member" method="post">
                    <input name="newExpire" type="text" readonly size="10" class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?>">
                    <input type="hidden" name="userLevelId" value="<?php echo $row->nUserLevel_ID ?>" />
                    <input type="hidden" name="act" value="changeExpiredDate" />
                    <br>
                    <input type="button" name="button2" id="button2" value="Cancel" onClick="changeExpire('hide','<?php echo $row->nUserLevel_ID ?>')">
                    <input type="submit" name="button" id="button" value="Update">
                  </form>
                </div></td>
              <td><?php echo $daysExp ?></td>
              <td><form action="actions.php?type=member" method="post">
                  <input type="submit" class="inputsubmitb" value="Deactivate" onClick="return confirm('Are you sure you want to Deactivate This Level?');">
                  <input type="hidden" name="act" value="deactivateExpired" />
                  <input type="hidden" name="userLevelId" value="<?php echo $row->nUserLevel_ID ?>" />
                </form></td>
              <td><input type="button" class="inputsubmitb" value="Change Expiry Date" onClick="changeExpire('show','<?php echo $row->nUserLevel_ID ?>')"></td>
            </tr>
            <?php 
					} 
				}
				else{ ?>
                    <tr>
                      <td colspan="8" >No Expired Memberships </td>
                    </tr>
            <?php } ?>
            </tbody>
          </table>
          <div class="row">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script language="javascript" type="text/javascript"> 
		function cdel(w) {
			return confirm("Are you sure that you want to delete this member?");
		}
		
		function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=<?php echo empty($_GET['start']) ? 0 : $_GET['start'] ?>';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}

		function expireUser(id, levelid, name) {
			var qs = '?start=<?php echo empty($_GET['start']) ? 0 : $_GET['start'] ?>';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			
			if (confirm("Are you sure you want to expire user " + name + " permanently?")) {
				document.location.href = "expired_members.php" + qs + "&action=expire&userid=" + id + "&levelid=" + levelid;
			}	
		}
		function changeExpire(act,levelid){
			
			if(act == 'show'){
				$("#changeExpire_"+levelid).show();
				$("#showExpire_"+levelid).hide();
			}
			else{
				$("#changeExpire_"+levelid).hide();
				$("#showExpire_"+levelid).show();
			}
			
			
		}
		$(function(){
			$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		});
	</script>
</body></html>