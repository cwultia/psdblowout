<?php
include_once ('../conn.php');
include_once ('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'File Management';
	$css = <<<EOT
<!--page level css -->

<!--end of page level css-->
EOT;

	/***************************/
	/*		 MK - Added 08/20/2007			*/
	/***************************/
	
	$ctid = (isset($_REQUEST['ctid'])) ? $_REQUEST['ctid'] : 0; // Category ID
	$ft = (isset($_REQUEST['ft'])) ? $_REQUEST['ft'] : ''; // File Type
	$ipp = (!empty($_GET['ipp'])) ? $_GET['ipp'] : 10; // Items per Page
	$sort = (!empty($_GET['sort'])) ? $_GET['sort'] : 'nFile_ID';
	$sortdir = (!empty($_GET['sortdir'])) ? $_GET['sortdir'] : 'ASC';
	$start = (!empty($_GET['start'])) ? $_GET['start'] : 0;
	
	// Set QueryString Values after post
	if (isset($_POST['Update'])) {
		$ctid = $_POST['ctid'];
		$ipp = $_POST['ipp'];
		$sort = $_POST['sort'];
		$sortdir = $_POST['sortdir'];
		$start = $_POST['start'];
	}
	
	// Setup Options for Items per Page listing
	$aIPP = array('5', '10', '15', '20', '25', '50', '100');
	
	// DELETE FILE
	if ($_GET['act'] == 'd') {
		$row = $dbo->getrow("SELECT sFilename FROM tblfiles WHERE nFile_ID = '" . $dbo->
			format($_GET['flid']) . "'");
		$file = dirname(__file__) . "/assets/" . $row['sFilename'];
		if (file_exists($file) && !is_dir($file)) {
			unlink($file);
		}
		$dbo->delete("DELETE FROM tblfiles WHERE nFile_ID = " . $dbo->format($_GET['flid']));
		$message = "<p class='success'>File has been deleted.</p>";
	}
	
	// LOCK/UNLOCK FILES
	if (isset($_GET['lock']) && is_numeric($_GET['lock'])) {
		if (isset($_GET['id']) && is_numeric($_GET['id'])) {
			$sql = "UPDATE tblfiles SET nMemberOnly=" . $dbo->format($_GET['lock']) . " WHERE nFile_ID=" . $dbo->format($_GET['id']);
			//die('here');
			$dbo->update($sql);
		}
	}
	
	// IMPORT FILES
	if ($_GET['act'] == 'imp') {
	
		$new = addFilesToDb('/');
		$removed = removeFilesFromDb();
		$msg = ($new > 0) ? $new . " file(s) imported. " : "No files to import. ";
		$msg .= ($removed > 0) ? $removed . " file(s) removed. " :
			"No files to remove. ";
		$message = "<p class='success'>$msg</p>";
	
	}
	
	// Get File Types List
	$aFile = array('All Files', 'AUDIO', 'DOC', 'EXCEL', 'EXE', 'FLASH', 'IMAGES',
		'PDF', 'VIDEO', 'ZIP');
	ksort($aFile);
	$filetype = '';
	foreach ($aFile as $item) {
		$selected = ($item == $ft) ? 'selected' : '';
		$filetype .= sprintf("<option value='%s' %s>%s</option>", $item, $selected, $item);
	}
	
	// NOT CURRENTLY BEING USED
	// UPDATE PAGE DISPLAY ORDER, NAVBARLOCATION and MEMBERSHIP LEVEL
	if (isset($_POST['Update'])) {
		$st = $_POST['dd']; // nPage_ID
		$loc = $_POST['location']; // sNavBarLocation
		$disp = $_POST['disp']; // nSortOrder
		$mLvl = $_POST['mlevel']; // nLevel_ID
		for ($i = 0; $i < count($_POST['dd']); $i++) {
			$sql = sprintf("UPDATE tblpages 
										SET nSortOrder = '%s', sNavBarLocation = '%s', nLevel_ID = '%s'
										WHERE nPage_ID = '%s'", $dbo->format($disp[$i]), $dbo->format($loc[$i]),
				$dbo->format($mLvl[$i]), $dbo->format($st[$i]));
			$dbo->update($sql);
		}
		$message = "<p class='success'>Page updates have been completed.</p>";
	}
	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Content</li>
      <li class="active">Files</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12"> 
      <!-- Start Content -->
      <?php

/***************************/
/*      MK - Updated 08/20/07			*/
/***************************/

$sql = "SELECT * FROM tblfiles ";

// Filter by File Type
switch ($ft) {
    case 'DOC':
        $qry = "WHERE sType LIKE '%msword%' ";
        break;
    case 'IMAGES':
        $qry = "WHERE sType LIKE 'image%' ";
        break;
    case 'ZIP':
        $qry = sprintf("WHERE sType LIKE '%%%s%%' OR sType LIKE '%%compress%%' ",
            strtolower($ft));
        break;
    case 'AUDIO':
    case 'EXCEL':
    case 'EXE':
    case 'FLASH':
    case 'PDF':
    case 'VIDEO':
        $qry = sprintf("WHERE sType LIKE '%%%s%%' ", strtolower($ft));
        break;
}

// Add WHERE clause
$sql .= $qry;

$sql .= sprintf("ORDER BY %s %s ", $sort, $sortdir);

// Get Count to pass into paging object
$rs = $dbo->select("SELECT COUNT(*) FROM tblfiles " . $qry);
$row = $row = $dbo->getarray($rs,'NUM');
$number = $row[0];

// Start Paging
/*********************************************************/
include_once ('paging.php');
$objPaging = new Paging();

unset($_GET['start']);

$objPaging->Total_Records_Per_Page = $ipp;
$objPaging->Total_Records = $number;
$index = $start;
$indexupto = $index + $objPaging->Total_Records_Per_Page;
$objPaging->prepare_ParameterString($_GET);
$objPaging->set_Start_Item($indexupto);
$objPaging->Has_First_Last = true;
$navigator = $objPaging->Create_Paging();
$pageinfo = $objPaging->get_PageInfo();
$counter = 0;
$sql .= "LIMIT " . $objPaging->Total_Records_Per_Page . " OFFSET " . $index;
/*********************************************************/
//echo $sql;

$result = $dbo->select($sql);

// Put together QueryString
$qs = sprintf("?ctid=%s&start=%s&ipp=%s&ft=%s", $ctid, $start, $ipp, $ft);
//echo $qs;

?>
     <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> File Management </div>
        </div>
        <div class="portlet-body flip-scroll">
        
        	<div class="row" style="padding-bottom:10px;">
                <input class="btn btn-primary btn-responsive" type="submit" onClick="document.location.href='add_file.php'" value="Upload Files" />
                &nbsp;&nbsp;&nbsp;&nbsp;
                <input class="btn btn-primary btn-responsive" type="button" onClick="document.location.href='file_management_add.php'" value="Add Remote File" />
                &nbsp;&nbsp;&nbsp;&nbsp;
                <input class="btn btn-primary btn-responsive" type="submit" onClick="document.location.href='file_management.php<?php echo $qs ?>&act=imp'" value="Sync FTP Files" />
                &nbsp;&nbsp;&nbsp;&nbsp; <span>Display:</span>
                <select name="ft" onChange="filterFiles(this)">
                  <?php echo $filetype ?>
                </select>
                <span style="padding-left:10px"></span> </div>
                <div class="row" style="padding-bottom:10px; width:50%; float:left;">Files: <?php echo $number ?></div>
              <div class="row" style="padding-bottom:10px; width:50%; float:left; text-align:right"> Items per page&nbsp;
                <select id='ipp' style='height:1.5em' onChange="updateIPP(this)" class="select2">
                  <?php
foreach ($aIPP as $val) {
    $selected = ($val == $ipp) ? 'selected' : '';
    ;
    echo "<option value='$val' $selected>$val</option>";
}
?>
                </select>
              </div>
              <div style="clear:both"></div>
          
            <form name="form1" method="post" action="file_management.php">
             <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content">
                  <!-- HEADINGS -->
                  <tr>
                    <th><?php $sd = ($sort == 'sFileName' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="file_management.php<?php echo $qs ?>&sort=sFileName&sortdir=<?php echo $sd ?>" class="bluenave">Filename</a></th>
                    <th><?php $sd = ($sort == 'sURL' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="file_management.php<?php echo $qs ?>&sort=sURL&sortdir=<?php echo $sd ?>" class="bluenave">Location</a></th>
                    <th><?php $sd = ($sort == 'sType' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="file_management.php<?php echo $qs ?>&sort=sType&sortdir=<?php echo $sd ?>" class="bluenave">File Type</a></th>
                    <th> Embed Code </th>
                    <th><?php $sd = ($sort == 'nMemberOnly' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="file_management.php<?php echo $qs ?>&sort=nMemberOnly&sortdir=<?php echo $sd ?>" class="bluenave">Member Only File?</a></th>
                    <th><?php $sd = ($sort == 'sType' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="file_management.php<?php echo $qs ?>&sort=sType&sortdir=<?php echo $sd ?>" class="bluenave">Downloads</a></th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
// Add Sort to QueryString
$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['sortdir']);
 if (!empty($result)){
    while ($row = $dbo->getobj($result)): ?>
                  <!-- PAGE LISTING -->
                  <tr> 
                    <!-- FILENAME -->
                    <td><?php echo $row->sFilename ?></td>
                    <!-- LOCATION -->
                    <td><?php echo empty($row->sURL) ? '<a href="' . $sSiteURL .  '/admin/assets/' . $row->sFilename . '" target="_blank">Local File</a>' : '<a href=' . $row->sURL . ' target="_blank">Remote URL</a>'; ?></td>
                    <!-- FILE TYPE -->
                    <td><?php echo $row->sType ?></td>
                    <!-- EMBED CODE -->
                    <td> [[file <?php echo $row->nFile_ID ?>]] </td>
                    <!-- MEMBER ONLY -->
                    <td><?php if ($row->nMemberOnly == 0) : ?>
                      <a href="file_management.php<?php echo $qs?>&id=<?php echo $row->nFile_ID; ?>&lock=1" class="black" title="This can currently be downloaded from the front end AND members area. Click the padlock to only allow members to download this file."><img src="images/icon_lock_open.png" alt="This can currently be downloaded from the front end AND members area. Click the padlock to only allow members to download this file." width="16" height="16" border="0" /></a>
                      <?php else : ?>
                      <a href="file_management.php<?php echo $qs?>&id=<?php echo $row->nFile_ID; ?>&lock=0" class=black title="This can currently be downloaded on member's pages only. Click the padlock to unlock it so that you can use this file on both front-end AND members pages."><img src="images/icon_lock.png" alt="This can currently be downloaded on member's pages only. Click the padlock to unlock it so that you can use this file on both front-end AND members pages." width="16" height="16" border="0" /></a>
                      <?php endif; ?></td>
                    <!-- DOWNLOADS -->
                    <td><?php echo $row->nDownloads ?></td>
                    <!-- ACTIONS -->
                    <td><!-- Delete --> 
                      <a href="file_management.php<?php echo $qs ?>&flid=<?php echo $row->nFile_ID; ?>&act=d" class="bluenew" OnClick="return cdel('<?php echo $row->sFilename ?>');" title="Delete Page"><img src="images/drop.jpg" alt="Delete Page" width="16" height="16" border="0" class="iconspacing"></a></td>
                  </tr>
                  <?php endwhile;}else{?>
                  <tr>
                    <td colspan="9">No Files Stored Yet.</td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
              <input type="hidden" id="act" name="act" value="">
              <input type="hidden" name="ctid" value="<?php echo $ctid ?>">
              <input type="hidden" name="ipp" value="<?php echo $ipp ?>">
              <input type="hidden" name="sort" value="<?php echo $sort ?>">
              <input type="hidden" name="sortdir" value="<?php echo $sortdir ?>">
              <input type="hidden" name="start" value="<?php echo $start ?>">
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<style>
			.iconspacing {margin-right:2px}	
		</style>
<script type="text/javascript">
			function cdel(w) {
				return confirm("Are you sure you want to DELETE the\n\""+w+"\" file?");
			}

			function openPopup(page) {	
				window.open(page,'','height=265,width=650,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');
			}
			
			function MM_openBrWindow(theURL,winName,features) {
				window.open(theURL,winName,features);
			}
			
			function filterFiles(oList) {
				var ft = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&ft=' + ft;
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=<?php echo $ipp ?>';
				document.location = 'file_management.php' + qs;
			}

			function updateIPP(oList) {
				var ipp = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&ft=<?php echo $ft ?>';
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=' + ipp;
				document.location = 'file_management.php' + qs;
			}
		</script>
</body></html>