<?php
include_once ('../conn.php');
include_once ('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add Remote File';
	$css = <<<EOT
<!--page level css -->

<!--end of page level css-->
EOT;

// Process form
if (isset($_POST['Submit'])) {
	// Trim
	$url = trim($_POST['sFileURL']);
	// Add Video URL to database
	$message = addRemoteFileToDb($url) ? "<span class='success'>File added to database successfully</span>" : "<span class='error'>There was a problem adding this file, please check the URL and try again.</span>";
}
require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Content</li>
			<li><a href="file_management.php">Files</a></li>
			<li class="active">Add Remote File</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Add Remote File</h3>
				</div>
				<div class="panel-body">
				<div class="form-group">
					<form id="formFile" method="post" action="file_management_add.php">
						<label class="col-md-2" for="sFileURL">Remote URL <span style="color: red">*</span></label>
								<div class="col-md-10"><input type="text" name="sFileURL" style="width: 500px;" class="url required" /><br>
									<small>e.g. http://www.somewebsite.com/uploads/file123.zip</small></div><br>

						<input name="Submit" type="submit" value="Submit" class="btn btn-primary btn-responsive">
					</form>
				</div>
			</div>
		</div>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php require_once('footer.php'); ?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#formFile").validate();
		});
</script>
</body></html>