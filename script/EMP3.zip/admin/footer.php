<div class="modal fade in" id="dialog-confirm" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<div class="modal-dialog">
		<div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Session Timeout Warning</h4>
                    </div>
                    <div class="modal-body">
                       <span class="countdown"></span>
				</div>
				<div class="modal-footer">
                   <button id="keepAlive_Stay" type="button" class="btn btn-success btn-responsive">Stay Logged In</button>
					<button type="button" id="keepAlive_Out" class="btn">Logout</button>
                 </div>
				</div>
		
	</div>
</div>
</div>
<a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Return to top" data-toggle="tooltip" data-placement="left"> <i class="livicon" data-name="plane-up" data-size="18" data-loop="true" data-c="#fff" data-hc="white"></i>
</a>
<!-- global js -->
<script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="../js/jquery.validate.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!--livicons-->
<script src="vendors/livicons/minified/raphael-min.js" type="text/javascript"></script>
<script src="vendors/livicons/minified/livicons-1.4.min.js" type="text/javascript"></script>
<script src="js/josh.js" type="text/javascript"></script>
<script src="js/metisMenu.js" type="text/javascript"></script>
<script src="vendors/holder-master/holder.js" type="text/javascript"></script>
<!-- EMP JS -->
<script src="common/js/empAdmin.js?version=3.1.4" type="text/javascript"></script>
<!-- end of global js -->
 <script type="text/javascript">
<?php
	// Load Session Keep Alive
	if($_SESSION['admin']){
		if(get_option('session_timeout_active')=='1'){
			
		?>
		$(document).ready(keepAlive(<?php echo intval(get_option('security_timeout')*60)?>,<?php echo $_SESSION['admin']['LAST_ACTIVITY']?>));
	<?php }
	}
?>
	getServerTime();
    </script>