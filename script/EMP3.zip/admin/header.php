<?php
	global $dbo;
	
	// RETRIEVE ADMIN INFO
	$objAdmin = $dbo->getobject("select * from tblusers where nUser_ID='". $_SESSION['admin']["nUser_ID"] . "'");
	
	$sql = "SELECT count(nCancellation_ID) from tblcancellations where nStatus = 0;";
	$result = $dbo->select($sql);
	if($result){
		$data = $dbo->getarray($result);
		$cancel_requests = $data[0];
	}
		
	// Support Link
	$supportLink = ($licenseData->type == 'developer' && isset($DEVOPTS['SUPPORTURL']))?$DEVOPTS['SUPPORTURL']:'http://www.easymemberpro.com/support';
	
	// Filter for Nav Menu Actives
	$navActive = array();
	$navActive['members'] = array('add_members','manage_members','email_members','expired_members','cancel_requests','import_members');
	$navActive['affiliates'] =  array('pay_affiliates','pay_affiliates_files','export_affiliates','unpaid_commissions','unpaid_commissions_add');
	$navActive['content'] =  array('page_management','directory_management','member_levels','file_management','file_management_add','add_file','video_management','video_management_add','add_page','edit_page');
	$navActive['plugins'] =  array('manage_plugins');
	$navActive['reports'] =  array('report_affiliates_top','report_members_level','report_members_30days','report_members_stickrate','report_refunds_level','report_revenue_30days','report_revenue');
	$navActive['admin_logs'] =  array('admin_logins','manage_transactions');
	$navActive['general_settings'] =  array('script_settings','user_fields','advanced_settings','manage_crons');
	$navActive['emails'] =  array('email_settings','autoresponder_settings','email_templates');
	$navActive['payment_settings'] =  array('coupons','payment_plans','payment_plans_add','payment_plans_details', 'payment_processors');
	$navActive['templates'] =  array('template_setup');
	$navActive['affiliate_system'] =  array('affiliate_management','promotional_emails','add_email_subject','add_promotional_emails','promotional_graphics','add_promotional_graphics','email_subject');
	$navActive['testing_tracking'] =  array('testing_tracking');
	$navActive['database'] =  array('manage_database','restore_database','delete_database');
	
	$navActive = pluginClass::filter("admin_nav_active",$navActive);
	
	// 
	
	
	
	
	
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?> | Easy Member Pro</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!-- global css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <link href="vendors/font-awesome-4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/styles/black.css" rel="stylesheet" type="text/css" id="colorscheme" />
    <link href="css/panel.css" rel="stylesheet" type="text/css"/>
    <link href="css/metisMenu.css" rel="stylesheet" type="text/css"/>
	<link href="css/pages/tables.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="vendors/animate/animate.min.css">
	
	<!--select css-->
	<link href="vendors/select2/select2.css" rel="stylesheet" />
	<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
	
	<!-- EMP CSS-->
	<link href="common/css/notifications.css" rel="stylesheet" />
    
    <!-- end of global css -->
    <?php echo isset ($css) ?  $css : '' ?>
	<?php echo pluginClass::filter("admin_head"); ?>
</head>

<body class="skin-josh">
    <header class="header">
        <a href="home.php" class="logo">
            <img src="" alt="EMP">
        </a>
        <nav class="navbar navbar-static-top" role="navigation">
            <!-- Sidebar toggle button-->
            <div>
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <div class="responsive_nav"></div>
                </a>
            </div>
            <div class="navbar-right">
               <ul class="nav navbar-nav">
                     
                    
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <!-- <img data-src="holder.js/35x35/#fff:#000" width="35" class="img-circle img-responsive pull-left" height="35" alt="riot"> -->
                            <div class="riot">
                                <div>
                                    <?php echo $objAdmin->sForename; ?>
                                    <span>
                                        <i class="caret"></i>
                                    </span>
                                </div>
                            </div>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- User image -->
                            <li class="user-header bg-light-blue">
                               <!-- <img data-src="holder.js/90x90/#fff:#000" class="img-responsive img-circle" alt="User Image"> -->
                                <p class="topprofiletext"><?php echo $objAdmin->sForename." ".$objAdmin->sSurname; ?></p>
                            </li>
                            <!-- Menu Body -->
                            <li>
                                <a href="view_member.php?id=<?php echo $_SESSION['admin']['nUser_ID']?>">
                                    <i class="livicon" data-name="user" data-s="18"></i>
                                    My Profile
                                </a>
                            </li>
                            <li role="presentation"></li>
                            
                            <!-- Menu Footer-->
                            <li>
                                
                               
                                    <a href="lout.php">
                                        <i class="livicon" data-name="sign-out" data-s="18"></i>
                                        Logout
                                    </a>
                                
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="left-side sidebar-offcanvas">
            <section class="sidebar ">
                <div class="page-sidebar  sidebar-nav">
                   <!-- <div class="nav_icons">
                        <ul class="sidebar_threeicons">
                            <li>
                                <a href="form_builder.php">
                                    <i class="livicon" data-name="hammer" title="Form Builder 1" data-loop="true" data-color="#42aaca" data-hc="#42aaca" data-s="25"></i>
                                </a>
                            </li>
                            <li>
                                <a href="form_builder2.php">
                                    <i class="livicon" data-name="list-ul" title="Form Builder 2" data-loop="true" data-color="#e9573f" data-hc="#e9573f" data-s="25"></i>
                                </a>
                            </li>
                            <li>
                                <a href="buttonbuilder.php">
                                    <i class="livicon" data-name="vector-square" title="Button Builder" data-loop="true" data-color="#f6bb42" data-hc="#f6bb42" data-s="25"></i>
                                </a>
                            </li>
                            <li>
                                <a href="gridmanager.php">
                                    <i class="livicon" data-name="new-window" title="Form Builder 1" data-loop="true" data-color="#37bc9b" data-hc="#37bc9b" data-s="25"></i>
                                </a>
                            </li>
                        </ul>
                    </div> -->
                    <div class="clearfix"></div>
                    <!-- BEGIN SIDEBAR MENU -->
                    <ul id="menu" class="page-sidebar-menu">
                        <li <?php if($page == 'home') echo 'class="active"'; ?> >
                            <a href="home.php">
                                <i class="livicon" data-name="home" data-size="18" data-c="#418BCA" data-hc="#418BCA" data-loop="true"></i>
                                <span class="title">Dashboard</span>
                            </a>

                        </li>
                        <li <?php if(in_array($page,$navActive['members']))  echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="users" data-size="18" data-c="#00bc8c" data-hc="#00bc8c" data-loop="true"></i>
                                <span class="title">Members</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'add_members') echo 'class="active" id="active"'; ?> >
                                    <a href="add_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Add Members
                                    </a>
                                </li>
                                <li <?php if($page == 'manage_members') echo 'class="active" id="active"'; ?> >
                                    <a href="manage_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Manage Members
                                    </a>
                                </li>
                                <li <?php if($page == 'email_members') echo 'class="active" id="active"'; ?> >
                                    <a href="email_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Email Members
                                    </a>
                                </li>
                                <li <?php if($page == 'expired_members') echo 'class="active" id="active"'; ?> >
                                    <a href="expired_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Expired Members
                                    </a>
                                </li>
                                <li <?php if($page == 'cancel_requests') echo 'class="active" id="active"'; ?> >
                                    <a href="cancel_requests.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Cancel Requests
                                    </a>
                                </li>
                                <li <?php if($page == 'export_members') echo 'class="active" id="active"'; ?> >
                                    <a href="export_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Export Members
                                    </a>
                                </li>
                                <li <?php if($page == 'import_members') echo 'class="active" id="active"'; ?> >
                                    <a href="import_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Import Members
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_users"); ?>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['affiliates']))  echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="doc-portrait" data-c="#5bc0de" data-hc="#5bc0de" data-size="18" data-loop="true"></i>
                                <span class="title">Affiliates</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'pay_affiliates') echo 'class="active" id="active"'; ?> >
                                    <a href="pay_affiliates.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Pay Affiliates
                                    </a>
                                </li>
                                <li <?php if($page == 'pay_affiliates_files') echo 'class="active" id="active"'; ?> >
                                    <a href="pay_affiliates_files.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Affiliate Files
                                    </a>
                                </li>
                                <li <?php if($page == 'email_affiliates') echo 'class="active" id="active"'; ?> >
                                    <a href="email_members.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Email Affiliates
                                    </a>
                                </li>
                                <li <?php if($page == 'export_affiliates') echo 'class="active" id="active"'; ?> >
                                    <a href="export_affiliates.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Export Affiliates
                                    </a>
                                </li>
                                <li <?php if($page == 'unpaid_commissions' || $page == 'unpaid_commissions_add') echo 'class="active" id="active"'; ?> >
                                    <a href="unpaid_commissions.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Unpaid Commissions
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_affiliates"); ?>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['content'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="brush" data-c="#F89A14" data-hc="#F89A14" data-size="18" data-loop="true"></i>
                                <span class="title">Content</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if(($page == 'page_management') || ($page == 'add_page') || ($page == 'edit_page')) echo 'class="active" id="active"'; ?> >
                                    <a href="page_management.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Pages
                                    </a>
                                </li>
                                <li <?php if($page == 'directory_management') echo 'class="active" id="active"'; ?> >
                                    <a href="directory_management.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Directories
                                    </a>
                                </li>
                                <li <?php if($page == 'member_levels') echo 'class="active" id="active"'; ?> >
                                    <a href="member_levels.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Member Levels
                                    </a>
                                </li>
                                <li <?php if($page == 'file_management' || $page == 'file_management_add' || $page == 'add_file') echo 'class="active" id="active"'; ?> >
                                    <a href="file_management.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Files
                                    </a>
                                </li>
                                <li <?php if($page == 'video_management' || $page == 'video_management_add') echo 'class="active" id="active"'; ?> >
                                    <a href="video_management.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Videos
                                    </a>
                                </li>
                              <?php echo pluginClass::filter("admin_menu_content"); ?>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['plugins'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="lab" data-c="#EF6F6C" data-hc="#EF6F6C" data-size="18" data-loop="true"></i>
                                <span class="title">Plugins</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'manage_plugins') echo 'class="active" id="active"'; ?> >
                                    <a href="manage_plugins.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Manage Plugins
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['reports'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="table" data-c="#418BCA" data-hc="#418BCA" data-size="18" data-loop="true"></i>
                                <span class="title">Reports</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'report_affiliates_top') echo 'class="active" id="active"'; ?> >
                                    <a href="report_affiliates_top.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Top 25 Affiliates
                                    </a>
                                </li>
                                
                                <li <?php if($page == 'report_members_level') echo 'class="active" id="active"'; ?> >
                                    <a href="report_members_level.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Members By Level
                                    </a>
                                </li>
                                <li <?php if($page == 'report_members_30days') echo 'class="active" id="active"'; ?> >
                                    <a href="report_members_30days.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Members In Last 30 Days
                                    </a>
                                </li>
                                <li <?php if($page == 'report_members_stickrate') echo 'class="active" id="active"'; ?> >
                                    <a href="report_members_stickrate.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Member Stick Rate
                                    </a>
                                </li>
                                <li <?php if($page == 'report_refunds_level') echo 'class="active" id="active"'; ?> >
                                    <a href="report_refunds_level.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Refunds By Level
                                    </a>
                                </li>
                                <li <?php if($page == 'report_revenue_30days') echo 'class="active" id="active"'; ?> >
                                    <a href="report_revenue_30days.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Revenue In Last 30 Days
                                    </a>
                                </li>
                                <li <?php if($page == 'report_revenue') echo 'class="active" id="active"'; ?> >
                                    <a href="report_revenue.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Revenue By Month
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_tools_reports"); ?>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['admin_logs'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="barchart" data-size="18" data-c="#00bc8c" data-hc="#00bc8c" data-loop="true"></i>
                                <span class="title">Admin Logs</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'admin_logins') echo 'class="active" id="active"'; ?> >
                                    <a href="admin_logins.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Admin Logins
                                    </a>
                                </li>
                                <li <?php if($page == 'manage_transactions') echo 'class="active" id="active"'; ?> >
                                    <a href="manage_transactions.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Transaction Logs
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_tools"); ?>
                            </ul>
                        </li>
                        <li <?php  if(in_array($page,$navActive['general_settings'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="mail" data-size="18" data-c="#5bc0de" data-hc="#5bc0de" data-loop="true"></i>
                                <span class="title">General Settings</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'script_settings') echo 'class="active" id="active"'; ?> >
                                    <a href="script_settings.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Site Settings
                                    </a>
                                </li>
                                <li <?php if($page == 'user_fields') echo 'class="active" id="active"'; ?> >
                                    <a href="user_fields.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        User Fields
                                    </a>
                                </li>
                                <li <?php if($page == 'advanced_settings') echo 'class="active" id="active"'; ?> >
                                    <a href="advanced_settings.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Advanced Settings
                                    </a>
                                </li>
                                <li <?php if($page == 'manage_crons') echo 'class="active" id="active"'; ?> >
                                    <a href="manage_crons.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Manage Cron Jobs
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_settings_general"); ?>
                            </ul>
                        </li>
                        <li <?php  if(in_array($page,$navActive['emails'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="mail" data-size="18" data-c="#5bc0de" data-hc="#5bc0de" data-loop="true"></i>
                                <span class="title">Emails</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'email_settings') echo 'class="active" id="active"'; ?> >
                                    <a href="email_settings.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Email Settings
                                    </a>
                                </li>
                                <li <?php if($page == 'autoresponder_settings') echo 'class="active" id="active"'; ?> >
                                    <a href="autoresponder_settings.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Autoresponders
                                    </a>
                                </li>
                                <li <?php if($page == 'email_templates') echo 'class="active" id="active"'; ?> >
                                    <a href="email_templates.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Templates
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_settings_email"); ?>
                            </ul>
                        </li>
                        <li <?php  if(in_array($page,$navActive['payment_settings'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="users" data-size="18" data-c="#00bc8c" data-hc="#00bc8c" data-loop="true"></i>
                                <span class="title">Payment Settings</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'coupons') echo 'class="active" id="active"'; ?> >
                                    <a href="coupons.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Coupons
                                    </a>
                                </li>
                                <li <?php if($page == 'payment_plans' || $page == 'payment_plans_add' || $page == 'payment_plans_details') echo 'class="active" id="active"'; ?> >
                                    <a href="payment_plans.php?action=reset">
                                        <i class="fa fa-angle-double-right"></i>
                                        Payment Plans
                                    </a>
                                </li>
                                <li <?php if($page == 'payment_processors') echo 'class="active" id="active"'; ?> >
                                    <a href="payment_processors.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Payment Processors
                                    </a>
                                </li>
                                 <?php echo pluginClass::filter("admin_menu_settings_payments"); ?>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['templates'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="lab" data-c="#EF6F6C" data-hc="#EF6F6C" data-size="18" data-loop="true"></i>
                                <span class="title">Templates</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'template_setup') echo 'class="active" id="active"'; ?> >
                                    <a href="template_setup.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Template Setup
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_settings_templates"); ?>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['affiliate_system'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="lab" data-c="#EF6F6C" data-hc="#EF6F6C" data-size="18" data-loop="true"></i>
                                <span class="title">Affiliate System</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'affiliate_management') echo 'class="active" id="active"'; ?> >
                                    <a href="affiliate_management.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Affiliate Settings
                                    </a>
                                </li>
								<li <?php if($page == 'promotional_emails' || $page == 'add_promotional_emails') echo 'class="active" id="active"'; ?> >
                                    <a href="promotional_emails.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Promo Email Templates
                                    </a>
                                </li>
								<li <?php if($page == 'add_email_subject' || $page == 'email_subject') echo 'class="active" id="active"'; ?> >
                                    <a href="email_subject.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Promo Email Subjects
                                    </a>
                                </li>
								<li <?php if($page == 'add_promotional_graphics' || $page == 'promotional_graphics') echo 'class="active" id="active"'; ?> >
                                    <a href="promotional_graphics.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Promo Graphics
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li <?php if(in_array($page,$navActive['testing_tracking'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="lab" data-c="#EF6F6C" data-hc="#EF6F6C" data-size="18" data-loop="true"></i>
                                <span class="title">Testing & Tracking</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'testing_tracking') echo 'class="active" id="active"'; ?> >
                                    <a href="testing_tracking.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        SEO Options
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_settings_testing"); ?>
                            </ul>
                        </li>
                        <li <?php  if(in_array($page,$navActive['database'])) echo 'class="active"'; ?> >
                            <a href="#">
                                <i class="livicon" data-name="database" data-c="#5bc0de" data-hc="#5bc0de" data-size="18" data-loop="true"></i>
                                <span class="title">Database</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li <?php if($page == 'manage_database') echo 'class="active" id="active"'; ?> >
                                    <a href="manage_database.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Manage Database
                                    </a>
                                </li>
                                <li <?php if($page == 'restore_database') echo 'class="active" id="active"'; ?> >
                                    <a href="restore_database.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Restore Backups
                                    </a>
                                </li>
                                <li <?php if($page == 'delete_database') echo 'class="active" id="active"'; ?> >
                                    <a href="delete_database.php">
                                        <i class="fa fa-angle-double-right"></i>
                                        Delete Backups
                                    </a>
                                </li>
                                <?php echo pluginClass::filter("admin_menu_database"); ?>
                            </ul>
                        </li>
                         <?php echo pluginClass::filter("admin_menu"); ?>
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
            </section>
        </aside>