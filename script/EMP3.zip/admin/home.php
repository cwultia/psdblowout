<?php 
	include_once('../conn.php');
	include_once('../functions.php');
	$VERSION = checkversion();
	
	$page = 'home';
	$title = 'Dashboard';
	
	if($licenseData->type == 'single') $displayLicenseType = 'Single Domain';
	elseif ($licenseData->type == 'unlimited') $displayLicenseType = 'Unlimited Domains';
	elseif ($licenseData->type == 'trial') $displayLicenseType = 'Free Trial (Single)';
	elseif ($licenseData->type == 'developer') $displayLicenseType = 'Developer Provided';
	
	##### Sales Stats #####
	// Get Sales Counts
	$todaySalesCount = $dbo->getval("SELECT count(nTransaction_ID) FROM `tbltransactions` WHERE DATE(dDateTime) = DATE(NOW()) AND nTransactionType_ID = '1'");
	// Get Last Week Sales
	$weekSalesCount = $dbo->getval("SELECT count(nTransaction_ID) FROM tbltransactions WHERE dDateTime >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND dDateTime < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY AND nTransactionType_ID = '1'");
	// Last Month Sales
	$monthSalesCount = $dbo->getval(
	"SELECT count(nTransaction_ID) FROM tbltransactions WHERE
  /* Greater or equal to the start of last month */
  dDateTime >= DATE_ADD(LAST_DAY(DATE_SUB(NOW(), INTERVAL 2 MONTH)), INTERVAL 1 DAY) and
  /* Smaller or equal than one month ago */
  dDateTime <= DATE_SUB(NOW(), INTERVAL 1 MONTH)"
);

	##### Member Stats #####
	$last_week_date = date('Ymd', strtotime("-7 days", time()));
	$last_month_date = date('Ymd', strtotime("-30 days", time()));
	// Total Active Member Count
	$nActiveMembers = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE nActive = 1 AND nUser_ID > 1");
	$last_week_date = date('Ymd', strtotime("-7 days", time()));
	
	$sql = "SELECT COUNT(*) as nCount FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_week_date AND tblusers.nAdmin = 0;";
	$nActiveMembersWeek = $dbo->getval($sql);
	
	
	$last_month_date = date('Ymd', strtotime("-30 days", time()));
	$sql = "SELECT COUNT(*) as nCount FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_month_date AND tblusers.nAdmin = 0;";
	$nActiveMembersMonth = $dbo->getval($sql);
	
	// Total Subscriber Counts
	$nActiveSubs = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE nActive = 1 AND nUser_ID > 1");
	
	
	$sql = "SELECT COUNT(*) as nCount FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_week_date AND tblusers.nAdmin = 0;";
	$nActivesubsWeek = $dbo->getval($sql);
	
	
	$last_month_date = date('Ymd', strtotime("-30 days", time()));
	$sql = "SELECT COUNT(*) as nCount FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_month_date AND tblusers.nAdmin = 0;";
	$nActiveMembersMonth = $dbo->getval($sql);
	
	$nActiveAffiliates = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE nActive = 1 AND nUser_ID > 1 AND nAffiliate = 1");
	$nActiveAffiliatesWeek = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_week_date AND tblusers.nAdmin = 0 AND nAffiliate = 1");
	$nActiveAffiliatesMonth = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= $last_month_date AND tblusers.nAdmin = 0 AND nAffiliate = 1");
	
	
	##### Revenue #####
	$sql = "SELECT SUM(nSaleAmount) as nCount FROM tbltransactions WHERE ntransactiontype_id = 1 and DATE(dDateTime) = DATE(NOW())";
	$revenueToday = $dbo->getval($sql);
	if($revenueToday == NULL) $revenueToday = 0.00;
	//die(var_dump($revenueToday));
	
	$sql = "SELECT SUM(nSaleAmount) as nCount FROM tbltransactions WHERE ntransactiontype_id = 1 AND dDateTime >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND dDateTime < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY";
	$revenueWeek = $dbo->getval($sql);
	
	if($revenueWeek == NULL) $revenueWeek = 0.00;
	
	$sql = "SELECT SUM(nSaleAmount) as nCount FROM tbltransactions WHERE ntransactiontype_id = 1 
	
	AND dDateTime >= $last_month_date";
	$revenueMonth = $dbo->getval($sql);
	
	if($revenueMonth == NULL) $revenueMonth = 0.00;
	
	
	
	
	
	
	// Total Counts
	

	$nActiveMembers = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE nActive = 1 AND nUser_ID > 1");
	$nCancelledMembers = $dbo->getval("SELECT COUNT(*) FROM (SELECT nUser_ID FROM tbluserlevels WHERE nDateCancelled > 0 GROUP BY nUser_ID) AS tmp1");
	$nFreeOnlyMembers = $dbo->getval(
	"SELECT COUNT(*) FROM (
		SELECT tblusers.nUser_ID FROM tblusers 
		WHERE tblusers.nUser_ID NOT IN (
			SELECT tblusers.nUser_ID FROM tblusers
			INNER JOIN tbluserlevels ON tbluserlevels.nUser_ID = tblusers.nUser_ID 
			INNER JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
			INNER JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
			WHERE NOT tblpaymentprocessors.sProcessorName = 'Free' AND tblusers.nActive = 1
			)
		AND nUser_ID > 1 AND tblusers.nActive = 1
		GROUP BY tblusers.nUser_ID)
	AS tmp1");
	$nPaidOnlyMembers = $dbo->getval("SELECT COUNT(*) FROM (
						SELECT tblusers.nUser_ID FROM tblusers 
						WHERE tblusers.nUser_ID IN (
							SELECT tblusers.nUser_ID FROM tblusers
							INNER JOIN tbluserlevels ON tbluserlevels.nUser_ID = tblusers.nUser_ID 
							INNER JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
							INNER JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
							WHERE NOT tblpaymentprocessors.sProcessorName = 'Free' AND tblusers.nActive = 1
						)
						AND nUser_ID > 1 AND tblusers.nActive = 1
						GROUP BY tblusers.nUser_ID
					) AS tmp1");
	
	$css = <<<EOT
<!--page level css -->
<link rel="stylesheet" href="css/only_dashboard.css" />
<!--end of page level css-->
EOT;
	require_once('header.php');
	
	?>

<aside class="right-side"> 
	<!-- Main content -->
	<section class="content-header">
		<h1> Welcome to Dashboard </h1>
		<ol class="breadcrumb">
			<li class="active"> <a href="#"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
		</ol>
	</section>
	<section class="content">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6 margin_10 animated fadeInLeftBig"> 
				<!-- Trans label pie charts strats here-->
				<div class="lightbluebg no-radius">
					<div class="panel-body squarebox square_boxs">
						<div class="col-xs-12 pull-left nopadmar">
							<div class="row">
								<div class="square_box col-xs-7 text-right"> <span> Revenue Today </span>
									<div class="number" id="revenueToday"></div>
								</div>
								<i class="livicon pull-right" data-name="piggybank" data-l="true" data-c="#fff" data-hc="#fff" data-s="70"></i> </div>
							<div class="row">
								<div class="col-xs-6"> <small class="stat-label">Last Week</small>
									<h4 id="revenueWeek"></h4>
								</div>
								<div class="col-xs-6 text-right"> <small class="stat-label">Last Month</small>
									<h4 id="revenueMonth"></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6 margin_10 animated fadeInUpBig"> 
				<!-- Trans label pie charts strats here-->
				<div class="redbg no-radius">
					<div class="panel-body squarebox square_boxs">
						<div class="col-xs-12 pull-left nopadmar">
							<div class="row">
								<div class="square_box col-xs-7 pull-left"> <span> Today's Sales </span>
									<div class="number" id="salesCountDaily"></div>
								</div>
								<i class="livicon pull-right" data-name="piggybank" data-l="true" data-c="#fff" data-hc="#fff" data-s="70"></i> </div>
							<div class="row">
								<div class="col-xs-6"> <small class="stat-label">Last Week</small>
									<h4 id="salesCountWeek"></h4>
								</div>
								<div class="col-xs-6 text-right"> <small class="stat-label">Last Month</small>
									<h4 id="salesCountMonth"></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 col-md-6 margin_10 animated fadeInDownBig"> 
				<!-- Trans label pie charts strats here-->
				<div class="goldbg no-radius">
					<div class="panel-body squarebox square_boxs">
						<div class="col-xs-12 pull-left nopadmar">
							<div class="row">
								<div class="square_box col-xs-7 pull-left"> <span> Affiliates </span>
									<div class="number" id="affiliatesTotal"></div>
								</div>
								<i class="livicon pull-right" data-name="archive-add" data-l="true" data-c="#fff" data-hc="#fff" data-s="70"></i> </div>
							<div class="row">
								<div class="col-xs-6"> <small class="stat-label">Last Week</small>
									<h4 id="affiliatesWeek"></h4>
								</div>
								<div class="col-xs-6 text-right"> <small class="stat-label">Last Month</small>
									<h4 id="affiliatesMonth"></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6 margin_10 animated fadeInRightBig"> 
				<!-- Trans label pie charts strats here-->
				<div class="palebluecolorbg no-radius">
					<div class="panel-body squarebox square_boxs">
						<div class="col-xs-12 pull-left nopadmar">
							<div class="row">
								<div class="square_box col-xs-7 pull-left"> <span> Registered Users </span>
									<div class="number" id="usersTotal"></div>
								</div>
								<i class="livicon pull-right" data-name="users" data-l="true" data-c="#fff" data-hc="#fff" data-s="70"></i> </div>
							<div class="row">
								<div class="col-xs-6"> <small class="stat-label">Last Week</small>
									<h4 id="usersWeek"></h4>
								</div>
								<div class="col-xs-6 text-right"> <small class="stat-label">Last Month</small>
									<h4 id="usersMonth"></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/row-->
		
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6">
				<div class="panel panel-border">
					<div class="panel-heading border-light">
						<h4 class="panel-title"> <i class="livicon" data-name="calendar" data-size="16" data-loop="true" data-c="#333" data-hc="#333"></i> New Members </h4>
						<span class="pull-right"> <i class="glyphicon glyphicon-chevron-up showhide clickable"></i> </span> </div>
					<div class="panel-body">
						<div align="center" id="admin_chart_membership" class="widget_content" ></div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6">
				<div class="panel panel-border">
					<div class="panel-heading border-light">
						<h4 class="panel-title"> <i class="livicon" data-name="calendar" data-size="16" data-loop="true" data-c="#333" data-hc="#333"></i> Revenue Chart </h4>
						<span class="pull-right"> <i class="glyphicon glyphicon-chevron-up showhide clickable"></i> </span> </div>
					<div class="panel-body">
						<div align="center" id="admin_chart_revenue"  class="widget_content"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6">
			<div class="panel panel-primary todolist">
				<div class="panel-heading border-light">
					<h4 class="panel-title"> <i class="livicon" data-name="medal" data-size="18" data-color="white" data-hc="white" data-l="true"></i> Quick Start Checklist </h4>
				</div>
				<div class="panel-body nopadmar">
					<table class="table table-striped table-bordered table-hover">
						<tr>
							<td valign="middle" ><span id="QS_settings" class="qs_image"> <img src="<?php echo (!is_option('QS_settings') || get_option('QS_settings') == '0')?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Review and Modify Site Settings</td>
							<td ><span id="QS_settings_go" style="display:<?php echo (!is_option('QS_settings') || get_option('QS_settings') == '0')?'inline':'none' ?>">
								<input type="button" name="Button" value="Go" onClick="doQS('settings')" class="btn btn-xs btn-success">
								<input type="button" name="settings" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_settings_done" style="display:<?php echo (get_option('QS_settings') == '1')?'inline':'none' ?>">
								<input type="button" name="settings" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
						<tr>
							<td ><span id="QS_email" class="qs_image"> <img src="<?php echo (!is_option('QS_email'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Setup Email Settings and Templates</td>
							<td ><span id="QS_email_go" style="display:<?php echo (!is_option('QS_email'))?'inline':'none' ?>">
								<input type="button" name="Button2" value="Go" onClick="doQS('email')" class="btn btn-xs btn-success">
								<input type="button" name="email" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_email_done" style="display:<?php echo (get_option('QS_email') == '1')?'inline':'none' ?>">
								<input type="button" name="email" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
						<tr>
							<td ><span id="QS_levels" class="qs_image"> <img src="<?php echo (!is_option('QS_levels') || get_option('QS_levels') == '0')?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Define Membership Level(s)</td>
							<td ><span id="QS_levels_go" style="display:<?php echo (!is_option('QS_levels'))?'inline':'none' ?>">
								<input type="button" name="Button2" value="Go" onClick="doQS('levels')" class="btn btn-xs btn-success">
								<input type="button" name="levels" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_levels_done" style="display:<?php echo (get_option('QS_levels') == '1')?'inline':'none' ?>">
								<input type="button" name="levels" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
						<tr>
							<td ><span id="QS_processors" class="qs_image"> <img src="<?php echo (!is_option('QS_processors'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Setup Payment Processor(s)</td>
							<td ><span id="QS_processors_go" style="display:<?php echo (!is_option('QS_processors'))?'inline':'none' ?>">
								<input type="button" name="Button2" value="Go" onClick="doQS('processors')" class="btn btn-xs btn-success">
								<input type="button" name="processors" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_processors_done" style="display:<?php echo (get_option('QS_processors') == '1')?'inline':'none' ?>">
								<input type="button" name="processors" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
						<tr>
							<td ><span id="QS_plans" class="qs_image"> <img src="<?php echo (!is_option('QS_plans'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Define Payment Plans</td>
							<td ><span id="QS_plans_go" style="display:<?php echo (!is_option('QS_plans'))?'inline':'none' ?>">
								<input type="button" name="Button2" value="Go" onClick="doQS('plans')" class="btn btn-xs btn-success">
								<input type="button" name="plans" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_plans_done" style="display:<?php echo (get_option('QS_plans') == '1')?'inline':'none' ?>">
								<input type="button" name="plans" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
						<tr>
							<td ><span id="QS_pages" class="qs_image"> <img src="<?php echo (!is_option('QS_pages') || get_option('QS_pages') == '0')?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Create Home/Sales Pages</td>
							<td ><span id="QS_pages_go" style="display:<?php echo (!is_option('QS_pages'))?'inline':'none' ?>">
								<input type="button" name="Button2" value="Go" onClick="doQS('pages')" class="btn btn-xs btn-success">
								<input type="button" name="pages" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_pages_done" style="display:<?php echo (get_option('QS_pages') == '1')?'inline':'none' ?>">
								<input type="button" name="pages" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
						<tr>
							<td ><span id="QS_content" class="qs_image"> <img src="<?php echo (!is_option('QS_content'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" alt="" /></span> Add Member Content / Upload Products</td>
							<td ><span id="QS_content_go" style="display:<?php echo (!is_option('QS_content'))?'inline':'none' ?>">
								<input type="button" name="Button2" value="Go" onClick="doQS('content')" class="btn btn-xs btn-success">
								<input type="button" name="content" value="Mark Completed" onClick="completeQs(this)" class="btn btn-xs btn-primary">
								</span> <span id="QS_content_done" style="display:<?php echo (get_option('QS_content') == '1')?'inline':'none' ?>">
								<input type="button" name="content" value="Reset" onClick="resetQs(this)" class="btn btn-xs btn-info">
								</span></td>
						</tr>
					</table>
					<div class="row" align="right">
						<input type="button" name="QS_Close" id="QS_Close" value="Disable Quickstart" onClick="disableQS()" class="btn btn-xs btn-danger">
					</div>
				</div>
			</div>
		</div>
		<?php if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO']) && $DEVOPTS['SYSINFO'] == 1)){ ?>
		<div class="col-lg-6 col-md-6 col-sm-6">
			<div class="panel panel-primary todolist">
				<div class="panel-heading border-light">
					<h4 class="panel-title"> <i class="livicon" data-name="medal" data-size="18" data-color="white" data-hc="white" data-l="true"></i> System Information </h4>
				</div>
				<div class="panel-body nopadmar">
					<table class="table table-striped table-bordered table-hover">
						<?php if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO_KEY']) && $DEVOPTS['SYSINFO_KEY'] == 1)){?>
						<tr>
							<th>License Key</th>
							<td><a href="license.php?action=update" title="Click Here To Change Your License Key"><?php echo $licenseData->key ?></a></td>
						</tr>
						<?php
						}
						if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO_REGISTERED']) && $DEVOPTS['SYSINFO_REGISTERED'] == 1)){?>
						<tr>
							<th>Registered To</th>
							<td><?php echo $licenseData->Customer ?></td>
						</tr>
						<?php
						}
						if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO_LTYPE']) && $DEVOPTS['SYSINFO_LTYPE'] == 1)){?>
						<tr>
							<th>License Type</th>
							<td class="gridrow2"><?php echo $displayLicenseType ?>
								<?php 
						  
						  if ($displayLicenseType == 'trial') 
						  echo " - <a href='http://easymemberpro.com/index.php?page=trial-upgrade' target='_blank'>Purchase Full License</a>";
                          
                          elseif($displayLicenseType == 'single')
						  echo " - <a href='http://www.easymemberpro.com/index.php?page=join&plan=46' target='_blank'>Upgrade To Unlimited</a>";
						  
						  ?></td>
						</tr>
						<?php 
						}
						if($licenseData->type != 'developer') {?>
						<tr>
							<th><?php echo ($licenseData->type == 'trial')?'Trial Expires':'Support/Upgrade Expires' ?></th>
							<td><span class="<?php echo ($licenseData->updates_expires <= time())?'error':'green'?>" > <?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$licenseData->updates_expires)) ?> </span></td>
						</tr>
						<?php
					   if($licenseData->updates_expires >= time()){ ?>
						<tr>
							<th>Support Email</th>
							<td><input id="license_support_email" name="license_support_email" type="text" value="<?php echo $licenseData->support_email ?>" size="40">
								<input type="button" name="update_support_email" id="update_support_email" value="Update" onClick="updateSupportEmail('license_support_email','<?php echo $licenseData->key ?>','<?php echo CLIENT ?>')">
								<div id="license_support_email_message"></div></td>
						</tr>
						<?php
					   } }
					   if($licenseData->type != 'developer' 
					   || (isset($DEVOPTS['SYSINFO_VERSION']) && $DEVOPTS['SYSINFO_VERSION'] == '1')){
					   ?>
						<tr>
							<th>Installed Version</th>
							<td><span class="<?php echo ($VERSION!=false)?'error':'green'?>" ><?php echo get_emp_version() ?> <?php echo ($VERSION!=false)?' - '.$VERSION:''; ?></span></td>
						</tr>
						<?php } ?>
					</table>
				</div>
			</div>
		</div>
		<?php } ?>
	</section>
</aside>
<!-- right-side -->
<?php
require_once('footer.php');
?>
<!-- begining of page level js --> 
<!--  todolist--> 
<script src="js/todolist.js"></script> 
<!-- EASY PIE CHART JS --> 
<script src="vendors/charts/easypiechart.min.js"></script> 
<script src="vendors/charts/jquery.easypiechart.min.js"></script> 
<!--for calendar--> 
<script src="vendors/fullcalendar/fullcalendar.min.js" type="text/javascript"></script> 
<script src="vendors/fullcalendar/calendarcustom.min.js" type="text/javascript"></script> 
<!--   Realtime Server Load  --> 
<script src="vendors/charts/jquery.flot.min.js" type="text/javascript"></script> 
<script src="vendors/charts/jquery.flot.resize.min.js" type="text/javascript"></script> 
<!--Sparkline Chart--> 
<script src="vendors/charts/jquery.sparkline.js"></script> 
<!-- Back to Top--> 
<script type="text/javascript" src="vendors/countUp/countUp.js"></script> 
<!--   maps --> 
<script src="vendors/jvectormap/jquery-jvectormap-1.2.2.min.js"></script> 
<script src="vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script> 
<script src="vendors/jscharts/Chart.js"></script> 
<!-- <script src="js/dashboard.js" type="text/javascript"></script> --> 
<script type="text/javascript" language="JavaScript" src="common/js/wrapscript.js"></script> 
<script type="text/javascript" src="../js/swfobject.js"></script> 
<script type="text/javascript">
			var params = {};
			params.wmode = "transparent"; 
			swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_membership", "100%", "200", "9.0.0", "expressInstall.swf", {"data-file":"chart_data.php?data=membership"},params );
			swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_revenue", "100%", "200", "9.0.0", "expressInstall.swf", {"data-file":"chart_data.php?data=revenue"},params );
			
			</script> 
<script type="text/javascript">
    
	// top menu 
    var options = {
        useEasing: false,
        useGrouping: false,
        separator: ',',
        decimal: '.'
    }
	var demo = new countUp("salesCountDaily", 0, <?php echo $todaySalesCount ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("salesCountWeek", 0, <?php echo $weekSalesCount ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("salesCountMonth", 0, <?php echo $monthSalesCount ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("usersTotal", 0, <?php echo $nActiveMembers ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("usersWeek", 0, <?php echo $nActiveMembersWeek ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("usersMonth", 0, <?php echo $nActiveMembersMonth ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("affiliatesTotal", 0, <?php echo $nActiveAffiliates ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("affiliatesWeek", 0, <?php echo $nActiveAffiliatesWeek ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("affiliatesMonth", 0, <?php echo $nActiveAffiliatesMonth ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("revenueToday", 0, <?php echo $revenueToday?>, 0, 6, options);
    demo.start();
	var demo = new countUp("revenueWeek", 0, <?php echo $revenueWeek ?>, 0, 6, options);
    demo.start();
	var demo = new countUp("revenueMonth", 0, <?php echo $revenueMonth ?>, 0, 6, options);
    demo.start();
	
	
	
	
	
	$(document).ready(function() {
        var composeHeight = $('#calendar').height() +21 - $('.adds').height();
        $('.list_of_items').slimScroll({
            color: '#A9B6BC',
            height: composeHeight + 'px',
            size: '5px'
        });
    });
    </script> 
<!-- end of page level js -->

</body></html>