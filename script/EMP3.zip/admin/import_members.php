<?php
include_once ('../conn.php');
include_once ('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Import Members';
	$css = <<<EOT
<!--page level css -->

<link href="vendors/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen" />
<link href="vendors/jasny-bootstrap/css/jasny-bootstrap.css" rel="stylesheet" />
<!--end of page level css-->
EOT;

	define('FIRST', 0);define('LAST', 1);define('EMAIL', 2);define('ADDR1', 3);define('ADDR2', 4);define('ADDR3', 5);define('CITY', 6);define('STATE', 7);define('ZIP', 8);define('COUNTRY', 9);define('PHONE', 10);define('CELL', 11);define('PASSWORD', 12);define('JOINDATE', 13);define('SUBSCRIPTION', 14);define('USER_ADDED', 1);define('USER_ALREADY_EXISTS', 2);
	
	
	//-----------------we generate an array with all membership levels
	$result = $dbo->select("SELECT * FROM tblmembershiplevels WHERE nLevel_ID>1");
	$membershipLevelsArray = array();
	while ($row = $dbo->getarray($result)) {
		array_push($membershipLevelsArray, array($row['nLevel_ID'], $row['sLevel']));
	}
	
	
	function import_user($info){
		// Check if User already Exists
		global $dbo, $membershipLevelsArray;
		$sql = sprintf("SELECT nUser_ID FROM tblusers WHERE sEmail = '%s' ", $dbo->format($info[EMAIL]));
		$rs = $dbo->select($sql);
		if ($dbo->nr($rs) > 0)
			return USER_ALREADY_EXISTS;
	
		// Add User to tblusers
		if (empty($info[JOINDATE]))
			$info[JOINDATE] = date("Ymd");
		if (empty($info[PASSWORD])) //$info[PASSWORD] = genpassword(6);
	
			$info[PASSWORD] = "123456";
		$sql = sprintf("INSERT INTO tblusers (sForename, sSurname, sAddr1, sAddr2, sAddr3, sTown, sCounty, sPostcode, sCountry, sEmail, sTelephone, sMobile, sPaymentStatus, sPassword, nJoinDate, nActive)
									VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', 1)",
			$info[FIRST], $info[LAST], $info[ADDR1], $info[ADDR2], $info[ADDR3], $info[CITY],
			$info[STATE], $info[ZIP], $info[COUNTRY], $info[EMAIL], $info[PHONE], $info[CELL],
			'', $info[PASSWORD], $info[JOINDATE]);
		$dbo->insert($sql);


    //--------- we now add the membership levels to the last inserted member-------------------------------
    if ($info[SUBSCRIPTION] != "") {
        $membership_levels_array = explode(",", $info[SUBSCRIPTION]);

        foreach ($membership_levels_array as $membership_level) {

            $query = "SELECT nUser_ID FROM tblusers WHERE sEmail='" . $info[EMAIL] . "'";
            $result = $dbo->select($query);
            $row = $dbo->getarray($result);
            $user_id = $row['nUser_ID'];


            $membership_level = explode("-", $membership_level);
            $membership_level_id = $membership_level[0];
            $membership_level_expires = $membership_level[1];
            $nDateActive = $membership_level[2];

            $query = "INSERT INTO tbluserlevels (nUser_ID, nLevel_ID, nDateExpires, nActive, nDateActive) 
		VALUES 
		('$user_id', '$membership_level_id', '$membership_level_expires', '1', $nDateActive)";
            $dbo->insert($query) or die($dbo->error);
        }
    }
    //-----------------------------------------------------------------------------------------------


    return USER_ADDED;}

	if (!empty($_POST)) {
    	$file = $_FILES['importfile'];

    	if ($file['error'] == UPLOAD_ERR_OK) {
        $filename = $file['tmp_name'];
        $delimiter = ($_POST['delimiter'] == 'comma') ? ',' : '\t';
        $cnt = (isset($_POST['header'])) ? 0 : 1; // If we have a header we'll skip the first line
        $aExists = array();
        $cnt_import = 0;
        $cnt_exists = 0;


        //======generates subscription levels string if any level is checked
        $nDateExpires = str_replace("-", "", $_POST['dtEnd']);
        $nDateActive = date(Ymd);

        foreach ($membershipLevelsArray as $membersipLevel) {
            if ($_POST['level_' . $membersipLevel[0]]) {

                if ($levelsString == "") {
                    $levelsString = $membersipLevel[0] . "-" . $nDateExpires . "-" . $nDateActive;
                } else {
                    $levelsString .= ", " . $membersipLevel[0] . "-" . $nDateExpires . "-" . $nDateActive;
                    ;
                }
            }

        }

        // Process File

        if (($handle = fopen($filename, "r")) !== false) {
            while (($info = fgetcsv($handle, 1000, ",")) !== false) {

                if ($levelsString != "") {
                    $info[SUBSCRIPTION] = $levelsString;
                }
                if ($cnt > 0) {
                    $status = import_user($info);
                    if ($status == USER_ALREADY_EXISTS) {
                        $info['line'] = $cnt;
                        $aExists[] = $info;
                        $cnt_exists++;
                    } else
                        $cnt_import++;
                }
                $cnt++;

            }
            fclose($handle);
        }

        $total = $cnt_import + $cnt_exists;
        $message = "<p class='success'>$total Record(s) processed &mdash; $cnt_import Member(s) successfully imported </p>";
        if ($cnt_exists != 0) $message .= "<p class='error'>&mdash; $cnt_exists Member(s) already exist in database</p>";
    }
		elseif ($file['error'] == UPLOAD_ERR_NO_FILE) { $message = "<p class='error'>Please select an import file</p>";}
	}
	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Members</li>
      <li class="active">Import Members</li>
    </ol>
  </section>
  <section class="content"> 
  <?php echo isset($message) ? $message : '' ?>
    <div class="col-md-12"> 
      <!-- BEGIN SAMPLE TABLE PORTLET-->
      <div class="portlet box primary">
        <div class="portlet-title">
          <div class="caption"> <i class="livicon" data-name="responsive" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i> Member List </div>
        </div>
        <div class="portlet-body flip-scroll">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <form name="info" method="post"  enctype="multipart/form-data" action="import_members.php" style="margin-top:10px">
            <table class="table table-bordered table-striped table-condensed flip-content">
              <thead class="flip-content">
                <tr>
                  <th>Import File<font color="Red"> *</font></th>
                  <td><div class="fileinput fileinput-new input-group" data-provides="fileinput">
                    <div class="form-control" data-trigger="fileinput"> <i class="glyphicon glyphicon-file fileinput-exists"></i> <span class="fileinput-filename"></span> </div>
                    <span class="input-group-addon btn btn-default btn-file"> <span class="fileinput-new"> Select file </span> <span class="fileinput-exists">Change</span>
                    <input type="file" name="importfile">
                    </span> <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a></td>
                </tr>
                <tr>
                  <th>Field Delimiter</th>
                  <td><input type="radio" name="delimiter" id="comma" value="comma" checked>
                    Comma Delimited
                    <input type="radio" name="delimiter" id="tab" value="tab">
                    Tab Delimited</td>
                </tr>
                <tr>
                  <th>First Row</th>
                  <td class="gridRow1"><input type="checkbox" name="header" id="header" checked>
                    First row contains headers (First Name, Last Name, Email etc)</td>
                </tr>
                <tr>
                  <th>Data format</th>
                  <td>
                  	First, Last, Email, Addr1, Addr2, Addr3, City, State, Zip, Country, Phone, Cell, Password, JoinDate, nLevel_ID-nDateExpires-nDateActive
                  </td>
                </tr>
                <tr>
                  <th>Assign members to levels:</th>
                  <td>
					<table>
                      <tr>
                        <td><!-- LIST WITH ALL LEVELS generated dynamically-->
                          
                          <?php
                            $nrOfColumns = 5;
                            echo "<table>";
                            $td = 1;
                            $i = 1;
                            foreach ($membershipLevelsArray as $membersipLevel) {
                                if ($td == 1) {
                                    echo "
                                    <tr>";
                                }
                            
                            
                                ($_REQUEST['level_' . $membersipLevel[0]]) ? $checked = 'checked="checked"' : $checked =
                                    '';
                                echo "<td><input type='checkbox' $checked name='level_" . $membersipLevel[0] .
                                    "' />" . $membersipLevel[1] . "</td>";
                            
                                if ($i == count($membershipLevelsArray)) {
                            
                                    $requiredNrOfTd = $nrOfColumns - $td;
                                    $j = 0;
                                    while ($j < $requiredNrOfTd) {
                                        echo "<td></td>";
                                        $j++;
                                    }
                                    echo "</tr>
                                    ";
                                    break;
                                }
                            
                            
                                if ($td == $nrOfColumns) {
                                    echo "</tr>
                                    ";
                                    $td = 0;
                                }
                            
                                $td++;
                                $i++;
                            }
                            echo "</table>";
                            ?></td>
                        <td><label for="dtEnd" class="col-sm-3 control-label">Levels will expire on:</label>
                          <?php
                            $dtEnd = $_POST['dtEnd'];
                            
                            if ($dtEnd == "") {
                                $dtEnd = date("Ymd", strtotime("+1 month"));
                            }
                            ?>
						  <div class="col-sm-5">
             <div class='input-group date' id='reactive_expire'>
                 <input type="text" id="dtEnd" name="dtEnd" class="col-sm-3 form-control" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>" value="<?php echo fShowDate($chkSsettings->nDateFormat, $dtEnd);?>"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
						  
						  </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td colspan="2"><input class="btn btn-primary btn-responsive" name="submit" value="Import" type="submit"></td>
                </tr>
            </table>
          </form>
          <?php if (!empty($aExists)): ?>
          <table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
            <tr>
              <td class="gridHeader" colspan="2">Members Already in the Database </td>
            </tr>
            <?php foreach ($aExists as $item): ?>
            <tr>
              <td class="gridLabels1" nowrap="nowrap" width="120">Line: <?php echo $item['line'] ?></td>
              <td class="gridRow1"><table>
                  <tr>
                    <td width="380px"><span><?php echo $item[EMAIL] ?></span></td>
                    <td><span><?php echo $item[FIRST] . ' ' . $item[LAST] ?></span></td>
                  </tr>
                </table></td>
            </tr>
            <?php endforeach; ?>
          </table>
          <?php endif; ?>
          </td>
          </tr>
          <tr>
            <td style="padding-left: 8px; padding-right: 8px; " valign="top" width="100%"><br></td>
          </tr>
          </table>
          <div class="row">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script src="vendors/jasny-bootstrap/js/jasny-bootstrap.js"></script>
<!--datetime picker-->
<script type="text/javascript" src="vendors/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="vendors/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
<script type="text/javascript">
	$(function() {
	$('#reactive_expire').datetimepicker({
		format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>',
		minView: 'month',
		endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?>', 
    	autoclose: true
	});
	});

</script>
</body></html>