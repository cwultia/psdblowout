<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo $admintitle; ?></title>
        		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
		<script type="text/javascript" src="../js/jquery.validate.js"></script>
        <script type="text/javascript" src="../js/superfish.js"></script>
		<script type="text/javascript" src="../js/supersubs.js"></script>
        <link rel="stylesheet" type="text/css" href="../common/css/superfish.css" media="screen">
        <link rel="stylesheet" type="text/css" href="common/css/styles.css">
        <style type="text/css">
		.sf-menu ul {margin-top:-2px;}
.sf-menu li { background-color: #FFF; border:thin solid #666 ;border-left:1px solid #666 ;border-right:1px solid #666 ;}
	.sf-menu li li { background-color: #FFF;border:thin solid #666 ; border-collapse:collapse }
	.sf-menu li li li { background-color: #FFF; border:thin solid #666; border-collapse:collapse }
	.sf-menu a:focus, .sf-menu a:hover, .sf-menu a:active { background: [[MENU_HOVER_COLOR]]; outline: 0; }
	.sf-menu a, .sf-menu a:visited { color: [[MENU_TEXT_COLOR]]; }
	.sf-menu { float: left;}
	.sf-menu-img {
		border:none;
		width:16px;
		height:16px;
		float:left;
		}
</style>
<script type="text/javascript">
		// initialise plugins
		jQuery(function(){
			$("ul.sf-menu").supersubs({ 
				minWidth:    5,   	// minimum width of sub-menus in em units 
				maxWidth:    50,   	// maximum width of sub-menus in em units 
				extraWidth:  1     	// extra width can ensure lines don't sometimes turn over 
							// due to slight rounding differences and font-family 
		        }).superfish();
		});
	</script>
<meta charset="utf-8" />
</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="">
  <!--DWLayoutTable-->
  <tr>
    <td class="header-bg">
    <table border="0" align="left" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="20">&nbsp;</td>
          <td width="569" height="99"><img src="images/emp-cp-header-logo.jpg" width="546" height="106"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<ul class="sf-menu sf-js-enabled sf-shadow" style="background-color:#FFFFFF; width:100%; margin-top:-3px;">
  <li><a class="sf" href="home.php">&nbsp;Home</a></li>
  <li><a class="sf" href="update_license.php">&nbsp;Update License</a></li>
  <li><a class="sf" href="http://easymemberpro.com/member/index.php?page=licensekey">&nbsp;Manage License</a></li>
  </ul>




<br />
<center>
<div style="width:850px; color:#BF0B0B; font-family:verdana; line-height:190%; border-style:solid; border-width:2px; border-color: #EF6B00; padding:20px; margin:auto; margin-top:50px;margin-bottom:50px;">
<h3>The script has found an error with your license key <b style="color:#ff0000;"><?php echo $_SESSION['key']; ?></b><br /> <?php echo stripslashes($_GET['msg']); ?></h3>
</div>
</center>

<?php include_once('b.php'); ?>
	</body>
</html>