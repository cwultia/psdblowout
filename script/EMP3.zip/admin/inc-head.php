	 <script type="text/javascript" src="../js/jquery-1.8.3.min.js"></script> 
	<script type="text/javascript" src="../js/jquery.validate.js"></script>
	<script type="text/javascript" src="../js/superfish.js"></script>
	<script type="text/javascript" src="../js/supersubs.js"></script>
	<script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
	<script language="javascript" src="common/js/empAdmin.js?version=3.1.4"></script>
	<link rel="stylesheet" type="text/css" href="../common/css/superfish.css" media="screen">
	<link rel="stylesheet" type="text/css" href="common/css/styles.css">
	<link type="text/css" rel="stylesheet" href="../common/css/jqueryui/redmond/jquery-ui-1.8.24.custom.css">
	<style type="text/css">
		.sf-menu li {
    		border-collapse:collapse;
		}
		.sf-menu li li {
			padding: 0px 0px 0px 2px;
			
			background-color: #fafafa;
			border-color: #ffffff;
			border-style: solid;
			border-width: 1px 1px 0px 1px;
			border-collapse:collapse }
		.sf-menu li li li {
			padding: 0px 0px 0px 2px;
			
			background-color: #fafafa;
			border-color: #ffffff;
			border-style: solid;
			border-width: 1px 1px 0px 1px;
			border-collapse:collapse }
		.sf-menu a:focus, .sf-menu a:hover, .sf-menu a:active { background: [[MENU_HOVER_COLOR]]; outline: 0; }
		.sf-menu a, .sf-menu a:visited { color: [[MENU_TEXT_COLOR]]; }
		.sf-menu { float: left;}
		.sf-menu img {
			border:none;
			width:16px;
			height:16px;
			float:left;
		}
	</style>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <script type="text/javascript">
	<?php
	// Load Session Keep Alive
	if($_SESSION['admin']){
		if(get_option('session_timeout_active')=='1'){
			
		?>
		$(document).ready(keepAlive(<?php echo intval(get_option('security_timeout')*60)?>,<?php echo $_SESSION['admin']['LAST_ACTIVITY']?>));
	<?php }
	}
		?>
	getServerTime();
    </script>
<?php echo pluginClass::filter("admin_head"); ?>