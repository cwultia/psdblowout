<?php
include_once ('../conn.php');
include_once ('../functions.php');

if (!isset($_POST['action'])) {

	if (!isset($_GET['userid']) || $_GET['userid'] == "" || !is_numeric($_GET['userid'])) {
		echo "Invalid user id";
		exit();
	}
	
	if (!isset($_GET['levelid']) || $_GET['levelid'] == "" || !is_numeric($_GET['levelid'])) {
		echo "Invalid level id";
		exit();
	}
	
	$userid = $dbo->format($_GET['userid']);
	$levelid = $dbo->format($_GET['levelid']);

} else {
	
	$userid = $dbo->format($_POST['userid']);
	$levelid = $dbo->format($_POST['levelid']);
	
	// Process update
	$bErr = 0;
	
	$date = explode('/', $_POST['nDateExpires']);	
	if (!checkdate($date[0], $date[1], $date[2])) {
		$bErr = 1;
		$errMsg = "Expiry date is invalid";
	}
	
	if ($bErr == 0) {
		
		if (isset($_POST['updateAll'])) {
			
			$nDateToday = date("Ymd");
			$sql = "UPDATE tbluserlevels SET nDateExpires=" . date('Ymd', strtotime($dbo->format($_POST['nDateExpires']))) . " WHERE nPaymentPlan_ID=0 AND nUser_ID > 1 AND nDateExpires <= $nDateToday AND nDateCancelled = 0";
			$dbo->update($sql);
			
			header("Location: expired_members.php?bUpdated=2");
			exit();
			
		} else {
		
			$sql = "UPDATE tbluserlevels SET nDateExpires=" . date('Ymd', strtotime($dbo->format($_POST['nDateExpires']))) . " WHERE nUser_ID=$userid AND nLevel_ID=$levelid";
			$dbo->update($sql);
			
			header("Location: expired_members.php?bUpdated=1");
			exit();
		
		}
		
	}
}
?>
<html>
<head>
<title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
<link type="text/css" rel="stylesheet" href="calendar/popcalendar.css">
<script language="javascript" src='calendar/popcalendar.js'></script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once ('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        
			<?php include_once ('memberleft.php'); ?>      
		</td>
		<td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
			<table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="125" class="navRow1" nowrap="nowrap">Expired Members</td>
					<td class="navRow2" style="text-align:right; padding-right:20px"></td>
				</tr>
			</table>
			
			<?php 
			$sql = "SELECT U.sForename, U.sSurname, M.sLevel, UL.nDateExpires FROM tblusers U
			INNER JOIN tbluserlevels UL ON U.nUser_ID = UL.nUser_ID
			INNER JOIN tblmembershiplevels M ON UL.nLevel_ID = M.nLevel_ID
			WHERE U.nUser_ID = $userid AND UL.nLevel_ID = $levelid";
			
			$objUser = $dbo->getobject($sql);
			?>
			
			<form name="f1" action="increase_expiry.php" method="post">
			<input type="hidden" name="userid" value="<?php echo $userid ?>" />
			<input type="hidden" name="levelid" value="<?php echo $levelid ?>" />
			
			<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
			<tr><td class="gridHeader" colspan="2">Increase membership expiry for <?php echo $objUser->sForename . ' ' . $objUser->sSurname ?></td></tr>
			<tr><td class="gridRow1" width="150">Member level expired</td><td class="gridOptions1"><?php echo $objUser->sLevel ?></td></tr>
			<tr><td class="gridRow1" width="150">Current Expiry Date</td><td class="gridOptions1"><?php echo fShowDate($chkSsettings->nDateFormat, $objUser->nDateExpires) ?></td></tr>
			<tr><td class="gridRow1" width="150">New Expiry Date</td><td class="gridOptions1">
				<input class="inputText" name="nDateExpires" id="nDateExpires" style="width: 80px;" value="<?php echo date('m/d/Y', strtotime('+1 year')); ?>" readonly >
				<img src="calendar/images/calendar2.gif" border="0" onClick="popUpCalendar(this, document.getElementById('nDateExpires'), 'mm/dd/yyyy')" style="cursor:pointer;" align="absmiddle">
			</td></tr>
			<tr><td class="gridRow1" width="150">Update ALL members to this new date?</td><td class="gridOptions1">
				<input type="checkbox" name="updateAll"> <small>Note: This will only update <b>manually</b> added members who belong to a membership level which is currently expired.
			</td></tr>
			<tr><td class="gridFooter" colspan="2">
				<input name="action" type="submit" class="inputsubmit" value="Update">			
			</td></tr>
			</table>
			  
			<br />
		</td>
	</tr>
</table>

<?php include_once ('b.php'); ?>

</body>
</html>