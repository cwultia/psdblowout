<?php

	if(isset($_POST['destruct'])){
		@session_start();
		if(isset($_SESSION['install']['nOnce'])){
			
			$nOnce = $_SESSION['install']['nOnce'];
			if($nOnce == $_POST['destruct']){
			// Attempt To Delete Install Dir.
			// If Exists - It Should, But Just Incase
			if(is_dir('../install')){
				
				if (version_compare(PHP_VERSION, '5.3.0') >= 0) {
					foreach(
					new RecursiveIteratorIterator(
						new RecursiveDirectoryIterator('../install', FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $path) {
						$path->isFile() ? @unlink($path->getPathname()) : @rmdir($path->getPathname());
					}
					@rmdir('../install');
				}
				else{
					  
					$iterator = new RecursiveDirectoryIterator('../install');  
					foreach (new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::CHILD_FIRST) as $file) {  
						if ($file->isDir()) @rmdir($file->getPathname());
						else @unlink($file->getPathname());   
					}
					@rmdir('../install');
				}
				
			}
		}
			unset($_SESSION['install']);
		}
	}
	include_once ('../conn.php');
	include_once ('../functions.php');
	include_once ('../includes/encrypt.php');


	// Lets check to see if logged in alredy. If already logged in than redirect to home
	if($secure->checkAuth('admin',false)){header("Location:home.php");exit;}

	if (isset($_COOKIE['adm_u'])) {
		$encrypt = new Encrypt();
		$user = $encrypt->decode($_COOKIE['adm_u']);
		$pass = $encrypt->decode($_COOKIE['adm_p']);
		$checked = 'checked';
	}
	else {
		$user = '';
		$pass = '';
		$checked = '';
	}
	
	$redirect = (isset($_GET['redirect']))?'?redirect='.urlencode($_GET['redirect']):'';
	

?>
<!DOCTYPE html>
<html>
<head>
		<title>Admin Login | Easy Member Pro</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- global level css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <!-- end of global level css -->
    <!-- page level css -->
    <link rel="stylesheet" type="text/css" href="css/pages/login.css" />
	<link href="css/notifications.css" rel="stylesheet" />
    <!-- end of page level css -->
</head>
	<body>
		<div class="container">
        <div class="row vertical-offset-100">
            <div class="col-sm-6 col-sm-offset-3  col-md-5 col-md-offset-4 col-lg-4 col-lg-offset-4">
                <div id="container_demo">
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
						<?php echo isset($message) ? $message.'<br />' : ''.'<br />' ?>
                            <form method="POST" action="verify.php<?php echo $redirect ?>" name="adm_login" id="adm_login">
                                <h3 class="black_bg">
                                    <img src="" alt="EMP">
                                    <br>Log in</h3>
                                <p>
                                    <label style="margin-bottom:0px;" for="user" class="uname"> <i class="livicon" data-name="user" data-size="16" data-loop="true" data-c="#3c8dbc" data-hc="#3c8dbc"></i>
                                        E-mail Address 
                                    </label>
                                    <input name="user" type="text" required id="user" placeholder="e-mail" value="<?php echo $user ?>" />
                                </p>
                                <p>
                                    <label style="margin-bottom:0px;" for="password" class="youpasswd"> <i class="livicon" data-name="key" data-size="16" data-loop="true" data-c="#3c8dbc" data-hc="#3c8dbc"></i>
                                        Password
                                    </label>
                                    <input name="password" type="password" required id="password" placeholder="eg. X8df!90EO" value="<?php echo $pass ?>" />
                                </p>
                                <p class="keeplogin">
                                    <input type="checkbox" name="rememberme" id="loginkeeping" value="1" <?php echo $checked ?>/>
                                    <label for="loginkeeping">
                                        Keep me logged in
                                    </label>
                                </p>
                                <p class="login button">
                                    <input type="submit" value="Login" class="btn btn-success" />
                                </p>
                             
								<input name="islogin" value="1" type="hidden" />
                            </form>
							<div class="text-center">Secure Area - Your Ip Address (<?php echo $_SERVER['REMOTE_ADDR'] ?>) will be recorded</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
		<!-- global js -->
    <script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <!--livicons-->
    <script src="vendors/livicons/minified/raphael-min.js" type="text/javascript"></script>
    <script src="vendors/livicons/minified/livicons-1.4.min.js" type="text/javascript"></script>
    <script src="js/josh.js" type="text/javascript"></script>
    <script src="js/metisMenu.js" type="text/javascript"></script>
    <script src="vendors/holder-master/holder.js" type="text/javascript"></script>
    <!-- end of global js -->
		 <script>
		  $(document).ready(function(){
			$("#adm_login").validate({
				errorPlacement: function(error, element) {
					error.appendTo( element.parent("td") );
				},
				 highlight: function(element){
						//$(element).css({"border": "2px solid #CC0000"});
						$(element).removeClass("textinput");
						$(element).removeClass("successHighlight");
						$(element).addClass("errorHighlight");
				 },
				 unhighlight: function(element){
						//$(element).css({"border": "2px solid #CC0000"});
						//$(element).removeClass("errorHighlight");
						//$(element).addClass("textinput");
						$(element).removeClass("textinput");
						$(element).removeClass("errorHighlight");
						$(element).addClass("successHighlight");
				 },
				 
				success: function(label,element) {
				   
				   
					var name = label.attr('for');
					var span = name + '_success';
					
					var span = document.getElementById(span);
		
					
					//label.selector='label.success';
					//label.text('<img src="images/ed_format_underline.gif" />');
					//alert(JSON.stringify(label, null, 4));
				},
				rules: {
					password: {
						required: true,
						minlength: 6
					},
					user: {
						required: true,
						email: true
					}
				}
			});
		  });
  		</script>
	</body>
</html>
