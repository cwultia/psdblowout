<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Easy Member Pro Control Panel</title>
<style>
body {
	margin:0px;}

h1 {
	color:#CC0000;}
</style>
</head>

<body>
		<div style="width:750px; margin:auto;">
		  <h1>Security Requirement:</h1>
		  <h2>You Must Delete The Install Directory Before You Continue.</h2>
		  <h3 style="text-align:center;"><a href="index.php">Try Again</a></h3>
		</div>
</body>
</html>