<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="sideHeader">&nbsp;Quick Navigation </td>
	</tr>
	<!-- MEMBER MANAGEMENT -->
	<tr>
		<td class="sideRow">
			<div class="NV1" id="RR" onClick="clikker1(RR2,BB2,CC2,DD2,RRp,BBp,CCp,DDp);" onMouseOut="msout(1)" onMouseOver="msover(1)" style="cursor: pointer; cursor: hand;"><img src="images/mm.jpg"  name="RRp" alt="" border="0" align="absmiddle" id="RRp" />&nbsp;Member Management <img src="images/downarrow.gif" /></div>
			<div class="NV2" id="RR2" style="DISPLAY: none">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/membergroups.gif" width="16" height="16" /> <a href="add_members.php" target="_top" class="black">Add Members</a><br /></td></tr>
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/members.gif" width="16" height="16" /> <a href="manage_members.php" target="_top" class="black">Manage Members</a><br /></td></tr>
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/search.gif" width="16" height="16" /> <a href="search_members.php" target="_top" class="black">Search Members</a><br /></td></tr>
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/emmail.gif" width="16" height="16" /> <a href="email_members.php" target="_top" class="black">Email Members</a><br /></td></tr>
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/icon-expired.png" width="16" height="16"> <a class="black" href="expired_members.php">Expired Members</a><br /></td></tr>
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/export.jpg" width="16" height="16" /> <a class="black" href="export_members.php" target="_top">Export Members</a></td></tr>
					<tr><td height="25" style="padding-left:20px"><img border="0" src="images/export.jpg" width="16" height="16" /> <a class="black" href="import_members.php" target="_top">Import Members</a></td></tr>
				</table>
			</div>
		</td>
	</tr>
	<!-- AFFILIATE MANAGEMENT -->
	<tr>
		<td class="sideRow">
			<div class="NV1" id="BB" onClick="clikker2(BB2,RR2,CC2,DD2,RRp,BBp,CCp,DDp);" onMouseOut="msout(2)" onMouseOver="msover(2)"  style="cursor: pointer; cursor: hand;"><img src="images/am.jpg" alt="" name="BBp" width="24" height="23" border="0" align="absmiddle" id="BBp" />&nbsp;Affiliate Management <img src="images/downarrow.gif" /></div>
			<div class="NV2" id="BB2" style="DISPLAY: none">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<!-- <tr><td height="25" style="padding-left:20px"  class="black" >Affiliate Management<br /></td><tr> --> 
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/ss.jpg"  width="16" height="16" /> <a href="affiliate_management.php" target="_top" class="black">Affiliate Options</a><br /></td><tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/dollor.gif" /> <a href="pay_affiliates.php" target="_top" class="black">Pay Affiliates</a><br /></td>	</tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/dollor.gif" /> <a href="pay_affiliates_files.php" target="_top" class="black">Affiliates Files</a><br /></td>	</tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/emmail.gif" width="16" height="16" /> <a href="email_members.php" target="_top" class="black">Email Affiliates</a><br /></td></tr>
					<tr><td height="25" style="padding-left:28px"><img src="images/export.jpg" alt="" align="absmiddle" border="0" /> <a class="black" href="export_affiliates.php">Export Affiliates</a></td></tr>
					<tr><td height="25" class="black" style="padding-left:20px">Promotional Tools<br /></td></tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/th.jpg" width="16" height="16" /> <a href="email_subject.php" target="_top"  class="black">Email Subject Lines </a><br /></td></tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/th.jpg" width="16" height="16" /> <a href="promotional_emails.php" target="_top" class="black">Promotional Emails</a><br /></td></tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/th.jpg" width="16" height="16" /> <a href="promotional_graphics.php" target="_top" class="black">Promotional Graphics</a><br /></td></tr>
					<tr><td height="25" class="black" style="padding-left:20px">Reports<br /></td></tr>
					<tr><td height="25" style="padding-left:28px"><img border="0" src="images/pay.jpg" width="16" height="16" /> <a href="unpaid_commissions.php" target="_top" class="black">Unpaid Commission</a><br /></td></tr>
				</table>
			</div>
		</td>
	</tr>
	<!-- PAGE MANAGEMENT -->
	<tr>
		<td class="sideRow">
			<div class="NV1" id="CC" onClick="clikker3(CC2,RR2,BB2,DD2,RRp,BBp,CCp,DDp);" onMouseOut="msout(3)" onMouseOver="msover(3)"  style="cursor: pointer; cursor: hand;"><img src="images/pm.jpg" alt="" align="absmiddle" border="0" name="CCp" id="CCp" />&nbsp;Content Management <img src="images/downarrow.gif" /></div>
			<div class="NV2" id="CC2" style="DISPLAY: none">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">					
					<tr><td height="25" style='padding-left:20px'><img border="0" src="images/file_management.jpg" width="16" height="16" /> <a class="black" href="file_management.php" target="_top">File Management</a><br /></td></tr>
					<tr><td height="25" style='padding-left:20px'><img border="0" src="images/directories.gif" width="16" height="16" /> <a class="black" href="directory_management.php" target="_top">Folders</a><br /></td></tr>
					<tr><td height="25" style='padding-left:20px'><img border="0" src="images/mp.jpg" width="16" height="16" /> <a class="black" href="page_management.php" target="_top">Page Management</a><br /></td></tr>
					<tr><td height="25" style='padding-left:20px'><img border="0" src="images/icon_video.png" width="16" height="16" /> <a class="black" href="video_management.php" target="_top">Video Management</a><br /></td></tr>			
				</table>
			</div>
		</td>
	</tr>
	<!-- SETTINGS -->
	<tr>
		<td class="sideRow">
			<div class="NV1" id="DD" onClick="clikker4(DD2,RR2,BB2,CC2,RRp,BBp,CCp,DDp);" onMouseOut="msout(4)" onMouseOver="msover(4)"  style="cursor: pointer; cursor: hand;"><img src="images/ss.jpg" alt="" align="absmiddle" border="0" name="DDp" id="DDp" />&nbsp;System Settings <img src="images/downarrow.gif" /></div>
			<div class="NV2" id="DD2" style="DISPLAY: none">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr><td height="25" style="padding-left:20px"  class="black" >General Settings<br /></td><tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_email.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="autoresponder_settings.php">Autoresponders</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_email.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="email_templates.php">Email Templates</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_settings.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="script_settings.php">Site Settings</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_member.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="user_fields.php">User Fields</a></td></tr>
	 
	 				<tr><td height="25" style="padding-left:20px"   class="black">Payment Settings</td></tr>
	 				<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon-coupon.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="coupons.php">Coupons</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon-levels.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="member_levels.php">Member Levels</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px" ><img src="images/dollor.gif" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="payment_plans.php?action=reset">Payment Plans</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px" ><img src="images/dollor.gif" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="payment_processors.php">Payment Processors</a></td></tr>
					
					<tr><td height="25" style="padding-left:20px"   class="black">Template Settings</td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_dictionary.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="language_settings.php">Language Settings</a></td></tr>
	 				<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_settings.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="template_setup.php">Template Setup</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon-images.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="template_graphics.php">Template Graphics</a></td></tr>
					<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon-colors.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="template_colors.php">Template Colors</a></td></tr>
					
					<tr><td height="25" style="padding-left:20px"   class="black">Testing &amp; Tracking (SEO)</td></tr>
	 				<tr><td class="sideRow" style="padding-left:28px"><img src="images/icon_seo.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="testing_tracking.php">Settings</a></td></tr>
									
				</table>
			</div>
		</td>
	</tr>
	<tr>
		<td class="sideRow"><img src="images/bk.jpg" alt="" align="absmiddle" border="0" />&nbsp;<a class="opt" href="backup_database.php">Database <a class="opt" href="backup_database.php">Backups</a></a></td>
	</tr>
</table>
