<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="sideHeader">&nbsp;Affiliate Reports </td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_affiliates_top.php">Top 25 Affiliates</a></td>
  </tr>
</table>
<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="sideHeader">&nbsp;Member Reports </td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_members_level.php">Members By Level</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_members_30days.php">Members In Last 30 Days</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_members_stickrate.php">Member Stick Rate By Level</a></td>
  </tr>
</table>
<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="sideHeader">&nbsp;Revenue
      Reports </td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_refunds_level.php">Refunds By Level</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_revenue.php">Revenue By Month</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_report.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href=" report_revenue_30days.php">Revenue In Last 30 Days</a></td>
  </tr>
</table>