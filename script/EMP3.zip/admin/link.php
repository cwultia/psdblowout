<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$rw1 = $dbo->getobject("SELECT * FROM tblpages where nPage_ID ='" . $dbo->format($_GET["id"]) . "'");
	
	$path="index.php?page=".$rw1->sFileName;
	
	if(usePageLevels($rw1->nDirectory_ID)) $path = 'member/'.$path;
	
?>
<html>
<head>
<title>
<?php echo $admintitle; ?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="common/css/styles.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color:;
}
-->
</style>
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0"  >
<br>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>Use the page below to link to pages in your membership site from other internal pages, or from other external websites </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="border: 1px solid #CCC;">
  <tr>
    <td  align="right" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td  align="right" valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr valign="top">
        <td width="29%" align="center" valign="middle" class="black">Internal Page Link </td>
        <td width="71%"><input name="link" type="text" value="<?php echo $path;?>" size="50"></td>
      </tr>
      <tr valign="top">
        <td align="center" valign="middle" class="black">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="top">
        <td align="center" valign="middle" class="black">External Page Link </td>
        <td><input name="link2" type="text" value="<?php echo $sSiteURL."/".$path;?>" size="50"></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td  align="right" valign="top">&nbsp;</td>
  </tr>
</table>

</body>
</html>
