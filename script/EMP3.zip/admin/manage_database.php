<?php
	include_once('../conn.php');
	include_once('../functions.php');
	global $db_name;
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Database Management System';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;
	
	// Get Table Data
	$sql = "SHOW TABLE STATUS FROM `".$db_name."`;";
	
	$result = $dbo->select($sql);
	$tnr = $dbo->nr($result);
	$nr = $tnr - 1;
	$i = 0;
	while ($array = $dbo->getassoc($result)) {
		foreach($array as $k=>$v){
			$key = $k;
			$tables[$i][$key] = $v;
		}
		$i++;
	}
require_once('header.php');
	?>
   <aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
       <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a> </li>
      <li>Database</li>
      <li class="active">Manage Database</li>
    </ol>
  </section>
  <section class="content">
  <div class="col-md-12">
  <?php echo isset($message) ? $message : '' ?>
  <form action="actions.php?type=db" method="post" id="dbtables" name="dbtables">
  <div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Database Management System</h3>
					</div>
					<div class="panel-body">
					<div class="table-responsive">
  <div class="col-md-6"><table class="table table-striped table-bordered table-hover">
  <thead>
  <tr>
    <th></th>
    <th>Table Name</th>
    <th>Total Rows</th>
    <th>Table Size</th>
    <th>Actions</th>
  </tr>
  </thead>
  <tbody>
  <?php 
  $row = 0;
  while($row <= $nr){
	$ttext = ' KB';
	$total = ($tables[$row]['Data_length'] + $tables[$row]['Index_length']) / 1024;
	if($total > '512'){$total = $total / 1024; $fstext = ' MB';}
	if(($row+1) >floor($tnr / 2)){
			?>
  <tr>
    <td ><input name="<?php echo $tables[$row]['Name']?>" type="checkbox" value="1"></td>
    <td ><?php echo $tables[$row]['Name']?></td>
    <td ><?php echo $tables[$row]['Rows'] ?></td>
    <td ><?php echo round($total,2).$ttext ?></td>
    <td >
    <form action="actions.php?type=db" method="post" style="margin:0px; padding:0px;">
        <?php
						if($tables[$row]['Name'] == 'tbladminlogins' || $tables[$row]['Name'] == 'tbluserlogins' || $tables[$row]['Name'] == 'tblcronlog' || $tables[$row]['Name'] == 'tblquerylog'|| $tables[$row]['Name'] == 'tblipnlog'){ ?>
        <input type="hidden" value="clear" name="act" />
        <input name="" type="image" src="images/log_delete.png" title="Clear Logs">
        <input type="hidden" value="<?php echo $tables[$row]['Name']?>" name="table" />
        <?php } ?>
      </form>
      </td>
  </tr>
  <?php }
  	$row++;}	?>
	</tbody>
</table></div>
  <div class="col-md-6"><table class="table table-striped table-bordered table-hover">
  <thead>
  <tr>
    <th></th>
    <th>Table Name</th>
    <th>Total Rows</th>
    <th>Table Size</th>
    <th>Actions</th>
  </tr>
  </thead>
  <tbody>
  <?php	
  $row = 0;
  while($row <=$nr){$therow = $row;
	$ttext = ' KB';
	$total = ($tables[$row][Data_length]+$tables[$row][Index_length]) / 1024;
	if($total > '512'){$total = $total / 1024; $fstext = ' MB';}
	if(($row+1)<=floor($tnr / 2)){?>
  <tr>
    <td ><input name="<?php echo $tables[$row]['Name']?>2" type="checkbox" value="1"></td>
    <td ><?php echo $tables[$row]['Name'] ?></td>
    <td ><?php echo $tables[$row]['Rows'] ?></td>
    <td ><?php echo round($total,2).$ttext ?></td>
    <td ><form action="actions.php?type=db" method="post" style="margin:0px; padding:0px;">
        <?php
if($tables[$row]['Name'] == 'tbladminlogins' || $tables[$row]['Name'] == 'tbluserlogins' || $tables[$row]['Name'] == 'tblcronlog' || $tables[$row]['Name'] == 'tblquerylog'|| $tables[$row]['Name'] == 'tblipnlog'){ ?>
        <input type="image" src="images/log_delete.png" title="Clear Logs">
        <input type="hidden" value="clear" name="act" />
        <input type="hidden" value="<?php echo $tables[$row]['Name']?>" name="table" />
        <?php } ?>
      </form></td>
  </tr>
  <?php
			
			
			}
	$row++;
		}
?>
</tbody>
</table></div>
</div>
<div style="clear:both; padding:5px; background-color:#369; color:#FFFFFF"><a style="color:#FFFFFF" href="javascript:checkAll('dbtables', true);">Check All</a> / <a href="javascript: checkAll('dbtables', false);" style="color:#FFFFFF" >Uncheck All --&gt;</a> <em>With selected:</em>
        <span style=" color:#000"><select name="act">
          <option value="backup">Backup</option>
          <option value="optlist">Optimize</option>
        </select></span>
        <input type="submit" name="button2" id="button2" value="Go &gt;&gt;" class="btn btn-success btn-responsive btn-xs">
</div></div></div>
  
  </form>
  
  </div>
  
  
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
        <script type="text/javascript">
        function toggle(id){
			var ele = document.getElementById(id).style.display;
			
			if(ele == 'none'){document.getElementById(id).style.display = 'block'}
			else{document.getElementById(id).style.display = 'none';}
			}
function checkAll(frm, checkedOn) {
    // have we been passed an ID
    if (typeof frm == "string") {
        frm = document.getElementById(frm);
    }

    // Get all of the inputs that are in this form
    var inputs = frm.getElementsByTagName("input");

    // for each input in the form, check if it is a checkbox
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            inputs[i].checked = checkedOn;
        }
    }
}
        </script>
        <script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
</body>
</html>