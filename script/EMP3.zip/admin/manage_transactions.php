<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Manage Transactions';
	$css = <<<EOT
<!--page level css -->
<link href="vendors/modal/css/component.css" rel="stylesheet" />
<link href="vendors/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen" />
<!--end of page level css-->
EOT;
	
	// Load Refunded Transaction List ...
	$sql = "SELECT nTransaction_ID
	FROM `tbltransactions`
	WHERE sTransactionNumber
	IN (
		SELECT sTransactionNumber
		FROM tbltransactions
		WHERE nTransactionType_ID =2
	)
	AND nTransactionType_ID = '1'";
	
	$res = $dbo->select($sql);
	$refundedIds = array();
	if($dbo->nr($res)) while($row = $dbo->getobj($res)) $refundedIds[] = $row->nTransaction_ID;
	unset($res);
	
	// get tx types
	$result = $dbo->select("SELECT * FROM tbltransactiontypes;");
	while ($row = $dbo->getobj($result)) $txtypes[$row->nTransactionType_ID] = $row->sType;
			
	// Get Payment Processors
	$payres = $dbo->select("SELECT nPaymentProcessor_ID,sProcessorName FROM tblpaymentprocessors");
	if($payres) while($row = $dbo->getobj($payres)) $processors[$row->nPaymentProcessor_ID] = $row->sProcessorName;
	
	// Get total number of transactions AND get a currency amount.
	// This is the query for the total revenue text.
	$sql2 = "SELECT COUNT( * ) nCount FROM `tbltransactions` ";
	$sql3 = "SELECT COUNT( * ) nCount, SUM( `nSaleAmount` ) revenue FROM `tbltransactions` WHERE nTransactionType_ID = '1'";
	$sql3 = "SELECT COUNT( * ) nCount, SUM( `nSaleAmount` ) revenue FROM `tbltransactions` WHERE nTransactionType_ID = '2'";
	//$countquery = $dbo->getobject($sql2);
	$countquerySales = $dbo->getobject($sql3);
	$countqueryRefunds = $dbo->getobject($sql4);
	// Build Display Data
	$number = $countquerySales->nCount + $countqueryRefunds->nCount; // Number of records
	$revenue = $countquery->revenue;
	
	// Main query
	$sql = "
	SELECT tbltransactions.*,
	tblusers.sForename as firstname,
	tblusers.sSurname as lastname 
	FROM tbltransactions 
	LEFT JOIN tblusers ON tblusers.nUser_ID = tbltransactions.nUser_ID ";
	
	
	// Query Filters
	if(isset($_GET['id'])) $sql .="WHERE nTransaction_ID = ".$_GET['id']." ";
	elseif(isset($_GET['user'])) $sql .="WHERE tbltransactions.nUser_ID = ".$_GET['user']." ";	
	
	// Query Sorting		
	switch ($_GET['sort']) {
		case 'amount':
			$sortfield = 'tbltransactions.nSaleAmount';
			break;
		case 'txtype':
			$sortfield = 'tbltransactions.nTransactionType_ID';
			break;
		case 'processor':
			$sortfield = 'tbltransactions.sProcessor';
			break;
		case 'txnum':
			$sortfield = 'tbltransactions.sTransactionNumber';
			break;
		case 'email':
			$sortfield = 'tblusers.sEmail';
			break;
		case 'joindate':
			$sortfield = 'tblusers.nJoinDate';
			break;
		case 'referrer':
			$sortfield = 'sAffSurname';
			break;
		default:
			$sortfield = 'tbltransactions.dDateTime';
	}
	$sql .= "ORDER BY $sortfield {$_GET['type']}";
			
	$totalRecords = $dbo->num_rows($sql);	
	// Start Paging
	/*********************************************************/
	include_once('paging.php');
	$objPaging = new Paging();
	$aMPP = array('5', '10', '15', '20', '25', '50', '100');
	$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];
	$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
	unset($_GET['start']);
		 	
	$objPaging->Total_Records_Per_Page = $mpp; 
	$objPaging->Total_Records = $totalRecords;
	$index = $start ;
	$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
	$objPaging->prepare_ParameterString($_GET);
	$objPaging->set_Start_Item($indexupto); 	 		 	
	$objPaging->Has_First_Last = true;	
	$navigator = $objPaging->Create_Paging();
	$pageinfo = $objPaging->get_PageInfo();	 	
	$counter = 0;  
	$sql .= "LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
	/*********************************************************/
//die($sql);
	$mainres = $dbo->select($sql);
	
	// Put together QueryString
	$qs = sprintf("?qry=%s&srchval=%s&start=%s&mpp=%s", $_GET['qry'], $_GET['srchval'], $start, $mpp);
			
	// Used For Sorting Links ...
	// Load Defaults
	$txtype = $txname = $processor = $dDateTime = 'desc';
			  
	if($_GET['sort']) {
		$type = ($_GET['type'] == 'asc')?'desc':'asc';
		$$_GET['sort'] = $type;
	}
require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Admin Logs</li>
			<li class="active">Transaction Log</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <?php if( isset($message)) echo $message ?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Manage Transactions</h3>
        </div>
        <div class="panel-body">
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
          <div style="clear:both"></div>
          <div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
  <thead>
    <tr>
      <th>Amount</th>
      <th><a href="manage_transactions.php<?php echo $qs?>&sort=txtype&type=<?php echo $txtype ?>" class="bluenave">Type</a></th>
      <th>Member</th>
      <th><a href="manage_transactions.php<?php echo $qs?>&sort=processor&type=<?php echo $processor; ?>" class="bluenave">Processor</a></th>
      <th><a href="manage_transactions.php<?php echo $qs?>&sort=txname&type=<?php echo $txname; ?>" class="bluenave">Processor Transaction Id</a></th>
      <th><a href="manage_transactions.php<?php echo $qs?>&sort=dDateTime&type=<?php echo $dDateTime ?>" class="bluenave">Date/Time</a></th>
      <th>Affiliate</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php
	// Add Sort to QueryString
	$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['type']);
	if ($mainres){
		while ($row = $dbo->getobj($mainres)) { 
	?>
    <tr>
      <td><?php 
		$style =($txtypes[$row->nTransactionType_ID] == 'Refund')?'color: #FF0000;':'color:#009900;';
                    
        // Format The Number For Display
        $neg = '';
        $value = number_format((float)$row->nSaleAmount, 2, '.', '');
                    
        if($txtypes[$row->nTransactionType_ID] == 'Refund'){
        	$value = str_replace('-','',$value);
            $neg = '- ';
        }
        $prettynum = get_currency_symbol($chkSsettings->sCurrencyFormat).$neg.$value;
        echo '<span style="'.$style.'">'.$prettynum.'</span>';
        if($row->nUser_ID){$name = $row->firstname.'&nbsp;'.$row->lastname;}
        else{
        	// version 2.x member details
        	$name = $row->sUserSurname.'&nbsp;'.$row->sUserForename;
		}
    ?></td>
      <td><?php echo '<span style="'.$style.'">'.trim($txtypes[$row->nTransactionType_ID]).'</span>'; ?></td>
      <td><a href="view_member.php?id=<?php echo $row->nUser_ID ?>"> <?php echo $name ?> </a></td>
      <td><strong><?php echo trim($row->sProcessor); ?></strong></td>
      <td><?php echo $row->sTransactionNumber ?></td>
      <td><?php echo date('m/d/Y h:i:s',strtotime($row->dDateTime)) ?></td>
      <td><?php echo $row->sAffForename . '&nbsp;' . $row->sAffSurname ?></td>
      <td><form name="form1" method="post" action="actions.php?type=transaction">
          <?php if($row->nTransactionType_ID == '1') {
                        if(!in_array($row->nTransaction_ID,$refundedIds)){?>
          <a class="btn btn-primary btn-responsive" data-toggle="modal" data-href="#refundTrans" href="#refundTrans" data-transid="<?php echo $row->nTransaction_ID?>" data-transnumber="<?php echo $row->sTransactionNumber ?>">Refund</a>
          <?php }else{ ?>
          <a class="btn btn-error" disabled>Refunded</a></span>
          <?php }} ?>
          <a class="btn btn-primary btn-responsive" data-toggle="modal" data-href="#TransEdit_<?php echo $row->nTransaction_ID ?>" href="#TransEdit_<?php echo $row->nTransaction_ID ?>">Edit</a>
          <input type="hidden" name="act" value="delete" />
          <input type="hidden" name="tx_id" value="<?php echo $row->nTransaction_ID?>" />
          <input type="submit" name="button2" id="button2" value="Delete" class="btn btn-danger" onClick="return cdel();">
        </form></td>
    </tr>
    <?php 
		}
	}
	else{?>
    <tr>
      <td colspan="8" >No Transactions Recorded</td>
    </tr>
    <?php 
	}
?>
  </tbody>
</table>

          </div>
          <div class="row" style="padding-bottom:5px;">
            <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
            <div style="width:50%;float:left">
              <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<div class="modal fade in" id="refundTrans" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
  <form action="actions.php?type=transaction" method="post" id="Model-Form">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title">Process Refund</h4>
        </div>
        <div class="modal-body">
        <strong>Are You Sure you want to refund this transaction?</strong><br>
      <br>--------------------
      Processing Options --------------------<br>
          <input name="removeCommission" type="checkbox" value="1" checked>
          <strong>Remove Affiliate Commission </strong><br>
          <input name="cancelLevel" type="checkbox" value="1" checked>
          <strong>Cancel Membership Level Access</strong>
          <p>-------------------- Processing Options --------------------</p>
          <p><strong>This action cannot be undone!</strong></p>
          
        </div>
        <div class="modal-footer">
          <input type="hidden" name="trans_id" id="trans_id" value="" />
          <input type="hidden" name="sTransactionNumber" id="refundTransactionNumber" value="">
          <input type="hidden" name="act" value="processRefundManually">
          <button type="button" data-dismiss="modal" class="btn">Close</button>
          <button type="submit" class="btn btn-primary btn-responsive"> Save Changes </button>
        </div>
      </div>
    </div>
  </form>
</div>
<?php
	// We need to go back through the loop and print divisions.
	if(is_object($mainres)){
		$dbo->seek($mainres, 0);
		if($dbo->nr($mainres)){
		while($row = $dbo->getobj($mainres)){
			if($row->nUser_ID){$name = $row->firstname.'&nbsp;'.$row->lastname;}
			else{
				// version 2.x member details
				$name = $row->sUserSurname.'&nbsp;'.$row->sUserForename;
			}
?>
			<div class="modal fade in editTrans" id="TransEdit_<?php echo $row->nTransaction_ID ?>" 
tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
  <form action="actions.php?type=transaction" method="post" id="Model-Form">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title">Edit Transaction</h4>
        </div>
        <div class="modal-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <tr>
                <th>Member</th>
                <td ><input  name="mem" value="<?php echo $name ?>"onKeyUp="lookup(this.value,'mem.php','#suggestionsm','#autoSuggestionsListm');" type="text"  class="required" autocomplete="off" />
                  <input name="suggestionsmHidden" type="hidden" value="<?php echo $row->nUser_ID ?>" />
                  </label></td>
              </tr>
              <tr>
                <th>Type</th>
                <td ><select name="trans_type" id="trans_type">
                    <option value="1" <?php echo ($row->nTransactionType_ID == '1')?'selected="selected"':''?>>Sale</option>
                    <option value="2" <?php echo ($row->nTransactionType_ID == '2')?'selected="selected"':''?>>Refund</option>
                    <option value="3" <?php echo ($row->nTransactionType_ID == '3')?'selected="selected"':''?>>Cancellation</option>
                  </select></td>
              </tr>
              <tr>
                <th>Processor</th>
                <td ><select name="processor" id="processor">
                    <option value="" selected>None</option>
                    <?php
                            foreach ($processors as $k=>$v){?>
                    <option value="<?php echo $v ?>" <?php echo ($row->sProcessor == $v) ?'selected="selected"':'' ?>><?php echo $v ?></option>
                    <?php }
                            
                        if($txtypes[$row->nTransactionType_ID] == 'Refund'){
                            
                            $style = 'color: #FF0000;';}
                        else{$style = 'color:#009900;';}
                        // Format The Number For Display
                        $neg = '';
                        $value = number_format((float)$row->nSaleAmount, 2, '.', '');
                        
                        if($txtypes[$row->nTransactionType_ID] == 'Refund'){
                            $value = str_replace('-','',$value);
                            $neg = '- ';
                        }
                        $prettynum = $value;
                        
                         ?>
                  </select></td>
              </tr>
              <tr>
                <th>Amount</th>
                <td ><?php echo get_currency_symbol($chkSsettings->sCurrencyFormat)?>
                  <input type="text" name="trans_amount" id="trans_amount" value="<?php echo $prettynum ?>"></td>
              </tr>
              <tr>
                <th>Date</th>
                <td >
                <div class="form-group">
        			<div class="input-group date form_datetime0 col-md-10">
                                    <input name = "trans_datetime" size="20" type="text" readonly class="form-control" value="<?php echo date('Y-m-d h:i',strtotime($row->dDateTime)) ?>">
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-th"></span>
                                    </span>
                                </div>
                            </div>
               </td>
              </tr>
              <tr>
                <th>Transaction #</th>
                <td ><div id="txncontainer_<?php echo $row->nUserLevel_ID ?>">
                    <input name="Txn" type="text"  value="<?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'';?>" autocomplete="off"/>
                  </div></td>
              </tr>
            </table>
          </div>
        </div>
        <div class="modal-footer">
          <input type="hidden" name="trans_id" value="<?php  echo $row->nTransaction_ID  ?>" />
          <input type="hidden" name="act" value="edit" />
          <button type="button" data-dismiss="modal" class="btn">Close</button>
          <button type="submit" class="btn btn-primary btn-responsive"> Save Changes </button>
        </div>
      </div>
    </div>
  </form>
</div>
    
<?php
		}
	}
	}
?>
    
    
<?php require_once('footer.php');?>


<script src="vendors/modal/js/classie.js"></script> 
<script src="vendors/modal/js/modalEffects.js"></script>
<!--datetime picker-->
<script type="text/javascript" src="vendors/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="vendors/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>

<script type="text/javascript"> 
		$('#refundTrans').on('show.bs.modal', function(e) {
		//get data-id attribute of the clicked element
		var id = $(e.relatedTarget).data('transid');
		var tn = $(e.relatedTarget).data('transnumber');
		//populate the textbox
		$(e.currentTarget).find('input[name="trans_id"]').val(id);
		$(e.currentTarget).find('input[name="sTransactionNumber"]').val(tn);
	});
		$(".form_datetime0").datetimepicker({
			dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',
			linkFormat: "mm/dd/yyyy hh:ii",
			timeFormat: "HH:mm:ss",
			yearRange: '1970:2037',
			changeYear: true 
		});
		function cdel(w) {
			return confirm("Are you sure that you want to delete this transaction? \n This action cannot be reversed.");
		}
		function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=0';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}
      function toggle(id){
		var ele = document.getElementById(id);
		if(ele.style.display == 'none'){ele.style.display = 'block'}
		else{ele.style.display = 'none'}
		}
	
	// Suggestion Scripting
	function lookup(inputString,file,suggestions,autosuggestionlist) {
		if(inputString.length == 0) {
			// Hide the suggestion box.
			$(suggestions).hide();
		}
		else {
			$.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$(suggestions).show();
					$(autosuggestionlist).html(data);
				}
			});
		}
	} // lookup
	function fill(thisValue,id,suggestions,thisValueId) {
		$(id).val(thisValue);
		$(suggestions+'Hidden').val(thisValueId);
		$(suggestions).hide();
	}
    </script>
<style type="text/css">
.suggestionsBox {
	position: absolute;
	left: 200px;
	top: 40px;
	margin: 10px 0px 0px 0px;
	width: 250px;
	background-color: #212427;
	-moz-border-radius: 7px;
	-webkit-border-radius: 7px;
	border: 2px solid #000;
	color: #fff;
}
.suggestionList {
	margin: 0px;
	padding: 5px;
}
.suggestionList li {
	margin: 0px 0px 5px 0px;
	padding: 3px;
	cursor: pointer;
}
.suggestionList li:hover {
	background-color: #659CD8;
}
</style>
</body></html>