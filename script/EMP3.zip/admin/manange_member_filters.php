<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$sql = "SELECT * FROM `tbloptions` WHERE `sName` LIKE 'mqf_%' ";
	$res = $dbo->select($sql);
	
	
?>
<html>
<head>
<title>
<?php echo $admintitle; ?>
</title>
<?php include('inc-head.php') ?>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="common/css/styles.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color:;
}
-->
</style>
<link href="../styles.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
	function getFilterTable(){
		$.ajax({
			type: "POST",
			url: "ajax/functions.php?act=loadMemberFiltersTable",
			data: {
				'variable1': 'content var1',
					'variable2': 'content var2'
			},
			success: function (response) {
			   $('#tableContainer').html(response);
			}
		});
		
	}
	function deleteFilter(name){
		if(confirm('Are you sure you want to delete this filter?')){
			$.ajax({
			type: "POST",
			url: "ajax/functions.php?act=deleteFilter",
			data: {
				'filterName': name
			},
			success: function (response) {
			   getFilterTable();
			}
		});
		}
		
	}

	$( document ).ready(function() {
		getFilterTable()
	});
</script>
</head>
<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0">
<br>
<div id="tableContainer">
Loading Filters ...
</div>

</body>
</html>