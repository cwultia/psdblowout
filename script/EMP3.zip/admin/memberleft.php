<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
<tr><td class="sideHeader">&nbsp;Member Management</td></tr>
<tr><td class="sideRow"><img src="../common/images/icons/user_add.png"  name="RRp" alt="" border="0" align="absmiddle" id="RRp3" style="float:left"/>&nbsp;<a class="opt" href="add_members.php">Add Members</a></td></tr>
<tr><td class="sideRow"><img border="0" src="../common/images/icons/group_gear.png" width="16" height="16" style="float:left" align="absmiddle"/>&nbsp;<a class="opt" href="manage_members.php">Manage Members</a></td></tr>
<tr><td class="sideRow"><img border="0" src="../common/images/icons/email_go.png" width="16" height="16" style="float:left" align="absmiddle" />&nbsp;<a class="opt" href="email_members.php">Email Members</a></td></tr>
<tr><td class="sideRow"><img border="0" src="../common/images/icons/expired.png" width="16" height="16" style="float:left" align="absmiddle" />&nbsp;<a class="opt" href="expired_members.php">Expired Members</a></td></tr>
<tr>
  <td class="sideRow"><img src="../common/images/icons/stop.png" alt="" width="16" height="16" border="" align="absmiddle"style="float:left" />&nbsp;<a class="opt" href="cancel_requests.php">Cancel Requests (<?php if
  ($cancel_requests) {echo $cancel_requests;}else echo "0"; ?>)</a></td>
</tr>
<tr><td class="sideRow"><img src="../common/images/icons/file_extension_xls.png" alt="" align="absmiddle" border="" />&nbsp;<a class="opt" href="export_members.php">Export Members</a></td></tr>
<tr><td class="sideRow"><img src="../common/images/icons/file_extension_xls.png" alt="" align="absmiddle" border="" />&nbsp;<a class="opt" href="import_members.php">Import Members</a></td></tr>
</table>
