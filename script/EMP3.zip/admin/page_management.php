<?php
include_once ('../conn.php');
include_once ('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Page Management';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

	function rebuildSort($did,$type = 'abc'){
	// This is a feature to rebuild the sort field system if sort fields contain duplicate values.
	$sql = "SELECT nPage_ID FROM tblpages WHERE nDirectory_ID = '".$did."' ";
		// Sort Type
		if($type == 'abc'){
			
			$sql .= "ORDER BY `sPageName` ASC;";
		}
	//die($sql);
	$res = $dbo->select($sql);
	$nr = $dbo->nr($res);
	//die(var_dump($nr));
	$i = 0;
	if($nr){
		while($row = $dbo->getobj($res)){
			$i++;
			$sql = "Update tblpages SET nSortOrder='$i' WHERE nPage_ID='".$row->nPage_ID."' ";
			//echo $sql;
			$dbo->update($sql);
			}
		}
	}

	if($_GET['act'] == 'buildSort'){rebuildSort($_GET['did']);}	
	//die($message);
	if(!isset($_GET['did'])){$_GET['did']=0;}
	/////////////////////////////////////////////////////////////
	// Lets Check the View Type - V3.0
	// View 0 - System Pages
	// View 1 - User Created Pages
	// View 2 - All Pages
	/////////////////////////////////////////////////////////////
	if(!isset($_GET['view'])){$_GET['view']=2;}
	if($_GET['view'] == 0){$viewsql = 'AND cre = 0';}
	elseif($_GET['view'] == 1){$viewsql = 'AND cre = 1';}
	else{$viewsql == '';}
	
	// Set the drop down for current view.
	$sel = 'selected="selected"';
	/////////////////////////////////////////////////////////////
	// Get Database stored QueryString
	$qs = $_SESSION['page_management_qs'];
	if (isset($qs)) {$qs = trim($qs, '?');parse_str($qs);}
	
	// Get Real QueryString Values (these trump stored)
	$act = (isset($_GET['act'])) ? $_GET['act'] : '';
	if (isset($_GET['did'])) $did = $dbo->format($_GET['did']);
	if (isset($_GET['ipp']))$ipp = $dbo->format($_GET['ipp']);
	if (isset($_GET['start']))$start = $dbo->format($_GET['start']);
	
	// Init Variables
	if (empty($did))$did = 0;
	if (empty($ipp))$ipp = 25;
	if (empty($start))$start = 0;
	
	// Setup Options for Items per Page listing
	$aIPP = array('5', '10', '15', '20', '25', '50', '100');
	
	//$nopay = array('home', 'support', 'affiliates', 'affiliate-edit', 'profile-edit','affiliateemails', 'creport', 'graphics', 'sendemail', 'faq','contact', 'changepassword', 'forum', 'promotionalemails');
			
	// Init Page
	$sql = "SELECT * FROM tblpages WHERE nDirectory_ID = '$did' $viewsql ORDER BY nSortOrder ASC "; // Must leave trailing space for Paganator string
	
	// Get Count to pass into paging object
	$rs = $dbo->select("SELECT COUNT(*) FROM tblpages WHERE nDirectory_ID = '$did' $viewsql");
	$row = $dbo->getarray($rs,'NUM');
	$number = $row[0];
	
	// Total Number Of Pages
	$tnp = $number;
	
	
	// Start Paging
	/*********************************************************/
	include_once ('paging.php');
	$objPaging = new Paging();
	
	unset($_GET['start']);
	
	$objPaging->Total_Records_Per_Page = $ipp;
	$objPaging->Total_Records = $number;
	$index = $start;
	$indexupto = $index + $objPaging->Total_Records_Per_Page;
	$objPaging->prepare_ParameterString($_GET);
	$objPaging->set_Start_Item($indexupto);
	$objPaging->Has_First_Last = true;
	$objPaging->Create_Paging();
	$navigator = $objPaging->get_Page_Navigation();
	$pageinfo = $objPaging->get_PageInfo();
	$counter = 0;
	$sql .= "LIMIT " . $objPaging->Total_Records_Per_Page . " OFFSET " . $index;
	/*********************************************************/
	//echo $sql;
	
	$pageres2 = $pageresult = $dbo->select($sql);
	
	// Put together QueryString
	$qs = sprintf("?did=%s&start=%s&ipp=%s", $did, $start, $ipp);
	//echo $qs;
	
	// Check is sort is properly setup. If not give link for setup to version 3.0
	$sql = "SELECT nSortOrder FROM tblpages WHERE nDirectory_ID = '".$dbo->format($_GET['did'])."' GROUP BY nSortOrder HAVING count(*) > 1;";
	
	$result = $dbo->select($sql);
	$nr=$dbo->num_rows($sql);
	
	if($nr){
		$invalidsort = 1;
		$invalidmsg = '<form action="actions.php?type=page" method="post">
		Sort Field Error! <input type="submit" name="button" id="button" value="Rebuild Sort System" />
		<input type="hidden" name="sortrebuilddid" value="'.$_GET['did'].'">
		<input type="hidden" name="act" value="sortrebuild">
		</form>';
		}

	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Content</li>
      <li class="active"> <a href="page_management.php<?php echo $_SESSION['page_management_qs'] ?>">Pages</a> </li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-2">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Directories</h3>
        </div>
        <div class="panel-body">
          <?php if(isset($_GET['did']))
		echo generateTreeFolderList($_GET['did']); 
		else echo generateTreeFolderList();?>
        </div>
      </div>
    </div>
    <div class="col-md-10">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Page Management</h3>
        </div>
        <div class="panel-body">
        <div class="row" style="padding-bottom:5px;">
          <label for="view_filter">View
            <select name="ipp" id='ipp' style='height:1.5em' onChange="updateIPP(this)">
              <?php foreach ($aIPP as $val) {$selected = ($val == $ipp) ? 'selected' : '';echo "<option value='$val' $selected>$val</option>";} ?>
            </select>
            <span style="width:auto; float:right;"> </span></label>
          <select name="view" id="view" onChange="document.location='page_management.php?view='+this.options[this.selectedIndex].value+'&start=0&did=<?php echo $did ?>' ">
            <option value="2" <?php if($_GET['view'] == 2) echo $sel  ?>>All Pages</option>
            <option value="0" <?php if($_GET['view'] == 0) echo $sel  ?>>System Pages</option>
            <option value="1" <?php if($_GET['view'] == 1) echo $sel  ?>>User Pages</option>
          </select>
          <a href="add_page.php?did=<?= $did ?>" style="margin-left:20px;"> <img src="images/page_add.png" border="0" style="margin-bottom:-7px" alt="Add New Page" title="Add New Page"> </a> </div>
        <div class="row" style="padding-bottom:5px;">
          <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
          <div style="width:50%;float:left">
            <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
          </div>
        </div>
        <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover">
          <thead>
            <tr>
              <th>Page Name</th>
              <th><?php $sd = ($sort == 'nSortOrder' && $sortdir == 'ASC') ? 'DESC' :'ASC'; ?>
                Sort Order</th>
              <!-- MEMBERSHIP LEVELS
<?php $sd = ($sort == 'nLevel_ID' && $sortdir == 'ASC') ? 'DESC' :'ASC'; ?>
<a href="page_management.php<?php echo $qs ?>&sort=nLevel_ID&sortdir=<?php echo $sd ?>" class="bluenave">Membership Level</a>
</td>-->
              <th><?php $sd = ($sort == 'sNavBarLocation' && $sortdir == 'ASC') ?'DESC' : 'ASC'; ?>
                Folder Location</th>
              <th><?php $sd = ($sort == 'sNavBarLocation' && $sortdir == 'ASC') ?'DESC' : 'ASC'; ?>
                Menu Location</th>
              <th colspan="7" >Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
$_SESSION['page_management_qs'] = $qs;
$rownum = 0;

if(!empty($pageresult)){
	while ($row = $dbo->getobj($pageresult)): $rownum++ ?>
            <!-- PAGE LISTING -->
            <tr valign="middle"> 
              <!-- PAGES -->
              <td ><?php echo $row->sPageName ?><a name="<?php echo $row->sPageName ?>"></a></td>
              <!-- ACTIONS --> 
              <!-- Sort Order-->
              <?php 
				  if($invalidsort){ echo '<td  colspan="2">'. $invalidmsg.' </td>';}
					else{ ?>
              <td  style="text-align:left" ><?php
	  if($rownum != 1){?>
                <form action="actions.php?type=page" method="post">
                  <input type="hidden" name="sortPageId" value="<?php echo $row->nPage_ID; ?>" />
                  <input type="hidden" name="act" value="resort">
                  <input type="hidden" name="sort" value="up" />
                  <input type="hidden" name="did" value="<?php echo $_GET['did'] ?>" />
                  <input type="hidden" name="order" value="<?php echo $row->nSortOrder ?>" />
                  <input type="hidden" name="anchor" value="<?php echo $row->sPageName ?>" />
                  <input type="image" src="images/icon_arrow_up.png" alt="Up"/>
                </form>
                <?php }?></td>
              <td  style="text-align:left;"><?php
	  if($rownum != $tnp){?>
                <form action="actions.php?type=page" method="post">
                  <input type="hidden" name="sortPageId" value="<?php echo $row->nPage_ID; ?>" />
                  <input type="hidden" name="act" value="resort">
                  <input type="hidden" name="sort" value="down" />
                  <input type="hidden" name="order" value="<?php echo $row->nSortOrder ?>" />
                  <input type="hidden" name="did" value="<?php echo $_GET['did'] ?>" />
                  <input type="hidden" name="anchor" value="<?php echo $row->sPageName ?>" />
                  <input type="image" src="images/icon_arrow_down.png" alt="Down"/>
                </form>
                <?php }?></td>
              <?php } ?>
              <!-- SORT ORDER -->
              <td align="left" valign="middle" ><?php
		// You SHOULD NOT be able to move system pages into new folders. Lets stop that ish ...
		// Also Added Toggable Editability Feature
		  if($row->cre==1){?>
                <form action="actions.php?type=page" name="foldermove<?php echo $rownum?>" method="post">
                  <div id="changedirlink<?php echo $rownum ?>"  style="display:inline;"> <?php echo getFolderNameById($row->nDirectory_ID); ?> [<a href = "javascript:void(0);" onClick="toggleEdit('<?php echo $rownum ?>','changedir')">Move</a>] </div>
                  <div id="changedirdata<?php echo $rownum ?>" style="display:none;"> [<a href = "javascript:void(0);" onClick="toggleEdit('<?php echo $rownum ?>','changedir')">Cancel</a>]
                    <?php  
			  
			  // Display the Change Folder Select
		?>
                    <select name="ndid" onChange="document.forms['foldermove<?php echo $rownum?>'].submit();">
                      <?php echo generateTreeFolder($row->nDirectory_ID); ?>
                    </select>
                    <?php  ?>
                  </div>
                  <?php }
		  else{
			  echo getFolderNameById($row->nDirectory_ID);
			  }
		   ?>
                  <input type="hidden" name="act" value="movefolder" />
                  <input type="hidden" name="movePageId" value="<?php echo $row->nPage_ID ?>" />
                  <input type="hidden" name="did" value="<?php echo $_GET['did']?>" />
                </form></td>
              <!-- NAV BAR LOCATION -->
              <td align="center" ><?php 
	/*if($_GET['did']!=0 && $_GET['did']!=1){ 
	echo $row->sNavBarLocation;
	 }
	 else{*/?>
                <div id="changemenulink<?php echo $rownum ?>"  style="display:inline;"> <?php echo '<div style="width:25px; float:left;">'.ucwords($row->sNavBarLocation); ?></div>
                [<a href = "javascript:void(0);" onClick="toggleEdit('<?php echo $rownum ?>','changemenu')">Change</a>]
            </div>
            </div>
          
          <div id="changemenudata<?php echo $rownum ?>"  style="display:none;"> [<a href = "javascript:void(0);" onClick="toggleEdit('<?php echo $rownum ?>','changemenu')">Cancel</a>]
            <form action="actions.php?type=page" method="post" name="menu<?php echo $rownum ?>">
              <select name="menu" onChange="document.forms['menu<?php echo $rownum ?>'].submit();">
                <option value="top" <?php if ($row->sNavBarLocation == 'top') {echo 'selected="true"';} ?>>Top</option>
                <option value="bottom" <?php if ($row->sNavBarLocation =='bottom') {echo 'selected="true"';} ?>>Bottom</option>
                <option value="none" <?php if ($row->sNavBarLocation =='none') {echo 'selected="true"';} ?>>None</option>
              </select>
              <input type="hidden" name="menuPageId" value="<?php echo $row->nPage_ID?>">
              <input type="hidden" name="act" value="menu">
              <input type="hidden" name="qs" value="<?php echo $qs ?>" />
            </form>
          </div>
          <?php // }?>
            </td>
          
          
          <!-- NAV FOLDER LOCATION -->
          
          
            <td align="center" ><form action="actions.php?type=page" method="post">
                <a href="edit_page.php<?php echo $qs ?>&id=<?php echo $row->nPage_ID ?>" title="Edit Page"><img src="images/edit.jpg" alt="Edit Page" width="16" height="16" border="0" class="iconspacing"></a>
              </form></td>
            <td ><form action="actions.php?type=page" method="post">
                <!-- Display -->
                
                <?php 
					  // YOu notice One option is echo'd while the other closes php.
					  // This is done to main appearence in php/html editors.
					  //die(var_dump($row));
					  if ($row->nDisplay == 1){ 
					  $imginput = 
					  '<input type="image" src="images/disp.jpg" alt="Don\'t Display" title="Don\'t Display" width="16" height="16" border="0" class="iconspacing">';
					  echo $imginput;
					  echo '<input type="hidden" name="status" value="0">';
						}else{ 
					  $imginput = 
					  '<input type="image" src="images/ddisp.jpg" alt="Display Page" title="Display Page" width="16" height="16" border="0" class="iconspacing">';
					  echo $imginput; ?>
                <input type="hidden" name="status" value="1">
                <?php } ?>
                <input type="hidden" name="statusPageId" value="<?php echo $row->nPage_ID ?>">
                <input type="hidden" name="act" value="status">
              </form></td>
            <td ><!-- Page Link --> 
              <a href="javascript:MM_openBrWindow('link.php?id=<?php echo $row->nPage_ID; ?>','address','width=500,height=180')"  title="Page Link"> <img src="images/chain.jpg" alt="Page Links" width="18" height="18" border="0" class="iconspacing"></a></td>
            <td colspan="4" ><form action="actions.php?type=page" method="post">
                <!-- Delete -->
                <?php if($row->cre==0): ?>
                <img src="images/dropd.gif" alt="Cannot Delete this Page" width="16" height="16" border="0" />
                <?php else: ?>
                <input type="image" src="images/drop.jpg" alt="Delete Page" title="Delete Page" OnClick="return cdel('<?php echo $row->sPageName ?>');"  >
                <?php endif; ?>
                <input type="hidden" name="act" value="delete">
                <input name="delPageId" type="hidden" id="delPageId" value="<?php echo $row->nPage_ID ?>">
              </form></td>
          </tr>
          <?php endwhile; ?>
          <?php }else{ ?>
          <tr >
            <td colspan="12" >No Pages Found</td>
          </tr>
          <?php } ?>
            </tbody>
          
        </table>
      </div>
      <div class="row" style="padding-bottom:5px;">
        <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
        <div style="width:50%;float:left">
          <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<style>
.iconspacing {
	margin-right:2px
}
#folder-list{
	list-style:none;
	padding:0;
	margin:0;
	font-weight:bold;
	
}
#folder-list ul{
	list-style:none;
	padding:0;
	margin:0;
	
}
#folder-list ul li{
	list-style:none;
	padding:0;
	margin:0;
	
}
#folder-list ul li ul{
	list-style:none;
	padding:0;
	margin:0 0 0 5px;
	
}
#folder-list li ul li{
	list-style:none;
	padding:0 0 0 5px;;
	margin:0 0 0 5px;
	
}
</style>
<script type="text/javascript">
function cdel(w) {return confirm("Are you sure you want to DELETE the\n\""+w+"\" page?");}
//function openPopup(page) {window.open(page,'','height=325,width=650,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');}
function MM_openBrWindow(theURL,winName,features) {window.open(theURL,winName,features);}
function updateIPP(oList) {
	var ipp = oList.options[oList.selectedIndex].value;
	var qs = '?start=0';
	qs += '&did=<?php echo $did ?>';
	qs += '&view=<?php echo $_GET['view'] ?>';
	qs += '&ipp=' + ipp;
	document.location = 'page_management.php' + qs;}
function toggleEdit(rownum,div){
			if(document.getElementById(div+'data'+rownum).style.display == 'block'){
			document.getElementById(div+'data'+rownum).style.display = 'none';
			document.getElementById(div+'link'+rownum).style.display = 'inline';
			}
			else{
			document.getElementById(div+'data'+rownum).style.display = 'block';
			document.getElementById(div+'link'+rownum).style.display = 'none';}
		}
</script>
</body></html>