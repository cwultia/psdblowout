<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="sideHeader">&nbsp;Content Management</td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/mp.jpg" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="page_management.php">Page Management</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/directories.gif" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="directory_management.php">System Folders</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon-levels.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="member_levels.php">Member Levels</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/file_management.jpg" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="file_management.php">File Management</a></td>
  </tr>
  <tr>
    <td class="sideRow"><img src="images/icon_video.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="video_management.php">Video Management</a></td>
  </tr>
</table>