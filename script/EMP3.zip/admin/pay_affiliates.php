<?php
	include_once('../conn.php');
	include_once('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Pay Affiliates';
	$css = <<<EOT
<!--page level css -->



<!-- daterange picker -->
<link href="vendors/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />

<!--end of page level css-->
EOT;

	if ($chkSsettings->sCurrencyFormat == 'USD') { $cvalue = '$'; }
	if ($chkSsettings->sCurrencyFormat == 'AUD') { $cvalue = 'AUD'; }
	if ($chkSsettings->sCurrencyFormat == 'CAD') { $cvalue = 'CAD'; }
	if ($chkSsettings->sCurrencyFormat == 'CZK') { $cvalue = 'CZK'; }
	if ($chkSsettings->sCurrencyFormat == 'DKK') { $cvalue = 'DKK'; }
	if ($chkSsettings->sCurrencyFormat == 'EUR') { $cvalue = '&euro;'; }
	if ($chkSsettings->sCurrencyFormat == 'HKD') { $cvalue = 'HKD'; }
	if ($chkSsettings->sCurrencyFormat == 'HUF') { $cvalue = 'HUF'; }
	if ($chkSsettings->sCurrencyFormat == 'NZD') { $cvalue = 'NZD'; }
	if ($chkSsettings->sCurrencyFormat == 'NOK') { $cvalue = 'NOK'; }
	if ($chkSsettings->sCurrencyFormat == 'PLN') { $cvalue = 'PLN'; }
	if ($chkSsettings->sCurrencyFormat == 'GBP') { $cvalue = 'GBP'; }
	if ($chkSsettings->sCurrencyFormat == 'SGD') { $cvalue = 'SGD'; }
	if ($chkSsettings->sCurrencyFormat == 'SEK') { $cvalue = 'SEK'; }
	if ($chkSsettings->sCurrencyFormat == 'CHF') { $cvalue = 'CHF'; }
	if ($chkSsettings->sCurrencyFormat == 'JPY') { $cvalue = '&yen;'; }

	$sql = "SELECT * FROM tblaffiliatesettings";
	$oAffiliateSettings = $dbo->getobject($sql);
	
	$lastmonth = date('Ym01');
	//echo $lastmonth;
	
	// UPDATE ALL COMMISSIONS AS PAID
	//=================================
	
	require_once('header.php');
	
	//================added for selections based on nDate field
	$daterange = explode('-',$_GET['dateRange']);
	
	//$dtStart = $_GET['dtStart'];
	//$dtEnd = $_GET['dtEnd'];
	$dtStart = $daterange[0];
	$dtEnd = $daterange[1];
	
	
	if ($_GET['show_unpaid_commissions'] == "") {
		$yStart = date(Y)-1;
		$dtStart = date("m/d/").$yStart;
		$dtEnd = date("m/d/Y");
	}
	//========================================================
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliates</li>
      <li class="active">Pay Affiliates</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div class="row" style="text-align:right; padding-bottom:10px;"> Displaying unpaid commissions from <?php echo $dtStart ?> to <?php echo $dtEnd ?> </div>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Display Commission Options</h3>
        </div>
        <div class="panel-body"> 
          <!-- added calendars to select date from to -->
          <div class="form-group">
          <form action="pay_affiliates.php" method="get">
            <label> Date range: </label>
            <div class="input-group">
              <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
              <input type="text" class="form-control" id="reservation" name="dateRange" value="<?php echo $dtStart?> - <?php echo $dtEnd?>"/>
            </div>
            <!-- /.input group -->
            </div>
            <input type="submit" value=" Show Unpaid Commissions " name="show_unpaid_commissions" class="btn btn-primary btn-responsive"/>
          </form>
          <!-- ========== ========= =========== ========== --> 
          
          <span class="red">
          <?php if ($_GET['act'] == 'scheck') { echo "Check Pay File has been generated successfully<br><br>"; } ?>
          <?php if ($_GET['act'] == 'spaypal') { echo "Paypal Pay File has been generated successfully<br><br>"; } ?>
          <?php if ($_GET['act'] == 'snotyet') { echo "Not Known Pay File has been generated successfully<br><br>"; } ?>
          <?php if ($_GET['act'] == 'gsus') { echo "Payments marked as paid<br><br>"; } ?>
          </span> </div>
      </div>
      <?php
	//================added for selections based on nDate field
	$dtStart = explode("/", $dtStart);
	$date_start = $dtStart[2] . $dtStart[0] . $dtStart[1];
	$date_start_timestamp = $dtStart[2] . "-" . $dtStart[0] . "-" . $dtStart[1] .
		" 00:00:00";
	
	$dtEnd = explode("/", $dtEnd);
	$date_end = $dtEnd[2] . $dtEnd[0] . $dtEnd[1];
	$date_end_timestamp = $dtEnd[2] . "-" . $dtEnd[0] . "-" . $dtEnd[1] .
		" 23:59:59";
	//============================================================    
    //Check if paypal is accepted//
    if ($oAffiliateSettings->nPaypal) {
		// Get Total Payments for PayPal
		$sql = "SELECT tblaffiliatepayments.nAffiliate_ID, SUM(tblaffiliatepayments.nCommission) AS amount FROM tblaffiliatepayments 
		INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
		WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
		AND (tblaffiliatepayments.sFilename = '' OR tblaffiliatepayments.sFilename IS NULL)
		AND NOT tblusers.sPaypalEmail = '' 
		AND nDate >= $date_start 
		AND nDate <= $date_end
		GROUP BY tblaffiliatepayments.nAffiliate_ID ";
		$rs = $dbo->select($sql);
		$commission = 0;
		$cnt = 0;
		if ($rs!==false) {
			while ($row = $dbo->getassoc($rs)) {
				$commission += $row['amount'];
				$cnt++;
			}	
		}

?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Paypal Commissions</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Total Payments </th>
                  <th>Total Commission</th>
                  <th>Pay Files</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo $cnt ?>&nbsp;</td>
                  <td><?php echo  $cvalue.number_format($commission, 2); ?>&nbsp;</td>
                  <?php if ($cnt > 0) { ?>
                  <td><a href="pay_affiliates_csv_paypal.php?date_start=<?php echo $date_start?>&date_end=<?php echo $date_end?>"><strong>Generate Pay File</strong></a></td>
                  <?php } else { ?>
                  <td colspan="2">No unpaid affiliate commisions</td>
                  <?php } ?>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php
    } //End of paypal check
    //Check if payment by checque is available
    if ($oAffiliateSettings->nCheck) {
		// Get Total Payments for Check
		$sql = "SELECT tblaffiliatepayments.nAffiliate_ID, SUM(tblaffiliatepayments.nCommission) AS amount FROM tblaffiliatepayments 
		INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
		WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
		AND (tblaffiliatepayments.sFilename = '' OR tblaffiliatepayments.sFilename IS NULL)
		AND (tblusers.sPaypalEmail IS NULL OR tblusers.sPaypalEmail = '')
		AND nDate >= $date_start 
		AND nDate <= $date_end								
		GROUP BY tblaffiliatepayments.nAffiliate_ID ";
		
		$rs = $dbo->select($sql);
		$commission = 0;
		$cnt = 0;
		if ($rs!==false) {
			while ($row = $dbo->getassoc($rs)) {
				$commission += $row['amount'];
				$cnt++;
			}	
		}
?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Check Commissions</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Total Payments </th>
                  <th>Total Commission</th>
                  <th>Pay File</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo $cnt ?>&nbsp;</td>
                  <td><?php echo  $cvalue.number_format($commission, 2); ?>&nbsp;</td>
                  <?php if ($cnt > 0) { ?>
                  <td><a href="pay_affiliates_csv_check.php?date_start=<?php echo $date_start?>&date_end=<?php echo $date_end?>"><b>Generate Pay File</b></a></td>
                  <?php } else { ?>
                  <td colspan="2">No unpaid affiliate commisions</td>
                  <?php } ?>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php
    } //End of checque 
    if ((!$oAffiliateSettings->nCheck) || (!$oAffiliateSettings->nPaypal)) {
	// Get Total Payments for Unknown Payment Status
	$sql = "SELECT tblaffiliatepayments.nAffiliate_ID, SUM(tblaffiliatepayments.nCommission) AS amount FROM tblaffiliatepayments 
	INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
	WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL) 
	AND nDate >= $date_start 
	AND nDate <= $date_end							
	AND (tblaffiliatepayments.sFilename = '' OR tblaffiliatepayments.sFilename IS NULL) ";
	//check which payments are accepted not accepted payment methods should be included in Not Yet Known
	if (($oAffiliateSettings->nCheck) && (!$oAffiliateSettings->nPaypal)) {
		$sql .= " AND tblusers.sPaypalEmail IS NOT NULL AND NOT tblusers.sPaypalEmail = '' ";
	}
	elseif ((!$oAffiliateSettings->nCheck) && ($oAffiliateSettings->nPaypal)) {
		$sql .= " AND (tblusers.sPaypalEmail IS NULL OR tblusers.sPaypalEmail = '') ";
	}
	$sql .=	" GROUP BY tblaffiliatepayments.nAffiliate_ID ";					
	$rs = $dbo->select($sql);
	$commission = 0;
	$cnt = 0;
	if ($rs!==false) {
		while ($row = $dbo->getassoc($rs)) {
			$commission += $row['amount'];
			$cnt++;
		}	
	}
?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Not Yet Known</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Total Payments </th>
                  <th>Total Commission</th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo $cnt ?>&nbsp;</td>
                  <td><?php echo  $cvalue.number_format($commission, 2); ?>&nbsp;</td>
                  <td>N/A</td>
                  <td>N/A</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php } ?>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script language="javascript">
	function confirmAction(sAction) {
		var sName = (sAction == 'paypal') ? 'PayPal' : 'Check';
		if (confirm("Are you sure you want to mark all \""+sName+"\" commissions as paid?\n\nMake sure you have generated the pay file before continuing.\n ")) {document.location.replace('pay_affiliates.php?paid='+sAction);
		}
	}
	$(function() {$('#reservation').daterangepicker();})	
</script> 

<!-- =========Added calendar in order to choose a date range --> 
<script src="vendors/daterangepicker/daterangepicker.js" type="text/javascript"></script>
</body></html>