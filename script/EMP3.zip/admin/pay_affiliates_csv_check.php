<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	
	$now = time();
	$sFilename = "check-masspay-" . date("Ymd") . ".csv"; // file name for CSV
	$lastmonth = date('Ym01');
	
	//=======added to get the select period =====================
	$date_start = $_GET['date_start'];
	$date_end = $_GET['date_end'];
	//===========================================================

	// Get Total Payments for Ceck
	$sql = sprintf("SELECT tblaffiliatepayments.nAffiliate_ID, 
	SUM(tblaffiliatepayments.nCommission) AS amount,
	MAX(tblusers.sForename) AS sForename, 
	MAX(tblusers.sSurname) AS sSurname, 
	MAX(tblusers.sAddr1) AS sAddr1,
	MAX(tblusers.sAddr2) AS sAddr2, 
	MAX(tblusers.sAddr3) AS sAddr3, 
	MAX(tblusers.sTown) AS sTown, 
	MAX(tblusers.sCounty) AS sCounty, 
	MAX(tblusers.sPostcode) AS sPostcode, 
	MAX(tblusers.sCountry) AS sCountry
	FROM tblaffiliatepayments 
	INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
	WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
	AND (tblusers.sPaypalEmail IS NULL OR tblusers.sPaypalEmail = '')
	AND (sFileName = '' OR sFileName IS NULL) 
	AND UNIX_TIMESTAMP(nTimeStamp) <= %s
	AND nDate >= $date_start 
	AND nDate <= $date_end							
	GROUP BY tblaffiliatepayments.nAffiliate_ID ", $now);

	$rs = $dbo->select($sql);

	$csv = sprintf("First, Last, Addr1, Addr2, Addr3, City, State, Postal Code, Country, Commission, Note\n");
	$note = 'For commissions earned before ' . date('F j Y', strtotime($lastmonth));
	
	if ($dbo->nr($rs) > 0) {
		while ($row = $dbo->getassoc($rs)) {
			$paypal = (!empty($row['sPaypalEmail'])) ? $row['sPaypalEmail'] : 'PayPal email missing';
			$csv .= sprintf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%.2f,%s\n", $row['sForename'], $row['sSurname'],$row['sAddr1'], $row['sAddr2'], $row['sAddr3'], $row['sTown'], $row['sCounty'],$row['sPostcode'], $row['sCountry'], $row['amount'], $note);
		}
		
		$sql = sprintf("UPDATE tblaffiliatepayments SET sFileName = '%s' 
		WHERE tblaffiliatepayments.nAffiliate_ID IN ( SELECT nUser_ID 
		FROM tblusers 
		WHERE tblusers.sPaypalEmail IS  NULL 
		OR tblusers.sPaypalEmail = '')
		AND (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
		AND (sFileName = '' OR sFileName IS NULL)
		AND nDate >= $date_start 
		AND nDate <= $date_end								  
		AND UNIX_TIMESTAMP(nTimeStamp) <= %s", $sFilename, $now);
	
		$rs = $dbo->select($sql);
		// Generate CSV file
		header('Content-type:text/csv');
		header('Content-disposition:attachment;filename=' . $sFilename);
		echo $csv;
		exit();
	}
	else { header("Location: pay_affiliates.php");}
?>