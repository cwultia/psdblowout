<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Affiliate Files';
	$css = <<<EOT
<!--page level css -->


<!--end of page level css-->
EOT;
	
	// UPDATE ALL COMMISSIONS AS PAID
	//=================================
	if ($_GET['act'] == 'pay') {
		$file = urlencode($_GET['file']);
		$sql = sprintf("UPDATE tblaffiliatepayments 
		SET sPaymentStatus = 'paid', nDatePaid = ".date('Ymd')."
		WHERE sFileName = '%s' AND (sPaymentStatus = '' OR sPaymentStatus IS NULL)", $dbo->format($file));
		$dbo->select($sql);
		$sql = sprintf("INSERT INTO tbltransactions(nTransactionType_ID, sUserEmail, sUserForename, sUserSurname, nSaleAmount)
		SELECT MAX(4), sUserEmail, `tblusers`.sForename, `tblusers`.sSurname, SUM(`tblaffiliatepayments`.nCommission) 
		FROM `tblaffiliatepayments`, `tblusers` 
		WHERE `tblaffiliatepayments`.`nAffiliate_ID` = `tblusers`.nUser_ID AND `tblaffiliatepayments`.`sFileName` = '$s' 
		GROUP BY  sUserEmail, `tblusers`.sForename, `tblusers`.sSurname;",$dbo->format($file));
		$dbo->select($sql);
				
	}
	elseif ($_GET['act'] == 'get') {
		
		// Code Bugged Below
		//$file = urlencode($_GET['file']) . 'txt';
		// Fix
		$file = urlencode($_GET['file']);
		$fileType = substr($file,0,strpos($file,'-'));
		
		$sql = sprintf("SELECT tblaffiliatepayments.nAffiliate_ID, 
			SUM(tblaffiliatepayments.nCommission) AS amount,
			MAX(tblusers.sForename) AS sForename, 
			MAX(tblusers.sSurname) AS sSurname, 
			MAX(tblusers.sAddr1) AS sAddr1, 
			MAX(tblusers.sAddr2) AS sAddr2, 
			MAX(tblusers.sAddr3) AS sAddr3, 
			MAX(tblusers.sTown) AS sTown, 
			MAX(tblusers.sCounty) AS sCounty, 
			MAX(tblusers.sPostcode) AS sPostcode, 
			MAX(tblusers.sCountry) AS sCountry, 
			MAX(tblusers.sPaypalEmail) AS sPaypalEmail
			FROM tblaffiliatepayments 
			INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
			WHERE sFileName = '%s'
			AND (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
			GROUP BY tblaffiliatepayments.nAffiliate_ID", $dbo->format($file));
		//die($sql);
		$rs = $dbo->select($sql);
		
		if ($fileType == 'paypal') {
			$csv = '';
			
			if(!$dbo->nr($rs)){die('No Records Found For Pay File: This should not happen');}
			else{
				while ($row = $dbo->getassoc($rs)) {
					// Build The Pay File
					// Paypal Requires A Tab Seperated File
					
					// PaypalEmail	PaymentAmount	CurrencyFormat	Unique Identifer	Note
					$tab = "\t";
					$email = $row['sPaypalEmail'];
					$amount = number_format($row['amount'],2);
					$currency = $chkSsettings->sCurrencyFormat;
					$payid = '';
					$note = 'Affiliate Payment From '.$chkSsettings->sSiteName;
					
					// Old
					//$csv .= sprintf("%s\t%.2f\t%s\n", $row['sPaypalEmail'], $row['amount'], $chkSsettings->sCurrencyFormat);
					// V3
					$csv .= $email.$tab.$amount.$tab.$currency.$tab.$payid.$tab.$note."\n";
				}
			}
			
		} elseif ($fileType == 'check') {
			$csv = sprintf("First, Last, Addr1, Addr2, Addr3, City, State, Postal Code, Country, Commission, Note\n");
			$note = 'For commissions earned';
			while ($row = $dbo->getassoc($rs)) {
				$csv .= sprintf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%.2f,%s\n", $row['sForename'], $row['sSurname'], $row['sAddr1'], $row['sAddr2'], $row['sAddr3'], $row['sTown'], $row['sCounty'], $row['sPostcode'], $row['sCountry'], $row['amount'], $note);
			}
		}
		
		header('Content-type:text/csv');
		header('Content-disposition:attachment;filename='.$file);
		echo $csv;}
	if ($_GET['act'] != 'get') {
		require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliates</li>
      <li class="active">Affiliate Files</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <p class="success">
        <?php if ($_GET['act'] == 'pay') { echo $_GET['file'] . " marked as paid"; } ?>
      </p>
      <?php 
		 $rsUnpaidFiles = $dbo->select("
		SELECT tblaffiliatepayments.sFileName, tblaffiliatepayments.nDatePaid, SUM(nCommission) as nTotalCommission 
		FROM tblaffiliatepayments 
		WHERE (sPaymentStatus = '' OR sPaymentStatus IS NULL) AND NOT (tblaffiliatepayments.sFileName = '' OR tblaffiliatepayments.sFileName IS NULL)
		GROUP BY tblaffiliatepayments.sFileName");
		?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Unpaid Files</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Date Paid</th>
                  <th>Total Pending Amount</th>
                  <th>File name</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($rsUnpaidFiles) { ?>
                <?php
		 while ($row = $dbo->getassoc($rsUnpaidFiles)) { ?>
                <tr>
                  <td><strong><span class="red">UnPaid </span></strong>- <a href="pay_affiliates_files.php?act=pay&file=<?php echo urlencode($row['sFileName'])?>">Mark As Paid</a></td>
                  <td><?php echo get_currency_symbol($chkSsettings->sCurrencyFormat).number_format($row['nTotalCommission'], 2).' '.$chkSsettings->sCurrencyFormat; ?>&nbsp;</td>
                  <td><a href="pay_affiliates_files.php?act=get&file=<?php echo urlencode($row['sFileName'])?>"><?php echo $row['sFileName'] ?></a></td>
                  <td>&nbsp;</td>
                </tr>
                <?php }
		}
		else{ ?>
                <tr>
                  <td colspan="4">No Unpaid Affiliate Statements</td>
                </tr>
                <?php }?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php
		$rsPaidFiles = $dbo->select("
		SELECT tblaffiliatepayments.sFileName, SUM(nCommission) as nTotalCommission,tblaffiliatepayments.nDatePaid as nDatePaid 
		FROM tblaffiliatepayments 
		WHERE sPaymentStatus = 'paid' 
		AND NOT (tblaffiliatepayments.sFileName = '' OR tblaffiliatepayments.sFileName IS NULL)
		GROUP BY tblaffiliatepayments.sFileName
		ORDER BY tblaffiliatepayments.nDatePaid DESC");
		?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Paid Files (
            <?php  echo $dbo->nr($rsPaidFiles) ?>
            )</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Date Paid</th>
                  <th>Total Paid Amount</th>
                  <th>File name</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($rsPaidFiles) { ?>
                <?php
			while ($row = $dbo->getassoc($rsPaidFiles)) { ?>
                <tr>
                  <td><?php echo ($row['nDatePaid'])?$row['nDatePaid']:'Unknown' ?></td>
                  <td><?php echo get_currency_symbol($chkSsettings->sCurrencyFormat).number_format($row['nTotalCommission'], 2).' '.$chkSsettings->sCurrencyFormat; ?>&nbsp;</td>
                  <td><a href="pay_affiliates_files.php?act=get&file=<?php echo urlencode($row['sFileName'])?>"><?php echo $row['sFileName'] ?></a></td>
                  <td></td>
                </tr>
                <?php } ?>
                <?php }
		else{?>
                <tr>
                  <td class="gridrow2" colspan="4">No Paid Affiliate Files</td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script language="javascript">
				function confirmAction(sAction) {
					var sName = (sAction == 'paypal') ? 'PayPal' : 'Check';
					if (confirm("Are you sure you want to mark all \""+sName+"\" commissions as paid?\n\nMake sure you have generated the pay file before continuing.\n ")) {
						document.location.replace('pay_affiliates.php?paid='+sAction);
					}
				}	
			</script>
</body></html><?php } 

?>