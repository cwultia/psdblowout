<?php
	include_once '../conn.php';
	include_once '../functions.php';
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Manage Payment Plans';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

// Update Payment Plans
if (isset($_POST['update'])) {
//die(var_dump($_POST));
    // Update coupon link
    foreach ($_POST as $key => $value) {
        if (substr($key, 0, 11) == 'nCoupon_ID_') {
            $sql = "UPDATE tblpaymentplans SET nCoupon_ID = $value WHERE nPaymentPlan_ID = " .substr($key, 11);
            $dbo->update($sql);
        }
    }

    
	#######################################################################################################
	// This will just update the status (active/deactive)
    if (is_array($_POST['chkExistingPlan'])) {
        $values = implode(",", $_POST['chkExistingPlan']);
    } 
	else {$values = 9999;}

    // Update unchecked boxes
    $sql = "UPDATE tblpaymentplans SET nActive=0 WHERE nPaymentPlan_ID NOT IN (" . $values .") ";
	if($_GET['level_id']){$sql .="AND nMembershipLevel_ID=" . $dbo->format($_GET['level_id']).";";}
	$dbo->update($sql);

    // Update checked boxes
    $sql = "UPDATE tblpaymentplans SET nActive=1 WHERE nPaymentPlan_ID IN (" . $values .") ";
	if($_GET['level_id']){$sql .="AND nMembershipLevel_ID=" . $dbo->format($_GET['level_id']).";";}
	
    $dbo->update($sql);
	###########################################################################################################3

    $message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>The payment plans were updated successfully</div>';}

// Delete Payment Plans
if (isset($_GET['delete'])) {


    $sql = "DELETE FROM tblpaymentplans WHERE nPaymentPlan_ID=" . $_GET['delete'];
    $dbo->update($sql);

    $message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>The payment plan was deleted successfully.</div>';}

$sql = "SELECT tblpaymentplans.*, tblpaymentprocessors.sProcessorName, tblpaymentprocessors.nActive as processorStatus FROM tblpaymentplans " .
        "INNER JOIN tblpaymentprocessors on tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID";
		
	if(isset($_GET['level_id'])){$sql .= ' WHERE tblpaymentplans.nMembershipLevel_ID='. $dbo->format($_GET['level_id']);}
		
        $sql .= ' ORDER BY sPlanName';
//die($sql);
    $plans = $dbo->select($sql);
	ob_start();
	?>

<select name="nLevel_ID" id="nLevel_ID" onChange="changeLevel();">
	<option value="">Every</option>
	<?php
		$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels WHERE nActive=1 ORDER BY `nOrder` ASC";
		$result = $dbo->select($sql);
		while ($objLevel = $dbo->getobj($result)) {
    		if (isset($_GET['level_id']) && $_GET['level_id'] == $objLevel->nLevel_ID) {
        		echo '<option value="' . $objLevel->nLevel_ID . '" selected>' . $objLevel->sLevel . '</option>';
    		}
			else {
        		echo '<option value="' . $objLevel->nLevel_ID . '">' . $objLevel->sLevel .'</option>';
    		}
		}
?>
</select>
<?php 
	$levelSelect = ob_get_clean();
	require_once('header.php');
	?>
<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Payment Settings</li>
			<li class="active">Payment Plans</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Manage Payment Plans</h3>
				</div>
				<div class="panel-body">
					<div class="row" style="padding-bottom:10px;">
						<form name="form1" method="post" action="">
							<a href="payment_plans_add.php"><img src="images/icon_add.png" width="16" height="16" alt="Add New Commission" border="0" style="vertical-align: middle"> Add New</a> | Show Payment Plans For <?php echo $levelSelect ?> Membership
						</form>
					</div>
					<form name="form2" method="post" action="<?php echo $_SERVER['PHP_SELF'] .'?' . $_SERVER['QUERY_STRING']; ?>">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th>Links</th>
										<th>Plan Name</th>
										<th>Member Count</th>
										<th>Processor</th>
										<th>Promotion Method</th>
										<th>Active?</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>
									<?php
    
    if ($plans !== false) {
		while ($row = $dbo->getobj($plans)) {
            //==============added for "delete plan option"
            $query_usedPlan = "SELECT COUNT(*) FROM tbluserlevels WHERE nPaymentPlan_ID=" .$row->nPaymentPlan_ID;
			$memcount = $dbo->getval($query_usedPlan);
			$query_usedPlan = "SELECT COUNT(*) FROM tbluserlevels WHERE nPaymentPlan_ID=" .$row->nPaymentPlan_ID." AND nActive = 0;";
			$memcountIA = $dbo->getval($query_usedPlan);
			//var_dump($usedPlan);
			
			if($row->nPaymentPlan_ID == '1'){
				$sDelete = "<a href='#' OnClick=\"alert('Sorry but you cannot delete " . $row->sPlanName . " because it is required by the system.'); \" >
				<img src='images/dropd.gif' alt='Delete Plan' border=''0'/></a>";
			}
			elseif ($memcount > 0) {
                $sDelete = "<a href='#' OnClick=\"alert('Sorry but you cannot delete " . $row->sPlanName . " because it is already in use, instead, please hide it.'); \" >
				<img src='images/dropd.gif' alt='Delete Plan' border=''0'/></a>";
            }
			else {
                $sDelete = "<a href='payment_plans.php?level_id=" . $_GET['level_id'] ."&delete=" . $row->nPaymentPlan_ID . "' OnClick=\"return cdel('" . $row->sPlanName . "');\" >
				<img src='images/drop.jpg' alt='Delete Plan' border=''0'/></a>";
            }

            //=============================================

            if ($row->nActive == '1')
                $sActive = '<input type="checkbox" name="chkExistingPlan[]" value="' . $row->nPaymentPlan_ID . '" checked>';
            else
                $sActive = '<input type="checkbox" name="chkExistingPlan[]" value="' . $row->nPaymentPlan_ID . '">';
			?>
									<tr>
										<td  align="center"><a href="javascript:openPopup('payment_plan_link.php?id=<?php echo $row->nPaymentPlan_ID ?>')" > <img src="images/chain.jpg" alt="signup links" width="18" height="18" border="0" class="iconspacing"> </a></td>
										<td ><a href="payment_plans_details.php?id=<?php echo $row->nPaymentPlan_ID ?>"><?php echo $row->sPlanName ?></a></td>
										<td  align="center"><strong><span class="green"><?php echo ($memcount - $memcountIA) ?></span>/<span class="red" ><?php echo $memcountIA?></span></strong></td>
										<td ><?php echo $row->sProcessorName ?></td>
										<td ><select name="nCoupon_ID_<?php echo $row->nPaymentPlan_ID ?>">
												<option value="NULL">Public</option>
												<?php
            $sql = "SELECT * FROM tblcoupons WHERE bActive=1 ORDER BY sCouponCode";
            $result1 = $dbo->select($sql);
            if ($result1) {
                while ($row1 = $dbo->getobj($result1)) {
                    if ($row1->nCoupon_ID == $row->nCoupon_ID) {
                        echo '<option value="' . $row1->nCoupon_ID . '" selected="selected">Coupon -' . $row1->
                            sCouponCode . '</option>';
                    } else {
                        echo '<option value="' . $row1->nCoupon_ID . '">Coupon -' . $row1->sCouponCode .
                            '</option>';
                    }
                }
            }
            ?>
											</select></td>
										<td  align="center"><?php echo $sActive ?></td>
										<td  align="center"><?php echo $sDelete ?></td>
									</tr>
									<?php 
			// Lets make sure that the payment processor is still active.
			if($row->processorStatus == '0'){?>
									<tr>
										<td colspan="7" ><div class="notify-warning"> <strong>Warning:</strong> The payment processor for this plan is inactive. <a href="payment_processors.php">Fix This</a> </div></td>
									</tr>
									<?php 
		}
		}
	}
	else{echo '<tr><td colspan="7">No Payment Plans Exist.</tr>';} 
?>
								</tbody>
							</table>
						</div>
						<input type="submit" name="update" value="Update Payment Plans" class="btn btn-primary btn-responsive">
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script language="javascript" type="text/javascript">
   	function changeLevel() {
   	   	var nLevel_ID = document.getElementById('nLevel_ID').value;
   	   	if (nLevel_ID != '') {
   	   	   	document.location.href = 'payment_plans.php?level_id=' + nLevel_ID;
   	   	}
		else{document.location.href = 'payment_plans.php';}
   	}
   		
	function cdel(w) {
		return confirm("Are you sure you want to DELETE the\n\""+w+"\" payment plan?");
}
function openPopup(page) {	
				window.open(page,'','height=150,width=700,scrollbars=no,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no');
		}

   	</script>
</body></html>