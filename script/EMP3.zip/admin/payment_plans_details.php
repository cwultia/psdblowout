<?php
	include_once '../conn.php';
	include_once '../functions.php';
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Payment Plan Details';
	$css = <<<EOT
<!--page level css -->

<!--end of page level css-->
EOT;
	
	// Get payment plan details
	if ( isset($_GET['id']) && is_numeric($_GET['id']) ) {$nPaymentPlan_ID = $dbo->format($_GET['id']);} 
	elseif ( isset($_POST['nPaymentPlan_ID']) && is_numeric($_POST['nPaymentPlan_ID']) ){$nPaymentPlan_ID = $dbo->format($_POST['nPaymentPlan_ID']);}
	else {die("Invalid ID");}

	// Update Payment Plan
	if ( isset($_GET['action']) && $_GET['action'] == 'update') {
	
		if (isset($_POST['nOneTimePayment']) && $_POST['nOneTimePayment'] == 0)
		{
		
			// Update Recurring Plan
			
			if (isset($_POST['nTrialAmount1']) && is_numeric($_POST['nTrialAmount1'])) {
				$trialamt1 = $dbo->format($_POST['nTrialAmount1']);
			} else {
				$trialamt1 = 0;
			}
				
			if (isset($_POST['nTrialAmount2']) && is_numeric($_POST['nTrialAmount2'])) {
				$trialamt2 = $dbo->format($_POST['nTrialAmount2']);
			} else {
				$trialamt2 = 0;
			}
			
			if (isset($_POST['nTrial1Period']) && is_numeric($_POST['nTrial1Period'])) {
				$trial1period = $dbo->format($_POST['nTrial1Period']);
			} else {
				$trial1period = 0;
			}
			
			if (isset($_POST['nTrial2Period']) && is_numeric($_POST['nTrial2Period'])) {
				$trial2period = $dbo->format($_POST['nTrial2Period']);
			} else {
				$trial2period = 0;
			}
			
			$sql = "UPDATE tblpaymentplans SET
			sPlanName = '" . $dbo->format($_POST['sPlanName']) . "', 
			sItemNumber = '" . $dbo->format($_POST['sItemNumber']) . "',
			nRegularAmount = " . $dbo->format($_POST['nAmount']) . ",
			nRegularPeriod = " . $dbo->format($_POST['nRegularPeriod']) . ",
			sRegularPeriod = '" . $dbo->format($_POST['sRegularPeriod']) . "', 
			nTrialAmount1 = " . $trialamt1 . ",
			nTrial1Period = " . $trial1period . ",
			sTrial1Period = '" . $dbo->format($_POST['sTrial1Period']) . "', 
			nTrialAmount2 = " . $trialamt2 . ",
			nTrial2Period = " . $trial2period . ",
			sTrial2Period = '" . $dbo->format($_POST['sTrial2Period']) . "', 
			nMembershipLevel_ID = " . $dbo->format($_POST['nLevel_ID']) . ",
			nRecurTimes = " . $dbo->format($_POST['nRecurTimes']) . ",
			nZooFunnel = '". $dbo->format($_POST['nZooFunnel']) ."' 
			WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID
			;
			
			//$dbo->update($sql);
			
		}	
		// Update One Time Only plan
		else {
		
			$sql = "UPDATE tblpaymentplans SET
			sPlanName = '" . $dbo->format($_POST['sPlanName']) . "', 
			sItemNumber = '" . $dbo->format($_POST['sItemNumber']) . "',
			nRegularAmount = " . $dbo->format($_POST['nAmount']) . ",
			nMembershipLevel_ID = " . $dbo->format($_POST['nLevel_ID']) . ",
			nRegularPeriod = '".$dbo->format($_POST['nExpirePeriod'])."',
			sRegularPeriod = '".$dbo->format($_POST['sExpirePeriod'])."',
			nZooFunnel = '". $dbo->format($_POST['nZooFunnel'])."'"./*,
			ExpirePeriod = '".$dbo->format($_POST['nExpirePeriod'])."',
			sExpirePeriod = '".$dbo->format($_POST['sExpirePeriod'])."'"
			.*/" WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID;
			//die($sql);
		}
	
		$message = ($dbo->update($sql))?
		'<div class="notify-success">
		<div class="notify-close, success-close" onClick="closeNotify(this)"></div>Payment plan has been updated successfully</div>'
		:
		'<div class="notify-error">
		<div class="notify-close, error-close" onClick="closeNotify(this)"></div>There was an error Updating the Payment Plan<br />{$dbo->error}</div>';
	}
	
	$objPaymentPlan = $dbo->getobject("SELECT * FROM tblpaymentplans WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID);
	
	$sProcessorName = $dbo->getval("SELECT sProcessorName FROM tblpaymentprocessors WHERE nPaymentProcessor_ID=" . $objPaymentPlan->nPaymentProcessor_ID);
	$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
	
	$level_name = get_level_name_by_level_id($objPaymentPlan->nMembershipLevel_ID);


	// Can We Edit This Payment Plan Safely?
	$can_edit = false;
	// Lets See If It Is Assigned To Any Active User levels.
	$sql = "SELECT COUNT(*) FROM tbluserlevels WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID." AND nActive = 1;";
	$c = $dbo->getval($sql);
	//die($sql);
	//die(var_dump($c));
	if($c == "0"){$can_edit = true;}

	// Build the Payment Schedule String.
	
	if($objPaymentPlan->nOneTimePayment){$payview = ' One Time Payment of '.$currency_symbol.number_format($objPaymentPlan->nRegularAmount,2).' '.$chkSsettings->sCurrencyFormat;}
	else{
		if($objPaymentPlan->nTrial1Period > 0){
			$currency = $currency_symbol.$objPaymentPlan->nTrialAmount1;
			if($objPaymentPlan->nTrialAmount1 == 0){$currency = 'Free';}
										 
			$payview = $currency;
			$tperiod = 
			($objPaymentPlan->nTrial1Period == '1')?' For The First '.str_replace('s','',$objPaymentPlan->sRegularPeriod):' For The First '.$objPaymentPlan->nTrial1Period.' '.$objPaymentPlan->sTrial1Period;
			
			$payview .= $tperiod.', Than ';
		} 
			
		if($objPaymentPlan->nTrial2Period > 0){
			$payview .= $currency_symbol.$objPaymentPlan->nTrialAmount2;
			$payview .= ' For The Next '.$objPaymentPlan->nTrial2Period.' '.$objPaymentPlan->sTrial2Period;
			$payview .= ', Than ';
		}
								 
		// Do Regular Payment
		$payview .= $currency_symbol.number_format($objPaymentPlan->nRegularAmount,2).' '.$chkSsettings->sCurrencyFormat;
		//$payview .= ' Every '.$objPaymentPlan->nRegularPeriod.' '.$objPaymentPlan->sRegularPeriod;
		
		// Build recur display
		//die(var_dump($objPaymentPlan->nRecurTimes));
		
		$period = ($objPaymentPlan->nRegularPeriod == '1')?' Every '.str_replace('s','',$objPaymentPlan->sRegularPeriod):' Every '.$objPaymentPlan->nRegularPeriod.' '.$objPaymentPlan->sRegularPeriod;
		if($objPaymentPlan->nRecurTimes == '1'){$recurstring .= ' As Final Payment';}
		elseif($objPaymentPlan->nRecurTimes == 0){$recurstring .=$period .', Until Cancelled';}
		else{$recurstring .= $speriod.', For '.$objPaymentPlan->nRecurTimes.' Installments';}
		$payview .= $recurstring;
	
	}

	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Payment Settings</li>
			<li><a href="payment_plans.php?level_id=<?php echo $objPaymentPlan->nMembershipLevel_ID ?>">Payment Plans</a></li>
			<li class="active">Payment Plan Details</li>
		</ol>
	</section>
	<section class="content"> <?php echo isset($message) ? $message : '' ?>
		<?php ob_start(); ?>
		<div class="col-md-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Payment Plan Details</h3>
				</div>
				<div class="panel-body">
					<table >
						<tr>
							<td class="gridrow2" width="200">Plan Name</td>
							<td class="gridrow2"><?php echo $objPaymentPlan->sPlanName ?> 
								<!--<input name="sPlanName" value="<?php echo $objPaymentPlan->sPlanName ?>" style="width: 200px;" class="required"> <small><?php echo ($objPaymentPlan->nOneTimePayment == 0) ? '(e.g. "Free 7 Day Trial then $47/Month")' : '(e.g. "$97 One Time Only")'; ?></small> --></td>
						</tr>
						<tr>
							<td class="gridrow2" width="200">Processor</td>
							<td class="gridrow2"><?php echo $sProcessorName; ?></td>
						</tr>
						<?php if($sProcessorName !=='Free') { ?>
						<tr>
							<td class="gridrow2"><?php echo $sProcessorName; ?> Product Number</td>
							<td class="gridrow2"><?php 
								($sProcessorName == 'JvZoo')
								?$prodidview = '<a href="https://www.jvzoo.com/sellers/product/'.$objPaymentPlan->sItemNumber.'" target="_blank">'.$objPaymentPlan->sItemNumber.'</a>'
								:$prodidview = ($objPaymentPlan->sItemNumber)?$objPaymentPlan->sItemNumber:'N/A';
								
								
								echo $prodidview;
								
								 ?></td>
						</tr>
						<?php if($sProcessorName == 'JvZoo'){?>
						<tr>
							<td class="gridrow2">JvZoo Funnel Id:</td>
							<td class="gridrow2"><?php echo ($objPaymentPlan->nZooFunnel > 0)?'<a href="https://www.jvzoo.com/sellers/funnel/'.$objPaymentPlan->nZooFunnel.'" target="_blank">'.$objPaymentPlan->nZooFunnel.'</a>':'None' ?></td>
						</tr>
						<?php }?>
						<tr id="paymentSchedule">
							<td class="gridrow2">Payment Schedule</td>
							<td class="gridrow2"><?php echo $payview?></td>
						</tr>
					</table>
					<?php }
                        else{ echo '</table>';} ?>
				</div>
			</div>
		</div>
		<div class="col-md-6">
		<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title"><?php echo ($sProcessorName=='Free')?'Confirmation':'Payment' ?> Success Options</h3>
				</div>
				<div class="panel-body">
			<table>
				<tr>
					<td colspan="2" class="gridrow2">Activate Access To Membership Level: <a href="member_levels.php" target="_blank"><?php echo $level_name; ?></a></td>
				</tr>
				<tr>
					<td class="gridrow2" colspan="2"><?php 
						if ($objPaymentPlan->nOneTimePayment == '1' || $sProcessorName == 'Free'){ 
							echo ($objPaymentPlan->nRegularPeriod !='0')?'Expire Access After '.$objPaymentPlan->nRegularPeriod.' '.$objPaymentPlan->sRegularPeriod:'LifeTime Membership';
						}
						else{echo 'Set To Lifetime Access At End Of Term';}
						
						?></td>
				</tr>
			</table>
			</div></div>
		</div>
		<?php if($sProcessorName !=='Free') { ?>
		<div class="col-md-6">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Payment Refund Options</h3>
				</div>
				<div class="panel-body">
			<table>
				<tr>
					<td colspan="2" class="gridrow2">Remove Access To Membership Level: <a href="member_levels.php" target="_blank"><?php echo $level_name; ?></a></td>
				</tr>
				<tr>
					<td colspan="2" class="gridrow2">Set Account Status: Keep Account Active</td>
				</tr>
			</table>
			</div></div>
		</div>
		<?php echo pluginClass::filter('payment_plan_details_form'); } ?>
		<div class="col-md-12"><a href="edit_payment_plan.php?id=<?php echo $objPaymentPlan->nPaymentPlan_ID ?>" class="btn btn-primary btn-responsive">Edit Payment Plan</a></div>

		<?php
		$paymentplanform = ob_get_clean();
		$paymentplanform = pluginClass::filter("admin_payment_plan_details",$paymentplanform);
		echo $paymentplanform;
				
		?>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">		
     
jQuery.validator.addMethod("days", function(value, element) {
	
		if(value!="")		
			if(value<=365 &&  value>=0)
				return 1;
			else 
				return 0;
		else
		 return 1;
			 
}, "&nbsp;This value must be between 0 and 365!");


     $(document).ready(function()
		{
			$("#form1").validate(
			{

				onkeyup: false				
			
			});
		});
	</script>
</body></html>