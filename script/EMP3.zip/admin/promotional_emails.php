<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Promo Email Templates';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;

	
	if ($_GET['status'] != ''){
		$sql="UPDATE tblpromoemails SET nactive='" . $dbo->format($_GET["status"]) . "' WHERE npromoemail_id='" . $dbo->format($_GET["projid"])."'";
		$dbo->update($sql);
	}
	if($_GET['act']=="d"){
		$dbo->delete("delete from tblpromoemails where npromoemail_id='" . $dbo->format($_GET["id"])."'");
		header("location:promotional_emails.php?act=dsus");
	}
	require_once('header.php');
	$sqlcs="SELECT * FROM tblpromoemails order by npromoemail_id";
	$resultcs=$dbo->select($sqlcs);
	if(!empty($resultcs))
	$n=$dbo->nr($resultcs);
	$number = $n;                // record results selected from database 
	$displayperpage="10";                // record displayed per page 
	$pageperstage="10";                // page displayed per stage 
	$allpage=ceil($number/$displayperpage);        
	$allstage=ceil($allpage/$pageperstage);        // how many page will it be ? 
	if(trim($startpage)==""){$startpage=1;} 
	if(trim($_GET['nowstage'])==""){$_GET['nowstage']=1;} 
	if(trim($_GET['nowpage'])==""){$_GET['nowpage']=$startpage;} 
	$StartRow = 0;
	if (empty($_GET['nowpage'])){
		if($StartRow == 0) $_GET['nowpage'] = $StartRow + 1;
	}
	else{
		$nowpage = $_GET['nowpage'];
		$StartRow = ($nowpage - 1) * $displayperpage;
	}
	$c=1;
	$sql="SELECT * FROM tblpromoemails ORDER BY nSortOrder LIMIT $StartRow,$displayperpage";
	$result=$dbo->select($sql);
	if(!empty($result)){
				$number=$dbo->nr($result);
				$num1=$dbo->nr($result);
			}
?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliate System</li>
      <li class="active"> Promo Email Templates</li>
    </ol>
  </section>
  <section class="content">
  <div class="col-md-12">
  <?php echo isset($message) ? $message : '' ?>
  <p class="success">
	<?php if($_GET['act']=="adsus") { echo "Promotional email has been added successfully<br><br>"; }?>
	<?php if($_GET['act']=="upsus") { echo "Promotional email has been updated successfully<br><br>"; }?>
	<?php if($_GET['act']=="dsus") { echo "Promotional email has been deleted successfully <br><br>"; }?>
</p>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"> Promotional Emails - <a href="add_promotional_emails.php"><strong>Add New</strong></a></h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
	<thead>
		<tr>
			<td class="gridheader">Title</td>
			<td class="gridheader">Sort Order</td>
			<td colspan="3" align="center" nowrap="nowrap" class="gridheader">Actions</td>
		</tr>
	</thead>
	<tbody>
		<?php
			if(!empty($result)){
			while($row=$dbo->getobj($result)){
		?>
		<tr>
			<td ><?php echo $row->sTitle ?></td>
			<td  align="center"><?php echo $row->nSortOrder ?></td>
			<td  align="center"><?php if ($row->nActive==0) { ?>
				<a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=1&projid=<?php echo $row->nPromoEmail_ID?>" class="black"> <img src="images/adult_r.gif" alt="Not Active" width="16" height="16" border="0"></a>
				<?php } else { ?>
				<a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=0&projid=<?php echo $row->nPromoEmail_ID?>" class=black> <img src="images/adult_off.gif" alt="Active" width="16" height="16" border="0"></a>
				<?php }?></td>
			<td  align="center"><a class="grid" href="edit_promotional_emails.php?act=e&amp;id=<?php echo $row->nPromoEmail_ID;?>" title="Edit Promotional email"> <img src="images/edit.gif" alt="Edit promotional email" border="0"></a></td>
			<td  align="center"><a class="grid" href="<?php echo $_SERVER['PHP_SELF']; ?>?act=d&amp;id=<?php echo $row->nPromoEmail_ID;?>" title="Delete Promotional email"  OnClick="return cdel('employer');"> <img src="images/delete.gif" alt="Delete Promotional email" border="0"></a></td>
		</tr>
		<?php }
			}
			else{
	?>
		<tr>
			<td colspan="5" ><strong>No Promotional Emails Exist! - <a href="add_promotional_emails.php"><strong>Add New</strong></a></strong></td>
		</tr>
		<?php }
?>
	</tbody>
</table>
		</div>
		</div>
		</div>
		
		
		
		
		</div>

</section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');

?>
</body></html>