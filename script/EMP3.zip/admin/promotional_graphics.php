<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Promotional Graphics';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
	
	if ($_GET['status'] != '')
	{
		$sql = "UPDATE tblpromographics SET nActive = '" . $dbo->format($_GET['status']) . "' WHERE nPromoGraphic_ID = '" . $dbo->format($_GET['projid'])."'";
		$dbo->update($sql);
	}
	
	// CODE TO UPDATE THE LOCATION OF THE BANNERS 
	
	if ( isset($_POST['fUpdate']) )
	{
		$st = $_POST['dd'];
		$disp = $_POST['disp'];
		for ($i = 0; $i < count($disp); $i++)
		{
			
			if(!$dbo->update("UPDATE tblpromographics SET nSortOrder='" . $dbo->format($disp[$i]) . "' WHERE nPromoGraphic_ID = '" . $dbo->format($st[$i])."'"))
			die($dbo->error);
	
		}
	}

	if ($_GET['act'] == 'd')
	{
		$dbo->delete("DELETE FROM tblpromographics WHERE nPromoGraphic_ID = '" . $dbo->format($_GET['id'])."'");
		// TODO: Allow for non jpeg images.
		unlink('../promotional_pic/' . $_GET['id'] . '.jpg');
		header("location:promotional_graphics.php?act=dsus");
	}
	
	require_once('header.php');

?>

<aside class="right-side">
<section class="content-header">
	<h1> <?php echo $title?> </h1>
	<ol class="breadcrumb">
		<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
		<li>Affiliate System</li>
		<li class="active"> Promo Graphics</li>
	</ol>
</section>
<section class="content">
<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
	<p class="success">
		<?php if ($_GET['act'] == 'adsus') { echo "Promotional graphic has been added successfully<br /><br />"; } ?>
		<?php if ($_GET['act'] == 'upsus') { echo "Promotional graphic has been updated successfully<br /><br />"; } ?>
		<?php if ($_GET['act'] == 'dsus') { echo "Promotional graphic has been deleted successfully<br /><br />"; } ?>
		</span>
	
	<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">Promotional Graphics - <a href="add_promotional_graphics.php?act=a"><strong>Add New</strong></a></h3>
			</div>
			<div class="panel-body">
				<div class="table-responsive"> 
					<table class="table table-striped table-bordered table-hover">
<thead>
	<tr>
		<td class="gridHeader">Promotional Graphics </td>
		<td align="center" nowrap="nowrap" class="gridHeader">Sort Order</td>
		<td colspan="3" align="center" nowrap="nowrap" class="gridHeader">Actions</td>
		</tr>
		</thead>
		<tbody>
		<?php
							$sqlcs = "SELECT * FROM tblpromographics ORDER BY nPromoGraphic_ID";
							$resultcs = $dbo->select($sqlcs);
							if(!empty($resultcs))
							$n = $dbo->nr($resultcs);
							$number = $n; // record results selected from database 
							$displayperpage = "10"; // record displayed per page 
							$pageperstage = "10"; // page displayed per stage
							$allpage = ceil($number / $displayperpage);
							$allstage = ceil($allpage / $pageperstage); // how many page will it be ? 
							if (trim($startpage) == '') { $startpage = 1; } 
							if (trim($_GET['nowstage']) == '') { $_GET['nowstage'] = 1; }
							if (trim($_GET['nowpage']) == '') { $_GET['nowpage'] = $startpage; }
							$StartRow = 0;
							if ( empty($_GET['nowpage']) )
							{
								if ($StartRow == 0)
								{
									$_GET['nowpage'] = $StartRow + 1;
								}
							}
							else
							{
								$nowpage = $_GET['nowpage'];
								$StartRow = ($nowpage - 1) * $displayperpage;
							}
							$c = 1;
							$sql = "SELECT * FROM tblpromographics ORDER BY nPromoGraphic_ID LIMIT $StartRow,$displayperpage";
							$result = $dbo->select($sql);
							
							// Dont Know What this is.
							// Causing missing record.
							/*if(!empty($result)){
								$obj = $dbo->getobj($result);
								
								$number = $dbo->nr($result);
								$num1 = $dbo->nr($result);
							}*/
							if(!empty($result)){
								while ($row = $dbo->getobj($result)){?>
	<tr>
		<td class="gridRow1" width="100%"><img src="../promotional_pic/<?php echo $row->nPromoGraphic_ID; ?>.jpg" /></td>
		<td class="gridActions1" align="center"><span class="blue">
			<input name="disp[]" type="text" class="box" size="3" value="<?php echo $row->nSortOrder; ?>" />
			<input type="hidden" name="dd[]" value="<?php echo $row->nPromoGraphic_ID; ?>" />
			</span></td>
		<td class="gridActions1" align="center"><?php 
										$link0 = '<a href="'.$_SERVER['PHP_SELF'].'?status=1&projid='.$row->nPromoGraphic_ID.'" class="black"><img src="images/adult_r.gif" alt="Not Active" width="16" height="16" border="0" /></a>';
										$link1 = '<a href="'.$_SERVER['PHP_SELF'].'?status=0&projid='.$row->nPromoGraphic_ID.'" class="black"><img src="images/adult_off.gif" alt="Active" width="16" height="16" border="0" /></a>';
										
										echo ($row->nActive == 0)?$link0 :$link1 ?></td>
		<td class="gridActions1" align="center"><a class="grid" href="edit_promotional_graphics.php?act=e&amp;id=<?php echo $row->nPromoGraphic_ID; ?>" title="Edit Graphic"><img src="images/edit.gif" alt="Edit Graphic" border="0"></a></td>
		<td class="gridActions1" align="center"><a class="grid" href="<?php echo $_SERVER['PHP_SELF']; ?>?act=d&amp;id=<?php echo $row->nPromoGraphic_ID; ?>" title="Delete Graphic" OnClick="return cdel('employer');"> <img src="images/delete.gif" alt="Delete Graphic" border="0"></a></td>
	</tr>
	<?php 
								}
							}
							else{ ?>
	<tr>
		<td colspan="5" class="gridrow2">No Promotional Graphics Added Yet - <a href="add_promotional_graphics.php?act=a"><strong>Add New</strong></a></td>
	</tr>
	<?php } ?>
	</tbody>
</table>
				</div>
			</div>
			<input type="submit" name="fUpdate" value="Save Changes" class="btn btn-primary btn-responsive" />
		</div>
	</form>
</div>
</section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');

?>
<script type="text/javascript">
			function cdel(w)
			{
				if ( confirm("Are you sure that you want to delete this promotional graphic?") )
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		</script>
</body>
</html>
