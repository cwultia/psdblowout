<?php
	include_once( "../conn.php" );
	include_once( "../functions.php" );

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Top 25 Affiliates';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;
require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Reports</li>
      <li class="active">Top 25 Affiliates</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Top 25 Affiliates</h3>
        </div>
        <div class="panel-body"> <strong>Please note:</strong> This chart displays paid and unpaid affiliate commissions.
          <div id="chooseyear"> <strong>Choose Year</strong>:
            <select id="nYear" onChange="changeYear();">
              <?php
	$i = 0;
	// Why Only 5 Year Span Below? Should Start With Date Of First Record, and end at last... Duh? - $i < 5
	while ( $i < 5 ){
    $year = date( "Y" ) - $i;
    $selected = $year == $_GET['y'] ? "selected" : "";
    ?>
              <option value="<?php echo $year?>" <?php echo $selected ?>><?php echo $year ?></option>
              <?php 
	++$i;}
	?>
            </select>
          </div>
          <div align="center" id="admin_chart_affiliates" ></div>
        </div>
      </div>
      
      <!-- Breakdown -->
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Top 25 Breakdown</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>No. of Sales</th>
                  <th>Commissions</th>
                </tr>
              </thead>
              <tbody>
                <?php
	$year = isset( $_GET['y'] ) ? $_GET['y'] : date( "Y" );
	$curSymbol = get_currency_symbol( $chkSsettings->sCurrencyFormat );
	$sql = "SELECT 
         A.sForename AS sAffForename,
         A.sSurname AS sAffSurname,
         A.sEmail,
         COUNT(AP.nAffiliate_ID) AS nSales,
         SUM(AP.nCommission) AS nCommissionTotal
       FROM tblaffiliatepayments AP
       INNER JOIN tblusers A ON A.nUser_ID = AP.nAffiliate_ID
       WHERE NOT AP.sPaymentStatus = 'Refund' AND YEAR(nTimeStamp) = '{$year}'
       GROUP BY AP.nAffiliate_ID
       ORDER BY nCommissionTotal DESC
       LIMIT 25";
	  
$result = $dbo->select( $sql );
if ( $result )
{
    $i = 1;
	$totalSales = 0;
	
    while ( $row = $dbo->getarray( $result ) )
    {
        ?>
                <tr>
                  <td >#<?php echo $i ?></td>
                  <td ><?php echo $row['sAffForename']." ".$row['sAffSurname']?></td>
                  <td ><?php echo $row['sEmail']?></td>
                  <td ><?php echo $row['nSales']?></td>
                  <td ><?php echo $curSymbol.number_format( $row['nCommissionTotal'], 2 )?></td>
                </tr>
                <?php
        $totalNoOfSales = $totalNoOfSales + $row['nSales'];
        $totalSales = $totalSales + (int)$row['nCommissionTotal'];
        ++$i;
    }
   
    ?>
                <tr>
                  <td ><strong>Totals</strong></td>
                  <td ><strong></strong></td>
                  <td ><strong></strong></td>
                  <td ><strong><?php echo $totalNoOfSales ?></strong></td>
                  <td ><strong><?php echo $curSymbol.number_format( $totalSales, 2 )?></strong></td>
                </tr>
                <?php }else{ ?>
                <tr>
                  <td colspan="5"  align="center">No data to display</td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript" src="../js/swfobject.js"></script> 
<script type="text/javascript">
   swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_affiliates", "900", "200", "9.0.0", "expressInstall.swf", 
   {"data-file":"report_affiliates_top_data.php?y=<?php echo isset( $_GET['y'] ) ? $_GET['y'] : date( "Y" )?>"} );
  </script> 
<script language="javascript">
  function changeYear() {
   var dropdown = document.getElementById('nYear');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_affiliates_top.php?y=' + ddVal;
  }
  </script>
<style>
   #note {
    margin-top: 5px;
    margin-bottom: 20px;
    font-size: 10px;
   }
   #note span {
    background-color: #FFC;
    padding: 5px;
   }
  </style>
</body></html>