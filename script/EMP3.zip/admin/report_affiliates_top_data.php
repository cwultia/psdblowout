<?php

include( "common/php/ofc/open-flash-chart.php" );
include_once( "../conn.php" );
include_once( "../functions.php" );
if ( isset( $_GET['y'] ) && is_numeric( $_GET['y'] ) && strlen( $_GET['y'] ) == 4 )
{
    $year = $_GET['y'];
}
else
{
    $year = date( "Y" );
}
$sql = "
 SELECT 
   A.sForename AS sAffForename,
   A.sSurname AS sAffSurname,
   A.sEmail,
   COUNT(AP.nAffiliate_ID) AS nSales,
   SUM(AP.nCommission) AS nCommissionTotal
 FROM tblaffiliatepayments AP
 INNER JOIN tblusers A ON A.nUser_ID = AP.nAffiliate_ID
 WHERE NOT AP.sPaymentStatus = 'Refund' AND YEAR(nTimeStamp) = '{$year}'
 GROUP BY AP.nAffiliate_ID
 ORDER BY nCommissionTotal DESC
 LIMIT 25
";

$result = $dbo->select( $sql );
if ( $result )
{
    while ( $row = $dbo->getarray( $result ) )
    {
        $affName[] = $row['sAffForename']." ".$row['sAffSurname'];
        $affIncome[] = ( integer )$row['nCommissionTotal'];
    }
    $maxY = max( $affIncome );
}


$chart = new open_flash_chart( );
$title = new title( "Top 25 Affiliates In ".date( "Y", mktime( 0, 0, 0, 1, 1, $year ) ) );
$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );
$chart->set_title( $title );
$bar = new bar_glass( );
$bar->colour( "#009933" );
$bar->set_values( $affIncome );
$bar->set_tooltip( $curSymbol."#val#" );
$chart->add_element( $bar );
$x_labels = new x_axis_labels( );
$x_labels->set_labels( $affName );
$x = new x_axis( );
$x->set_colours( "#666666", "#cccccc" );
$x->set_labels( $x_labels );
$chart->set_x_axis( $x );
$y = new y_axis( );
$y->set_colours( "#666666", "#cccccc" );
$y->set_label_text( $curSymbol."#val#" );
$y->set_range( 0, 0 < $maxY ? $maxY : null, 1000 < $maxY ? 1000 : 100 );
$chart->set_y_axis( $y );
$chart->set_bg_colour( "ffffff" );
echo $chart->toPrettyString( );
?>
