<?php

	include_once( "../conn.php" );
	include_once( "../functions.php" );
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Report: Members By Level';
	$css = <<<EOT
<!--page level css -->


<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;
require_once('header.php');
	?>
<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
      <ol class="breadcrumb">
      <li><a href="home.php"><i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a></li>
      <li>Reports</li>
      <li class="active">Top 25 Affiliates</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Members By Level</h3>
        </div>
        <div class="panel-body">
          <?php
	if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "active" ){
    	$selectedActive = "selected";
    	$selectedAll = "";
    	$sqlWhere = " WHERE ML.nActive=1";
	}
	else if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "all" ){
    	$selectedActive = "";
    	$selectedAll = "selected";
    	$sqlWhere = "";
	}
	else{$sqlWhere = " WHERE ML.nActive=1";}
?>
          <div class="row">
            <form>
              <select id="nDropdownID" onChange="changeDropdown();">
                <option value="active" <?php echo $selectedActive; ?>>Show Active Levels Only </option>
                <option value="all" <?php echo $selectedAll;?>>Show All Levels</option>
              </select>
            </form>
          </div>
           <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
            <tr>
              <th>Level</th>
              <th>Active Members</th>
              <th>Cancelled Members</th>
            </tr>
            </thead>
            <tbody>
            <?php
	$sql = "SELECT ML.nLevel_ID,ML.sLevel,
	IFNULL(Active.nMembers,0) AS nActiveMembers,
         IFNULL(Cancelled.nMembers,0) AS nCancelledMembers
       FROM tblmembershiplevels ML
       LEFT JOIN
       (
       SELECT 
         L.nLevel_ID,
         sLevel,
         COUNT(UL.nLevel_ID) AS nMembers
       FROM tblmembershiplevels L
       LEFT JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
       WHERE UL.nDateCancelled = 0
       GROUP BY UL.nLevel_ID
       ) AS Active ON Active.sLevel = ML.sLevel
       LEFT JOIN (

       SELECT 
         sLevel,
         COUNT(UL.nLevel_ID) AS nMembers
       FROM tblmembershiplevels L
       LEFT JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
       WHERE UL.nDateCancelled > 0 
       GROUP BY UL.nLevel_ID

       ) AS Cancelled
       ON Cancelled.sLevel = Active.sLevel
       ".$sqlWhere."
       ORDER BY sLevel";
$result = $dbo->select( $sql );
if ( $result ){
    while($row = $dbo->getarray( $result )){
            ?>
            <tr>
              <td ><?php echo $row['sLevel']?></td>
              <td><?php echo $row['nActiveMembers']?></td>
              <td><?php echo $row['nCancelledMembers']?></td>
            </tr>
            <?php
            $totalActiveMembers = $totalActiveMembers + $row['nActiveMembers'];
            $totalCancelledMembers = $totalCancelledMembers + $row['nCancelledMembers'];
            $sql = "
         SELECT
           PP.sPlanName,
           PR.sProcessorName,
           IFNULL(Active.nCount,0) AS nActiveCount,
           IFNULL(Cancelled.nCount,0) AS nCancelledCount,
           IFNULL(nTotalCount,0) AS nTotalCount
         FROM tblpaymentplans PP
         LEFT JOIN
         (
         SELECT
           PP.nPaymentPlan_ID,
           sPlanName,
           COUNT(UL.nPaymentPlan_ID) AS nCount
         FROM tblpaymentplans PP
         INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
         INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
         WHERE UL.nLevel_ID = ".$row['nLevel_ID']." AND UL.nDateCancelled = 0
         GROUP BY UL.nPaymentPlan_ID
         ) AS Active ON Active.nPaymentPlan_ID = PP.nPaymentPlan_ID
         LEFT JOIN (
         SELECT
           PP.nPaymentPlan_ID,
           sPlanName,
           COUNT(UL.nPaymentPlan_ID) AS nCount
         FROM tblpaymentplans PP
         INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
         INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
         WHERE UL.nLevel_ID = ".$row['nLevel_ID']." AND UL.nDateCancelled > 0
         GROUP BY UL.nPaymentPlan_ID
         ) AS Cancelled ON Cancelled.nPaymentPlan_ID = PP.nPaymentPlan_ID
         LEFT JOIN (
         SELECT
           PP.nPaymentPlan_ID,
           sPlanName,
           COUNT(UL.nPaymentPlan_ID) AS nTotalCount
         FROM tblpaymentplans PP
         INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
         INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
         WHERE UL.nLevel_ID = ".$row['nLevel_ID']."
         ) AS Total ON Total.nPaymentPlan_ID
         INNER JOIN tblpaymentprocessors PR
         ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
         WHERE (NOT Active.nCount IS NULL OR NOT Cancelled.nCount IS NULL)
         ORDER BY nActiveCount DESC, sProcessorName
        ";
            $result1 = $dbo->select( $sql );
			if($result1){
				while($row1 = $dbo->getarray( $result1 )){
					?>
            <tr>
              <td >&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row1['sPlanName']." (".$row1['sProcessorName'].")" ?></td>
              <td><?php echo $row1['nActiveCount']?></td>
              <td><?php echo $row1['nCancelledCount']?></td>
            </tr>
            <?php
					}
				}
           ?>
            <?php }
	?>
            <tr>
              <td ><strong>Totals</strong></td>
              <td><strong><?php echo $totalActiveMembers ?></strong></td>
              <td><strong><?php echo $totalCancelledMembers ?></strong></td>
            </tr>
            <?php }
else{ ?>
            <tr>
              <td colspan="5"  align="center">No data to display</td>
            </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript" >
  function changeDropdown() {
   var dropdown = document.getElementById('nDropdownID');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_members_level.php?cmd=' + ddVal;}
  </script>
<style>
   .small1 {
    font-size: 11px; 
    margin-left: 20px; 
    color: grey;
   }
  </style>
</body></html>