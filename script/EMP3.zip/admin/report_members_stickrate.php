<?php

include_once( "../conn.php" );
include_once( "../functions.php" );
$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Report: Member Stick Rate';
	$css = <<<EOT
<!--page level css -->



<!--end of page level css-->
EOT;
require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li><a href="home.php"><i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a></li>
      <li>Reports</li>
      <li class="active">Member Stick Rate</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Member Stick Rate By Level</h3>
        </div>
        <div class="panel-body"> <strong>Please note:</strong> The report below shows only levels that have <strong>recurring</strong> payment plans.
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Level</th>
                  <th>Average Months Members Remain Active</th>
                </tr>
              </thead>
              <tbody>
                <?php
$sql = "
       SELECT 
         sLevel,
         sPlanName,
         sProcessorName,
         ROUND(AVG(nDaysJoined)/30,2) AS nAverageMonths,
         ROUND(MAX(nDaysJoined)/30,2) AS nMaxMonths,
         ROUND(MIN(nDaysJoined)/30,2) AS nMinMonths
       FROM (
       SELECT
         PP.nMembershipLevel_ID,
         PR.sProcessorName,
         PP.nPaymentPlan_ID,
         sPlanName,
         DATEDIFF(DATE(IF(UL.nDateCancelled>0, UL.nDateCancelled, CURDATE())), DATE(U.nJoinDate)) AS nDaysJoined
       FROM tblpaymentplans PP
       INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
       INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
       INNER JOIN tblpaymentprocessors PR ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
       WHERE (UL.nDateCancelled > 0 AND UL.nDateCancelled > 19000101) 
       OR (UL.nDateCancelled = 0)
       AND PP.nOneTimePayment = 0
       ) AS tbl1
       INNER JOIN tblmembershiplevels ML
       ON ML.nLevel_ID = tbl1.nMembershipLevel_ID
       GROUP BY nPaymentPlan_ID
       ORDER BY nMembershipLevel_ID";
	   
$result = $dbo->select( $sql );
if ( $result ){
    while ( $row = $dbo->getarray( $result ) )
    {
        if ( $level != $row['sLevel'] )
        {
            ?>
                <tr>
                  <td ><?php echo $row['sLevel']?></td>
                  <td  align="right">&nbsp;</td>
                </tr>
                <?php 
            $level = $row['sLevel'];}
        ?>
                <tr>
                  <td ><?php echo $row['sPlanName'];?> ( <?php echo $row['sProcessorName'];?> )</td>
                  <td  align="right"><?php echo $row['nAverageMonths']?> months <em>(max: <?php echo $row['nMaxMonths']?> months, min: <?php echo $row['nMinMonths']?> months)</em></td>
                </tr>
                <?php }
	
	}
else{?>
                <tr>
                  <td colspan="5"  align="center">No data to display</td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script language="javascript">
  function changeDropdown() {
   var dropdown = document.getElementById('nDropdownID');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_members_level.php?cmd=' + ddVal;
  }
  </script>
</body></html>