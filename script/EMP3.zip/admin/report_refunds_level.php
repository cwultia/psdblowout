<?php

	include_once( "../conn.php" );
	include_once( "../functions.php" );
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Report: Refunds by level';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;
require_once('header.php');
	?>
   <aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li><a href="home.php"><i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a></li>
      <li>Reports</li>
      <li class="active">Refunds By Level</li>
    </ol>
  </section>
  <section class="content">
  <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Member Stick Rate By Level</h3>
        </div>
        <div class="panel-body">

     
<?php
	if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "active" ){
		$selectedActive = "selected";
		$selectedAll = "";
		$sqlWhere = " AND L.nActive=1";
	}
	else if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "all" ){
		$selectedActive = "";
		$selectedAll = "selected";
		$sqlWhere = "";
	}
	else{$sqlWhere = " AND L.nActive=1";}
?>     
     <div class="row">
      <form>
<select id="nDropdownID" onChange="changeDropdown();">
<option value="active" <?php $selectedActive; ?>>Show Active Levels Only</option>
        <option value="all" <?php echo $selectedAll ?>>Show All Levels</option>
       </select>
      </form>      
     </div>
     <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
      <tr>
       <th>Level</th>
       <th>Refunds</th>
       <th>Refund %</th>
      </tr>
      </thead>
      <tbody>
      <?php
$sql = "
       SELECT 
         Sales.sLevel,
         Sales.sPlanName,
         Sales.sProcessor,
         nSales,
         IFNULL(nRefunds,0) AS nRefunds
       FROM
       (
       SELECT 
         PP.nPaymentPlan_ID,
         sLevel,
         COUNT(UL.nLevel_ID) AS nSales,
         sPlanName,
         sProcessor
       FROM tblmembershiplevels L
       INNER JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tbltransactions T ON T.sTransactionNumber = UL.sTransactionNumber
       INNER JOIN tblpaymentplans PP ON PP.nPaymentPlan_ID = UL.nPaymentPlan_ID
       INNER JOIN tblpaymentprocessors PR ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
       WHERE T.nTransactionType_ID = 1 ".$sqlWhere."
       GROUP BY PP.nPaymentPlan_ID
       ) AS Sales 
       LEFT JOIN (
       SELECT 
         PP.nPaymentPlan_ID,
         sLevel,
         COUNT(UL.nLevel_ID) AS nRefunds,
         sPlanName,
         sProcessor
       FROM tblmembershiplevels L
       INNER JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tbltransactions T ON T.sTransactionNumber = UL.sTransactionNumber
       INNER JOIN tblpaymentplans PP ON PP.nPaymentPlan_ID = UL.nPaymentPlan_ID
       INNER JOIN tblpaymentprocessors PR ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
       WHERE T.nTransactionType_ID = 2 ".$sqlWhere."
       GROUP BY PP.nPaymentPlan_ID
       ) AS Refunds ON Sales.nPaymentPlan_ID = Refunds.nPaymentPlan_ID
       ORDER BY Sales.sLevel, nRefunds DESC
      ";
$result = $dbo->select( $sql );
if ( $result )
{
    while ( $row = $dbo->getarray( $result ) )
    {
        if ( $row['sLevel'] != $level )
        {
            ?>
        <tr>
         <td ><?php echo $row['sLevel'] ?></td>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
        </tr><?php
            $level = $row['sLevel'];
        }
        ?>
        <tr>
         <td><?php echo $row['sPlanName']?></td>
         <td><?php echo $row['nRefunds'] ?></td>
         <td><?php echo number_format( $row['nRefunds'] / $row['nSales'] * 100, 1 )?>%</td>
        </tr>
		<?php
    }
}
?><tr><td colspan="3"  align="center">No data to display</td></tr>
</tbody>
</table>
</div></div></div></div>
</section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script language="javascript">
  function changeDropdown() {
   var dropdown = document.getElementById('nDropdownID');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_refunds_level.php?cmd=' + ddVal;
  }
  </script>
</body>
</html>