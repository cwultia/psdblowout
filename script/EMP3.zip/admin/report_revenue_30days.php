<?php
	include_once( "../conn.php" );
	include_once( "../functions.php" );
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Report: 30 Day Revenue';
	$css = <<<EOT
<!--page level css -->


<!--end of page level css-->
EOT;
	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li><a href="home.php"><i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a></li>
      <li>Reports</li>
      <li class="active">30 Day Revenue Report</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">Member Stick Rate By Level</h3>
        </div>
        <div class="panel-body">
          <div align="center" id="chart" ></div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript" src="../js/swfobject.js"></script> 
<script type="text/javascript">
   swfobject.embedSWF("common/open-flash-chart.swf", "chart", "900", "300", "9.0.0", "expressInstall.swf", {"data-file":"report_revenue_30days_data.php"} );
  </script>
</body></html>