<?php

include( "common/php/ofc/open-flash-chart.php" );
include_once( "../conn.php" );
include_once( "../functions.php" );
if ( isset( $_GET['y'] ) && is_numeric( $_GET['y'] ) && strlen( $_GET['y'] ) == 4 )
{
    $year = $_GET['y'];
}
else
{
    $year = date( "Y" );
}
$sql = "
 SELECT 
   Sales.sMonth, 
   ROUND(IFNULL(Sales.nSales,0),2) AS nSales, 
   IFNULL(nNoOfSales,0) AS nNoOfSales,
   ROUND(IFNULL(Refunds.nRefunds,0),2) AS nRefunds,
   IFNULL(nNoOfRefunds,0) AS nNoOfRefunds,
   ROUND(IFNULL(AffiliatePayments.nAffiliateAmount,0),2) AS nAffiliateAmount,
   IFNULL(nNoOfAffPayments, 0) AS nNoOfAffPayments,
   ROUND((IFNULL(nSales,0) + IFNULL(nRefunds,0)) - IFNULL(nAffiliateAmount,0),2) As nNetIncome
 FROM
 (
 SELECT 
   MONTH(dDateTime) AS sMonth, 
   SUM(nSaleAmount) AS nSales,
   COUNT(nTransaction_ID) AS nNoOfSales
 FROM tbltransactions
 WHERE 
   YEAR(dDateTime) = '{$year}' 
   AND nTransactionType_ID = 1
 GROUP BY sMonth
 ) AS Sales 
 LEFT JOIN
 (
 SELECT 
   MONTH(dDateTime) AS sMonth, 
   SUM(nSaleAmount) AS nRefunds,
   COUNT(nTransaction_ID) AS nNoOfRefunds
 FROM tbltransactions
 WHERE 
   YEAR(dDateTime) = '{$year}' 
   AND nTransactionType_ID = 2
 GROUP BY sMonth
 ) AS Refunds ON Refunds.sMonth = Sales.sMonth
 LEFT JOIN (
 SELECT 
   MONTH(nTimeStamp) AS sMonth, 
   SUM(nCommission) AS nAffiliateAmount,
   COUNT(nAffiliatePayment_ID) AS nNoOfAffPayments
 FROM tblaffiliatepayments
 WHERE 
   YEAR(nTimeStamp) = '{$year}' 
 GROUP BY sMonth
 ) AS AffiliatePayments ON AffiliatePayments.sMonth = Refunds.sMonth
";
$result = $dbo->select( $sql );
$chartArrayData = array( "Jan" => 0, "Feb" => 0, "Mar" => 0, "Apr" => 0, "May" => 0, "Jun" => 0, "Jul" => 0, "Aug" => 0, "Sep" => 0, "Oct" => 0, "Nov" => 0, "Dec" => 0 );
if ( $result )
{
    while ( $row = $dbo->getarray( $result ) )
    {
        $chartArrayData[date( "M", mktime( 0, 0, 0, $row['sMonth'], 1, $year ) )] = ( integer )$row['nNetIncome'];
        $netIncome[] = ( integer )$row['nNetIncome'];
    }
    $maxY = max( $netIncome );
}
else
{
    $months[] = null;
    $netIncome[] = null;
}
$curSymbol = get_currency_symbol( $chkSsettings->sCurrencyFormat );
$chart = new open_flash_chart( );
$title = new title( "Revenue By Month In ".date( "Y", mktime( 0, 0, 0, 1, 1, $year ) ) );
$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );
$chart->set_title( $title );
$bar = new bar_glass( );
$bar->colour( "#009933" );
foreach ( $chartArrayData as $key => $val )
{
    $netIncome2[] = $val;
}
$bar->set_values( $netIncome2 );
$bar->set_tooltip( $curSymbol."#val#" );
$chart->add_element( $bar );
$x_labels = new x_axis_labels( );
foreach ( $chartArrayData as $key => $val )
{
    $months2[] = $key;
}
$x_labels->set_labels( $months2 );
$x = new x_axis( );
$x->set_colours( "#666666", "#cccccc" );
$x->set_labels( $x_labels );
$chart->set_x_axis( $x );
$y = new y_axis( );
$y->set_colours( "#666666", "#cccccc" );
$y->set_label_text( $curSymbol."#val#" );
$y->set_range( 0, 0 < $maxY ? $maxY : null, 1000 < $maxY ? 1000 : 100 );
$chart->set_y_axis( $y );
$chart->set_bg_colour( "ffffff" );
echo $chart->toPrettyString( );
?>
