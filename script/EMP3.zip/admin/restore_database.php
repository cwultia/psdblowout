<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Restore Database Backups';
	$css = <<<EOT
<!--page level css -->


<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;
	
	if (isset($_POST['Restore'])) {
		if (isset($_POST['backupfile'])) {
			// Unzip file first
			$command = "gzip -d dump/".$_POST['backupfile'];
			$unzipped = basename($_POST['backupfile'], ".gz");			
			system($command, $result);
			if ($result == 0) {
				// Restore Backup
				$command = "mysql -u $db_username --password='$db_password' $db_name < dump/$unzipped";
				system($command, $return);
				if ($return == 1) $error = "restore";
				// Rezip File
				$command = "gzip dump/$unzipped";
				system($command, $return);
				if ($return == 1) $error = "zip";
				$message = "<p class='success'>Database restored successfully.</p>";
			}
		} else {
			$message = "<p class='error'>Please select a backup file to restore from</p>";			
		}			
	}
	function getBackupList() {
		$list = '';
		if ($handle = opendir('dump')) {
		    while (false !== ($file = readdir($handle))) {
		        if ($file != "." && $file != ".." && substr($file, strrpos($file,'.')+1) == 'gz') {
		            $list[] = $file;
		        }
		    }
		    closedir($handle);
		}
		@arsort($list);
		return $list;
	}
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			 <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a> </li>
      <li>Database</li>
      <li class="active">Restore Database</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form method="post" action="restore_database.php">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Database Management System</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<?php
								// Get the list of all tables from the database '$dbName'
								$back = getBackupList();	
								$cells = 4;	// Cells across (need to change cell width accordingly)
								if (!empty($back)) {	
									$i = 0;								
									foreach ($back as $item) {
										if ($i++ % $cells == 0) {
											if ($i == 1) 	echo "<tr>";
											else echo "</tr><tr>";
										}
										$display = explode('_',$item);
										$checked = ($item == $_POST['backupfile']) ? 'checked' : '';
										echo sprintf("<td><input type='radio' name='backupfile' value='%s' id='%s' %s style='margin-bottom:0px; margin-right:5px'><label for='%s'>%s</label></td>", $item, $item, $checked, $item, date('Y-m-d H:i(s) A',$display[3]));
									}	
									// Fill in missing table cells								 
									$start = ($i - intval($i / $cells) * $cells);
									if ($start > 0)
										for ($j = $start + 1; $j < $cells+1; $j++) echo "<td class='gridRow1'>&nbsp;</td>";
											echo "</tr>";									
								}
								else {
									echo "<tr><td>No Backups Found.</td></tr>";
								}
								?>
							</table>
							<input type="submit" name="Restore" value="Restore" class="btn btn-primary btn-responsive">
							<div> Remember, you can have a daily database backup emailed to you automatically if required.Just <a href="script_settings.php">click here</a> and tick the "Daily Backup" checkbox. </div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</body></html>