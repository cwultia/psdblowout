<?php
	include_once('../conn.php');
	include_once('../functions.php');
	include_once('../includes/functions-time.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'General Site Settings';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;
	
	$objTemplateOptions = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".TEMPLATEFOLDER."'");
	// To Do - Validate No Spam Fields.
	if ( isset($_POST['Update']) ){
		$c = 0;
		if (!isValidEmail ($_POST['sPaypalEmail']) && $_POST['sPaypalEmail'] != '') {
			$c++;
			$pem = 1;
		}
		
	
		if (!regex_filter(trim($_POST["sSiteURL"]),"^https?:\/\/^")) {
			$c++;
			$su = 1;
		}
		if (!$_POST["sRootPath"] ||$_POST["sRootPath"] == '' ) {
			$c++;
			$rp = 1;
		}
		else{
			$path = rtrim($dbo->format($_POST['sRootPath'],'/'));
			if(substr($path, -1) == '/') {$path = substr($path, 0, -1);}
			if(!is_file($path.'/conn_data.php')){
				$c++;
				$ivrp = 1;
				}
			}
			
		if($_POST['security_timeout'] == ''){$_POST['security_timeout'] = '20';}
		elseif($_POST['security_timeout'] < '5'){$_POST['security_timeout'] = '5';}
		
		if ($c == 0) {
			if(!is_numeric($_POST['nCookieExpiry'])){$_POST['nCookieExpiry'] = 90;}
			if(!is_numeric($_POST['nMaxDiffIpPerDay'])){$_POST['nMaxDiffIpPerDay'] = 3;}
			$sSiteURL = trim($_POST['sSiteURL'], '/');
			$sSiteURL = $dbo->format($sSiteURL);
			$sql = "UPDATE tblsitesettings SET 
			ssitename='".$dbo->format($_POST['sSitename'])."',
			sSiteOwner = '".$dbo->format($_POST['sSiteOwner'])."',  
			ssiteurl='$sSiteURL', 
			ndateformat='".$dbo->format($_POST['nDateFormat'])."', 
			scurrencyformat='".$dbo->format($_POST['sCurrencyFormat'])."', 
			ssiteowner='".$dbo->format($_POST['sSiteOwner'])."', 
			nOneTimeOffer='".$dbo->format($_POST['nOneTimeOffer'])."',
			sEMPAffiliateLink='".$dbo->format($_POST['sEMPAffiliateLink'])."',
			nDisplaySupportForm='" . $dbo->format($_POST['nDisplaySupportForm']) . "',
			HTTPPostURL='" . $dbo->format($_POST['HTTPPostURL']) . "',
			nMaxDiffIpPerDay='" . $dbo->format($_POST['nMaxDiffIpPerDay']) . "',
			sRootPath='".$dbo->format($path)."'";
						
			// Add Recaptcha Options - MDP - 3-10-12
			// Human Verification Moved To Options Table.
			update_option('nospam',$dbo->format($_POST['nospam']));
			update_option('ayah_pubkey',$dbo->format($_POST['ayah_pubkey']));
			update_option('ayah_scorekey',$dbo->format($_POST['ayah_scorekey']));
			update_option('recaptcha_public',$dbo->format($_POST['recaptcha_public']));
			update_option('recaptcha_private',$dbo->format($_POST['recaptcha_private']));
			
			update_option('security_timeout',$dbo->format($_POST['security_timeout']));
			//die(var_dump($_POST['session_timeout_active']));
			update_option('session_timeout_active',$dbo->format($_POST['session_timeout_active']));
			
			// Lang Settings ...
			// This will update ALL template folders with this language.
			$selected_language = $_POST['sLanguageFile'];
			$current_language = $objTemplateOptions->sLanguageFile;
			if($selected_language != $current_language){
				$dbo->update("Update tbltemplatesettings SET sLanguageFile = '$selected_language' WHERE 1");
			}
			
			
			// Automation Settings
			$auto_backup = ($_POST['auto_backup'] == '1')?'1':'0';
			$auto_backup_attach = ($_POST['auto_backup_attach'] == '1')?'1':'0';
			
			$auto_process_expired = ($_POST['auto_process_expired'] == '1')?'1':'0';
			$exclude_recurring_auto_process_expired = ($_POST['auto_process_expired'] == '1')?'1':'0';
			$auto_process_cancelled = ($_POST['auto_process_cancelled'] == '1')?'1':'0';
			
			$auto_user_cancel = ($_POST['auto_user_cancel'] == '1')?'1':'0';
			
			// BUG FIX - MAKE SURE ALL OPTIONS ARE IN DATABASE
			
			
			if(!is_option('auto_backup')) add_option('auto_backup','0');
			if(!is_option('auto_backup_attach')) add_option('auto_backup_attach','0');
			if(!is_option('auto_process_expired')) add_option('auto_process_expired','0');
			if(!is_option('exclude_recurring_auto_process_expired')) add_option('exclude_recurring_auto_process_expired','0');
			if(!is_option('auto_process_cancelled')) add_option('auto_process_cancelled','0');
			if(!is_option('auto_user_cancel')) add_option('auto_user_cancel','0');
			if(!is_option('timezone')) add_option('timezone',$dbo->format($_POST['timezone']));
			else{update_option('timezone',$dbo->format($_POST['timezone']));}
			
			
			if($auto_backup != get_option('auto_backup')){update_option('auto_backup',$auto_backup);}
			if($auto_backup_attach != get_option('auto_backup_attach')){update_option('auto_backup_attach',$auto_backup_attach);}
			if($auto_process_expired != get_option('auto_process_expired')){update_option('auto_process_expired',$auto_process_expired);}
			if($exclude_recurring_auto_process_expired != get_option('exclude_recurring_auto_process_expired')){update_option('exclude_recurring_auto_process_expired',$exclude_recurring_auto_process_expired);}
			if($auto_process_cancelled != get_option('auto_process_cancelled')){update_option('auto_process_cancelled',$auto_process_cancelled);}
			if($auto_user_cancel != get_option('auto_user_cancel')){update_option('auto_user_cancel',$auto_user_cancel);}
			
			$objTemplateOptions = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".TEMPLATEFOLDER."'");
			
			if(!$dbo->update($sql)){$message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>'.$dbo->error."</div>";}
			else{$message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>Site settings have been updated successfully</div>';}
			
		} 
		else {$message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>Please fix the errors on the form and resubmit</div>';}
		}
	$rw = $dbo->getobject("SELECT * FROM tblsitesettings");

	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>General Settings</li>
			<li class="active">Site Settings</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <?php if( isset($message)) echo $message ?>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">Site Information</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover">
                <tr>
                  <th>Website Name <font style="color:red"> * </font></th>
                  <td width="1028" ><input name="sSitename" type="text" style="width: 350px;" value="<?php echo $rw->sSiteName; ?>" class="required" /></td>
                </tr>
                <tr>
                  <th>Site Owner Name <font style="color:red"> * </font></th>
                  <td  ><input name="sSiteOwner" type="text" style="width: 350px;" value="<?php echo $rw->sSiteOwner; ?>"  class="required"/></td>
                </tr>
                <tr>
                  <th>Easy Member Pro URL<font style="color:red"> *</font></th>
                  <td ><input name="sSiteURL" type="text" style="width: 350px;" value="<?php echo $rw->sSiteURL; ?>" class="url required" />
                    <?php if ($su == 1) { ?>
                    <span class="red">Invalid Url. Please prefix http://</span>
                    <?php } ?></td>
                </tr>
                <tr>
                  <th>Easy Member Pro Path<font style="color:red"> *</font></th>
                  <td  ><input name="sRootPath" type="text" style="width: 350px;" value="<?php echo $rw->sRootPath; ?>"  class="required"/>
                    <?php if ($rp == 1) { ?>
                    <span class="red">You must enter a path.</span>
                    <?php }elseif($ivrp == 1){?>
                    <span class="red">Invalid Path</span>
                    <?php } ?></td>
                </tr>
                <tr>
                  <th>Email Notification Information </th>
                  <td>Moved to <a href="email_settings.php">Email Settings</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">General Settings</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover">
                <tr>
                  <th> Language</th>
                  <td ><select name="sLanguageFile" style="width: 200px;">
                      <?php 
								// Iterate through available language files in the /languages folder and choose English as default
								$current_language = $objTemplateOptions->sLanguageFile;
								$dirname = "../languages";
								$dir = opendir($dirname);
								$files = array();
								while ($file = readdir($dir)) {
									if ( ($file != ".") && ($file != "..") ) {
										$shortfile = ucfirst(str_replace(".php", "", $file));
										$files[] = $shortfile;
									}
								}
								closedir($dir);
								
								sort($files, SORT_STRING);// Sort alphabetically
								
								foreach ($files as $fileitem) {
									$selectedfile = ($current_language == $fileitem) ? "selected" : "";
									echo "<option value='" . $fileitem . "' " . $selectedfile . ">" . $fileitem . "</option>\n";
								}
								?>
                    </select></td>
                </tr>
                <tr>
                  <th>Date Format</th>
                  <td  ><select name="nDateFormat">
                      <option value="">Select</option>
                      <option value="1" <?php if ($rw->nDateFormat == '1') { echo 'selected="true"'; } ?>>mm/dd/yyyy</option>
                      <option value="2" <?php if ($rw->nDateFormat == '2') { echo 'selected="true"'; } ?>>dd/mm/yyyy</option>
                      <option value="3" <?php if ($rw->nDateFormat == '3') { echo 'selected="true"'; } ?>>mm-dd-yyyy</option>
                      <option value="4" <?php if ($rw->nDateFormat == '4') { echo 'selected="true"'; } ?>>dd-mm-yyyy</option>
                    </select></td>
                </tr>
                <tr>
                  <th>Time Zone</th>
                  <td  ><?php echo getTimeZoneSelect((get_option('timezone'))?get_option('timezone'):date_default_timezone_get(),'timezone') ?></td>
                </tr>
                <tr>
                  <th>Currency Type </th>
                  <td  ><select name="sCurrencyFormat">
                      <option value="USD" selected <?php if ($rw->sCurrencyFormat == 'USD') { echo 'selected="true"'; } ?>>U.S. Dollars</option>
                      <option value="AUD" <?php if ($rw->sCurrencyFormat == 'AUD') { echo 'selected="true"'; } ?>>Australian Dollars</option>
                      <option value="BRL" <?php if ($rw->sCurrencyFormat == 'BRL') { echo 'selected="true"'; } ?>>Brazilian Real</option>
                      <option value="CAD" <?php if ($rw->sCurrencyFormat == 'CAD') { echo 'selected="true"'; } ?>>Canadian Dollars</option>
                      <option value="CZK" <?php if ($rw->sCurrencyFormat == 'CZK') { echo 'selected="true"'; } ?>>Czech Koruna</option>
                      <option value="DKK" <?php if ($rw->sCurrencyFormat == 'DKK') { echo 'selected="true"'; } ?>>Danish Kroner</option>
                      <option value="EUR" <?php if ($rw->sCurrencyFormat == 'EUR') { echo 'selected="true"'; } ?>>Euros</option>
                      <option value="HKD" <?php if ($rw->sCurrencyFormat == 'HKD') { echo 'selected="true"'; } ?>>Hong Kong Dollars</option>
                      <option value="HUF" <?php if ($rw->sCurrencyFormat == 'HUF') { echo 'selected="true"'; } ?>>Hungarian Forint</option>
                      <option value="MYR" <?php if ($rw->sCurrencyFormat == 'MYR') { echo 'selected="true"'; } ?>>Malaysian Ringgit </option>
                      <option value="NZD" <?php if ($rw->sCurrencyFormat == 'NZD') { echo 'selected="true"'; } ?>>New Zealand Dollars</option>
                      <option value="NOK" <?php if ($rw->sCurrencyFormat == 'NOK') { echo 'selected="true"'; } ?>>Norwegian Kroner</option>
                      <option value="PHP" <?php if ($rw->sCurrencyFormat == 'PHP') { echo 'selected="true"'; } ?>>Philippines Peso</option>
                      <option value="PLN" <?php if ($rw->sCurrencyFormat == 'PLN') { echo 'selected="true"'; } ?>>Polish Zlotych</option>
                      <option value="GBP" <?php if ($rw->sCurrencyFormat == 'GBP') { echo 'selected="true"'; } ?>>Pounds Sterling</option>
                      <option value="SGD" <?php if ($rw->sCurrencyFormat == 'SGD') { echo 'selected="true"'; } ?>>Singapore Dollars</option>
                      <option value="SEK" <?php if ($rw->sCurrencyFormat == 'SEK') { echo 'selected="true"'; } ?>>Swedish Kronor</option>
                      <option value="CHF" <?php if ($rw->sCurrencyFormat == 'CHF') { echo 'selected="true"'; } ?>>Swiss Francs</option>
                      <option value="JPY" <?php if ($rw->sCurrencyFormat == 'JPY') { echo 'selected="true"'; } ?>>Yen</option>
                    </select></td>
                </tr>
                <tr>
                  <th>Display One Time Offer Page</th>
                  <td ><?php if($_POST['nOneTimeOffer'] == 1 || $rw->nOneTimeOffer == 1){$nOneTimeOffer_checked =  "checked='checked'";} ?>
                    <input  <?php echo $nOneTimeOffer_checked ?> id="nOneTimeOffer" name="nOneTimeOffer" type="checkbox" value="1" /></td>
                </tr>
                <!-- ====== ======== added selective display of contact form ====== == -->
                <tr>
                  <th>Display Contact Form</th>
                  <td  ><?php 	if($_POST['nDisplaySupportForm'] == 1 || $rw->nDisplaySupportForm == 1){ 
												$nDisplaySupportForm_checked =  "checked='checked'";
											} 
										?>
                    <input  <?php echo $nDisplaySupportForm_checked?> id="nDisplaySupportForm" name="nDisplaySupportForm" type="checkbox" value="1" /></td>
                </tr>
                <!-- ====== ======== ======================================= ====== == -->
                <tr>
                  <th>Easy Member Pro Affiliate Link</th>
                  <td ><input type="text" name="sEMPAffiliateLink" value="<?php echo $rw->sEMPAffiliateLink ?>" style="width: 350px;">
                    - Used If Displaying The Powered By Link.</td>
                </tr>
                <tr>
                  <th>HTTP Post URL</th>
                  <td><input type="text" name="HTTPPostURL" value="<?php echo $rw->HTTPPostURL ?>" style="width: 350px;">
                    (Advanced Users) - Will Send Notifications to an External Url.</td>
                </tr>
                <!-- TERMS OF SERVICE --> 
                <!--	<tr>
									<td colspan="2" class="gridheader">Terms of Service </td>
								</tr>
								<tr>
									<td  >Include Terms of Service during Sign-up</td>
									<td  ><input type="checkbox" name="nTOS" value="1" <?php // if ($rw->nTOS == '1') { echo 'checked="true"'; } ?> /></td>
								</tr>
								<tr>
									<td   colspan="2">
                              <?php // if ($ts == 1):  ?>
                               	<span class="red">Please enter your Terms of Service</span>
                               <?php // endif; ?>
                               <textarea name="sTOS" value="" cols="80" rows="10"><?php //=$rw->sTOS ?></textarea>
									</td>
								</tr>    -->
              </table>
            </div>
          </div>
        </div>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">Security Settings</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover">
                <!-- 
                                Disabled feature - Max Ips - 4-1-12
								<tr>
									<td  width="240">Max different IP addresses per user per day</td>
									<td ><input name="nMaxDiffIpPerDay" type="text" style="width: 50px;" value="<?php echo $rw->nMaxDiffIpPerDay; ?>" class="required" />
									<?php /* if ($err_ip == 1) {*/ ?>
									  <span class="red">Please enter a number between 1 and 99</span>
									  <?php /* } */ ?>
									</td>
								</tr>
                                -->
                <tr>
                  <?php 	
								  
								  $recapdisplay = 'none';
								  $ayahdisplay = 'none';
								  
								  if($_POST['nospam'] == 'recaptcha' || get_option('nospam') == 'recaptcha'){ 
												$recapchecked =  "checked='checked'";
												$recapdisplay = 'block';
									}
									elseif($_POST['nospam'] == 'ayah' || get_option('nospam') == 'ayah'){ 
												$ayahchecked =  "checked='checked'";
												$ayahdisplay = 'block';
									}
									else{$nonechecked =  "checked='checked'";}
										?>
                  <th>Anti Spam Control</th>
                  <td ><p>
                      <label>
                        <input type="radio" name="nospam" value="0" id="nospam_0" <?php echo $nonechecked ?>onChange="toggleNoSpam(this)">
                        Do Not Use</label>
                      <br>
                      <label>
                        <input type="radio" name="nospam" value="recaptcha" id="nospam_1" <?php echo $recapchecked ?>onChange="toggleNoSpam(this)">
                        Use <a href="http://www.google.com/recaptcha" target="_blank">reCAPTCHA</a></label>
                      - reCaptcha is used as a free Anti-Spam / Human Verification service.<br>
                      <label> <span style="margin-left:40px; display:<?php echo $recapdisplay ?>" id="sRecaptchaKeys"> <br>
                        If you do have this information, you can obtain it from here. <a href="http://www.google.com/recaptcha" target="_blank">reCAPTCHA Website</a><br>
                        Public Key<font style="color:red"> *</font>
                        <input name="recaptcha_public" type="text" id="recaptcha_public" value="<?php echo get_option('recaptcha_public') ?>" size="50">
                        <br>
                        Private Key<font style="color:red"> *</font>
                        <input name="recaptcha_private" type="text" id="recaptcha_private" value="<?php echo  get_option('recaptcha_private') ?>" size="50">
                        </span></label>
                      <label>
                        <input type="radio" name="nospam" value="ayah" id="nospam_2" <?php echo $ayahchecked ?> onChange="toggleNoSpam(this)">
                        Use <a href="http://portal.areyouahuman.com/dashboard">Are You A Human</a></label>
                      <span style="margin-left:40px; display:<?php echo $ayahdisplay ?>" id="sAyahKeys"><br>
                      Publisher Key<font style="color:red"> *</font>
                      <input name="ayah_pubkey" type="text" id="ayah_pubkey" value="<?php echo  get_option('ayah_pubkey'); ?>" size="50">
                      <br>
                      Scoring Key<font style="color:red"> *</font>
                      <input name="ayah_scorekey" type="text" id="ayah_scorekey" value="<?php echo get_option('ayah_scorekey'); ?>" size="50">
                      </span> </p></td>
                </tr>
                <tr>
                  <th>Session Timeout</th>
                  <td ><?php 
						$sto = get_option('session_timeout_active');
						if($sto == '1'){$checked0 = 'checked="checked"';$checked1 = '';}
						else{$checked1 = 'checked="checked"';$checked0 = '';}
					 ?>
                    <label>
                      <input type="radio" name="session_timeout_active" value="1" id="RadioGroup1_0" <?php echo $checked0 ?>>
                      On</label>
                    <label>
                      <input type="radio" name="session_timeout_active" value="0" id="RadioGroup1_1" <?php echo $checked1 ?>>
                      Off<br>
                    </label>
                    Inactive after
                    <input name="security_timeout" type="text" id="security_timeout"  value="<?php echo get_option('security_timeout'); ?>" size="4" maxlength="2">
                    Minutes (min:5, max:99)</td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">Automation Settings</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover">
                <tr>
                  <th>Run Daily Backup?</th>
                  <td  ><input type="checkbox" name="auto_backup" value="1" <?php if (get_option('auto_backup') == '1') { echo 'checked="true"'; }?>  onChange="showBackupOptions(this,'backup_email')" />
                    <span id="backup_email" style="display:<?php echo (get_option('auto_backup') == '1')?'inline':'none'; ?>">Attach Backup To Daily Cron Email?
                    <input name="auto_backup_attach" type="checkbox" id="auto_backup_attach" value="1" <?php if (get_option('auto_backup_attach') == '1') { echo 'checked="true"'; }?> >
                    </span></td>
                </tr>
                <tr>
                  <th>Auto Process Expired Memberships?</th>
                  <td  ><input name="auto_process_expired" type="checkbox" id="auto_process_expired" value="1" <?php if (get_option('auto_process_expired') == '1') { echo 'checked="true"'; }?>>
                    - Exclude Recuring Subscriptions?
                    <input name="exclude_recurring_auto_process_expired" type="checkbox" id="exclude_recurring_auto_process_expired" value="1" <?php if (get_option('exclude_recurring_auto_process_expired') == '1') { echo 'checked="true"'; }?>>
                    <label for="exclude_recurring_auto_process_expired"></label></td>
                </tr>
                <tr>
                  <th>Auto Process Cancelled Memberships?</th>
                  <td  ><input name="auto_process_cancelled" type="checkbox" id="auto_process_cancelled" value="1" <?php if (get_option('auto_process_cancelled') == '1') { echo 'checked="true"'; }?>></td>
                </tr>
                <tr>
                  <th>Allow Auto Cancellation from User?</th>
                  <td ><input name="auto_user_cancel" type="checkbox" id="auto_user_cancel" value="1" <?php if (get_option('auto_user_cancel') == '1') { echo 'checked="true"'; }?>>
                    - If unchecked admin must process all cancellation requests.</td>
                </tr>
                <!--								
								<tr>
									<td  >Log SQL Queries</td>
									<td  >
										<input type="checkbox" name="nLogQueries" value="1" <?php if ($rw->nLogQueries == '1') { echo 'checked="true"'; }?> />
										<span style="color:navy">All SQL queries will be saved and can be reviewed. <a href="query_log.php" style="color:red">View saved queries</a> </span>
									</td>
								</tr>
								 -->
              </table>
              <input type="submit" name="Update" value="Save Changes" class="btn btn-primary btn-responsive" />
            </div>
          </div>
        </div>
      </form>
    </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">
        function toggle(id){
			var ele = document.getElementById(id).style.display;
			if(ele == 'none'){document.getElementById(id).style.display = 'block'}
			else{document.getElementById(id).style.display = 'none';}
			}
		function toggleNoSpam(ele){
			//alert(ele.value);
			rc = document.getElementById('sRecaptchaKeys');
			ay = document.getElementById('sAyahKeys');
			if(ele.value =='recaptcha'){
				rc.style.display = 'block';
				ay.style.display = 'none';
			}
			else if(ele.value =='ayah'){
				rc.style.display = 'none';
				ay.style.display = 'block';
			}
			else{
				rc.style.display = 'none';
				ay.style.display = 'none';
			}
		
		}
		function showBackupOptions(ele,show){
			box = document.getElementById(show);
			if(ele.checked){box.style.display = 'inline';}
			else{box.style.display = 'none';}
			
			}
        </script> 
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
</body></html>