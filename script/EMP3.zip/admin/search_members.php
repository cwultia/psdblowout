<?php
include_once('../conn.php');
include_once('../functions.php');
?>
<html>
<head>
	<title><?php echo $admintitle; ?></title>
	<?php include("inc-head.php"); ?>
	<script language=javascript>
	function checkthis()
	{
		if(document.f1.search1.value=="")
		{
			alert("Please enter a first name, last name or email address");
			document.f1.search1.focus();
			return false;
		}
	}
	</script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
	<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        <?php include_once('memberleft.php'); ?>      </td>
	<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
	
	<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
		<tr>
		<td width="6%" nowrap="nowrap" class="navRow1"><span class="navRow2">Search members </span></td>
		<td width="94%" align="left" class="navRow2">&nbsp;</td>
		</tr>
	</table>                

	<form name="f1" method="get" action="manage_members.php" onSubmit="return checkthis()">
	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr><td class="gridHeader" colspan="2">Search Members</td></tr>
	<tr>
		<td class="gridLabels1" nowrap="nowrap" width="120"> Search for <span class="REQUIRED"><font color="Red"> *</font></span></td>
		<td class="gridRow1">
			<input type='hidden' name='qry' value='search'>
		<input class="inputText" name="srchval" style="width: 300px;" size="40" maxlength="255" value="<?php echo $_POST[search1]?>" type="text"><span style="padding-left:10px">First name, Last name or Email</span>
		<div style="margin-top:3px; font-size:8pt; color:navy">(search for &ldquo;joe&rdquo; &mdash; will find any member with a first name, lastname or email beginning with joe)</div>
		</td>
	</tr>
	<tr>
		<td class="gridFooter">&nbsp;</td>
		<td class="gridFooter"><input class="inputSubmit" name="submit" value="Search" type="submit"></td>
	</tr>
	
	</table>
	</form>
	
	</td>
</tr>
<tr><td style="padding-left: 8px; padding-right: 8px; " valign="top" width="100%"><br></td></tr>
</table>

<?php include_once('b.php'); ?>

</body>
</html>