<?php
	include_once('../conn.php');
	include_once('../functions.php');

	$userid = $_GET['userid'];

	$sql = "SELECT * FROM tblusers WHERE nUser_ID = '". $dbo->format($userid)."'";
	$rs = $dbo->select($sql);
	
	if ($dbo->nr($rs) > 0) {
		$user = $dbo->getobj($rs);

		$sql = "SELECT * FROM  tblemailtemplates WHERE sType = 'MEMBER_PASSWORD_REMINDER'";
		$rs1 = $dbo->select($sql);
		$emailMsg = $dbo->getassoc($rs1);
		
		$emailMsg['sBody'] = str_replace("[[FIRSTNAME]]", $user->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[EMAIL]]", $user->sEmail, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[PASSWORD]]", $user->sPassword, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[OWNER]]", $adminname, $emailMsg['sBody']);

		//EMAIL
		email ($user->sEmail, $sSitename, $supportemail, $emailMsg['sSubject'], nl2br(stripslashes($emailMsg['sBody'])));

		$msg = "msg";
	} else
		$msg = "err";
		
	/*echo "<script language='javascript'>";
	echo "top.document.getElementById('msgResend').innerHTML = '$msg';";
	echo 
	echo "</script>";*/
		
?>
<script type="text/javascript">
window.parent.showResendMsg('<?php echo $msg ?>');
</script>