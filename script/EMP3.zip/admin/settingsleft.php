<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
	<tr><td class="sideHeader">&nbsp;General Settings</td></tr>
	<tr><td class="sideRow"><img src="images/icon_email.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="autoresponder_settings.php">Autoresponders</a></td></tr>
	<tr><td class="sideRow"><img src="images/icon_email.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="email_templates.php">Email Templates</a></td></tr>
	<tr><td class="sideRow"><img src="images/icon_settings.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="script_settings.php">Site Settings</a></td></tr>
	<tr><td class="sideRow"><img src="images/icon_member.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="user_fields.php">User Fields</a></td></tr>
</table>

<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
	<tr><td class="sideHeader">&nbsp;Payment Settings</td></tr>
	<tr><td class="sideRow"><img src="images/icon-coupon.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="coupons.php">Coupons</a></td></tr>

	<tr><td class="sideRow"><img src="images/dollor.gif" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="payment_plans.php?action=reset">Payment Plans</a></td></tr>
	<tr><td class="sideRow"><img src="images/dollor.gif" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="payment_processors.php">Payment Processors</a></td></tr>
</table>

<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
	<tr><td class="sideHeader">&nbsp;Template Settings</td></tr>
	<tr><td class="sideRow"><img src="images/icon_settings.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="template_setup.php">Template Setup</a></td></tr>
</table>

<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
	<tr><td class="sideHeader">&nbsp;Affiliate System</td></tr>
	<tr><td class="sideRow"><img src="images/icon-coupon.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="affiliate_management.php">Affiliate Settings</a></td></tr>
</table>

<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
	<tr><td class="sideHeader">&nbsp;Testing &amp; Tracking (SEO)</td></tr>
	<tr><td class="sideRow"><img src="images/icon_seo.png" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a class="opt" href="testing_tracking.php">Settings</a></td></tr>
</table>