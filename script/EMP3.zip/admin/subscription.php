
<TABLE cellSpacing=0 cellPadding=0 width="75%" align=center border=0>

<TR>
<TD width="100%" colSpan=2 align=middle vAlign=top class=redhead><strong>Subscription Type  </strong></TD>
</TR>
<TR>
<TD vAlign=top colSpan=2>&nbsp;</TD></TR>
<TR>
<TD vAlign=top colSpan=2>Please select any one of the subscription type you are interested. </TD>
</TR>

<TR>
<TD vAlign=top colSpan=2><FORM name=forms action=index.php?page=payment method=post onsubmit="checkForm(this)">
  <table class="border" cellspacing="0" cellpadding="5" width="60%" align="left" bgcolor="#ffffff" border="0">
    
      <tr valign="top">
        <td width="9%" height="8" align="middle" valign="center" class="black1">&nbsp;</td>
        <td width="91%" height="8" align="middle" valign="center" class="black1"></td>
      </tr>
      <tr class="gridTable">
        <td class="gridRow1"><input type="radio" name="stype" value="<?php echo $rwp->month; ?>" />
        </td>
        <td class="gridRow1"> $<?php echo $rwp->month; ?>  &nbsp;- &nbsp;Monthly </td>
      </tr>
      <tr class="gridTable">
        <td class="gridRow1"><input  type="radio"  name="stype" value="<?php echo $rwp->month3; ?>">
        </td>
        <td class="gridRow1"> $<?php echo $rwp->month3; ?> &nbsp;- &nbsp;3 Months </td>
      </tr>
      <tr valign="top">
        <td align="middle" valign="center" class="bodytxt"><input  type="radio"  name="stype" value="<?php echo $rwp->month6; ?>" /></td>
        <td class="gridRow1">$<?php echo $rwp->month6; ?> &nbsp;- &nbsp;6 Months </td>
      </tr>
      <tr valign="top">
        <td align="middle" valign="center" class="bodytxt"><input  type="radio"  name="stype" value="<?php echo $rwp->month12; ?>" />
        </td>
        <td class="gridRow1">$<?php echo $rwp->month12; ?> &nbsp;- &nbsp;12 Months </td>
      </tr>
      <tr valign="top">
        <td align="middle" valign="center" class="bodytxt"><input  type="radio"  name="stype" value="<?php echo $rwp->onetime; ?>" />
        </td>
        <td width="91%" class="gridRow1">$<?php echo $rwp->onetime; ?> &nbsp;- &nbsp;1 Time Only 
          <input type="hidden" name="dd"  value="<?php echo $_POST['ptype']; ?>"/></td>
      </tr>
      <tr valign="top">
        <td colspan="2" align="middle" valign="center" class="bodytxt"><input class="button" type="submit" value="Continue Payment" name="Submit"  onclick= "return checkForm()" /></td>
      </tr>
    
  </table>
</form>
</TD></TR>


<TR>
<TD vAlign=top colSpan=2>&nbsp;</TD></TR></TABLE>
