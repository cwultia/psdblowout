<?php
include_once('../conn.php');
include_once('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Search Engine Optimization Settings';
	$css = <<<EOT
<!--page level css -->



<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

	if ( isset($_POST['Submit']) ){
		// Update current SEO settings
		$dbo->update("UPDATE tblsitesettings SET 
			sMetaTags = '" . addslashes($_POST['metatags']) . "', 
			sGoogleAnalytics = '" . addslashes($_POST['googleanalytics']) . "', 
			sGoogleWebmaster = '" . addslashes($_POST['googlewebmaster']) . "'
			");
		$message = "SEO settings have been updated successfully";
	}
	
	$objSiteSettings = $dbo->getobject("SELECT * FROM tblsitesettings");
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i>Home</a> </li>
      		<li>Testing/Tracking</li>
      <li class="active">SEO Options</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
			<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">SEO Options</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<td>Meta Tags:</td>
									<td ><textarea name="metatags" cols="80" rows="4" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sMetaTags)?></textarea>
										<br />
										<small>e.g: <?php echo htmlspecialchars('<meta name="description" content="your content here">');?></small></td>
								</tr>
								<tr>
									<td>Google Analytics:</td>
									<td ><p>Sign up <a href="http://www.google.com/analytics/sign_up.html" target="_blank">HERE</a> &amp; paste the supplied code into the box below</p>
										<textarea name="googleanalytics" cols="80" rows="10" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sGoogleAnalytics)?></textarea></td>
								</tr>
								<tr>
									<td>Google Webmaster Tools:</td>
									<td ><p>Sign up <a href="http://www.google.com/webmasters/tools/" target="_blank">HERE</a> &amp; paste the supplied code into the box below</p>
										<textarea name="googlewebmaster" cols="80" rows="4" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sGoogleWebmaster)?></textarea>
										<p><small>e.g. <?php echo htmlspecialchars('<meta name="google-site-verification" content="Czh1XM4Gq5dt6xEY9prSagznXfhy18tGnMJgAg11eRI" />'); ?></small></p></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<input type="submit" name="Submit" value="Save Changes"  class="btn btn-primary btn-responsive">
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</body></html>