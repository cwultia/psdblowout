<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
  <td class="sideHeader">&nbsp;Admin Logs</td></tr>
<tr>
  <td class="sideRow"><img src="images/th.jpg" alt="" align="absmiddle" border="" />&nbsp;<a class="opt" href="admin_logins.php">Admin Logins</a></td></tr>
<!--<tr>
  <td class="sideRow"><img src="images/th.jpg" alt="" align="absmiddle" border="" />&nbsp;<a class="opt" href="admin_activity.php">Admin Activity</a></td></tr> -->
<tr>
  <td class="sideRow"><img src="images/pay.jpg" alt="" width="16" height="16" border="" align="absmiddle" /> <a href="manage_transactions.php">Transaction Log</a></td> 
  Trans</tr>
</table>

<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
<tr>
  <td class="sideHeader">&nbsp;Admin Reports </td></tr>
<tr>
  <td class="sideRow"><img src="images/pay.jpg" alt="" width="16" height="16" border="" align="absmiddle">&nbsp;<a href="unpaid_commissions.php">Unpaid Commissions</a></td></tr>
</table>
<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="sideHeader">&nbsp;Admin Tools</td>
  </tr>
  <tr>
    <td class="sideRow">&nbsp;</td>
  </tr>
  <tr>
    <td class="sideRow">&nbsp;</td>
  </tr>
  <tr>
    <td class="sideRow">&nbsp;</td>
  </tr>
  <tr>
    <td class="sideRow">&nbsp;</td>
  </tr>
  <tr>
    <td class="sideRow">&nbsp;</td>
  </tr>
</table>
