<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Unpaid Commissions';
	$css = <<<EOT
<!--page level css -->


<!--end of page level css-->
EOT;
	
	$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
	$startmonth = date('Ym01');
	$nextmonth = date('Ymd', strtotime('+1 month', strtotime($startmonth)));
	
	// Run The Commissions Query.
	$sql = "SELECT CONCAT(tblusers.sForename, ' ',tblusers.sSurname) AS name, 
	tblaffiliatepayments.nAffiliate_ID, 
	tblusers.sPaypalEmail AS sPaypalEmail,
	SUM(tblaffiliatepayments.nCommission) AS amount, 
	COUNT(nAffiliatePayment_ID) AS cnt 
	FROM tblaffiliatepayments 
	INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
	WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
	GROUP BY tblaffiliatepayments.nAffiliate_ID 
	ORDER BY amount, name";				
	
	$tot_cnt = 0;
	$tot_amt = 0;
			
	$rs = $dbo->select($sql); // Hold The Result For Processing Later

	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliates</li>
      <li class="active">Unpaid Commissions</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div class="row"> <a href="unpaid_commissions_add.php"><img src="images/Add_24x24.png" width="24" height="24" alt="Add New Commission" border="0" style="vertical-align: middle"></a> <a href="unpaid_commissions_add.php">Add New Commission</a> </div>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Unpaid Commissions</h3>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>Affiliate Name </th>
                  <th>Payable Subscriptions </th>
                  <th>Paypal Email</th>
                  <th>Owed</th>
                  <th>View Details</th>
                </tr>
              </thead>
              <tbody>
                <?php
			if ($rs!==false) {
				while ($row = $dbo->getobj($rs)) { ?>
                <tr>
                  <td ><?php echo $row->name ?></td>
                  <!-- Subscription Count -->
                  <td><?php echo $row->cnt ?></td>
                  <!-- Paypal Email -->
                  <td><?php echo (empty($row->sPaypalEmail))? '<span style="color:red">Not Entered</span>' : $row->sPaypalEmail ?></td>
                  <!-- Projected Payments -->
                  <td><?php echo $currency_symbol.number_format($row->amount,2); ?></td>
                  <!-- View Details -->
                  <td><a href='unpaid_commissions_details.php?id=<?php echo $row->nAffiliate_ID ?>'>View</a></td>
                </tr>
                <?php
                    $tot_cnt += $row->cnt;
					$tot_amt += $row->amount;			
				}			
				// Totals
				?>
                <tr>
                  <td>Total</td>
                  <td><b><?php echo $tot_cnt ?></b></td>
                  <td ></td>
                  <td><b><?php echo $currency_symbol.number_format($tot_amt,2); ?></b></td>
                  <td >&nbsp;</td>
                </tr>
                <?php
			}
			else { ?>
                <tr>
                  <td colspan='5'  ><strong>No Unpaid Commissions</strong></td>
                </tr>
                <?php		}
		?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</body></html>