<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add New Unpaid Commissions';
	$css = <<<EOT
<!--page level css -->

<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

	if(isset($_POST['Add']))
	{
		$sql="SELECT sEmail,sForename,sSurname from tblusers where nUser_ID='".$dbo->format($_POST['suggestionsmHidden'])."'";
		$rs=$dbo->select($sql);
		if(!empty($rs))
		{
			$row = $dbo->getobj($rs);
			$memberEmail = $row->sEmail;
			$sForename = $row->sForename;
			$sSurname = $row->sSurname;
		}
		
		$sItemName = $dbo->format($_POST['sItemName']);
		
		$sql="INSERT INTO tblaffiliatepayments (
			nCommission, 
			nDate, 
			nDatePaid, 
			sPaymentStatus, 
			nAffiliate_ID, 
			sUserForename, 
			sUserSurname, 
			sUserEmail, 
			nMemberJoinDate, 
			sItemName, 
			sTransactionNumber
		) VALUES (
			'".$dbo->format($_POST['nCommission'])."',
			'". date('Ymd') ."',
			'0',
			'',
			'".$dbo->format($_POST['suggestionsHidden'])."',
			'".$sForename."',
			'".$sSurname."',
			'".$memberEmail."',
			'".$_POST['nMemberJoinYear'].$_POST['nMemberJoinMonth'].$_POST['nMemberJoinDay']."',
			'".$sItemName."',
			'".$dbo->format($_POST['nTransactionNumber']) . "'
		)";
	
		if($dbo->insert($sql)){
			$message = 'The new commission was added.';
			$type = 'msg';
			
			}
		else{$message = 'There was an error adding the commission:<br />'.$dbo->error;
			$type = 'err';}
		
		header("Location: unpaid_commissions_add.php?".$type."=".$message);exit;
		}
	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliates</li>
      <li><a href="unpaid_commissions.php">Unpaid Commissions</a></li>
      <li class="active">Add New</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
    <?php echo isset($message) ? $message : '' ?>
    <div class="panel panel-primary">
    <div class="panel-heading">
      <h3 class="panel-title"> Add New Commissions</h3>
    </div>
    <div class="panel-body">
    <div class="table-responsive">
      <form name="fAddCommission" action="unpaid_commissions_add.php?action=add" method="post" id="form">
        <table class="table table-striped table-bordered table-hover">
            <tr>
              <th align="left">Affiliate <font color="Red"> *</font></th>
              <td><div>
                  <div>
                    <input id="aff" name="aff" onKeyUp="lookup(this.value,'aff.php','#suggestions','#autoSuggestionsList');" type="text"  class="required" />
                    <input type="hidden" id="suggestionsHidden" name="suggestionsHidden" />
                  </div>
                  <div class="suggestionsBox" id="suggestions" style="display: none;"> <img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />
                    <div class="suggestionList" id="autoSuggestionsList"></div>
                  </div>
                </div></td>
            </tr>
            <tr>
              <th align="left">Member <font color="Red"> *</font></th>
              <td ><div>
                  <div>
                    <input id="mem" name="mem" onKeyUp="lookup(this.value,'mem.php','#suggestionsm','#autoSuggestionsListm');" type="text"  class="required" />
                    <input type="hidden" id="suggestionsmHidden" name="suggestionsmHidden" />
                  </div>
                  <div class="suggestionsBox" id="suggestionsm" style="display: none;"> <img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />
                    <div class="suggestionList" id="autoSuggestionsListm"></div>
                  </div>
                </div></td>
            </tr>
            <tr>
              <th align="left">Join/Renewal Date <font color="Red"> *</font></th>
              <td><select name="nMemberJoinDay">
                  <?php
			for ($i=1; $i<=31; $i++) {
				echo '<option value="' .sprintf("%02d", $i) . '">' .  sprintf("%02d", $i) . '</option>';
			}
		?>
                </select>
                <select name="nMemberJoinMonth">
                  <?php
			for ($i=1; $i<=12; $i++) {
				echo '<option value="' .sprintf("%02d", $i) . '">' . date('M',mktime(0,0,0,$i,1,2000)) . '</option>';
			}
		?>
                </select>
                <select name="nMemberJoinYear">
                  <?php
			for ($i=0; $i<5; $i++) {
				echo '<option value="' . date('Y',mktime(0,0,0,1,1,date('Y')-$i)) . '">' . date('Y',mktime(0,0,0,1,1,date('Y')-$i)) . '</option>';
			}
		?>
                </select></td>
            </tr>
            <tr>
              <th align="left">Commission Amount <font color="Red"> *</font></th>
              <td ><input type="text" name="nCommission"  class="number required"></td>
            </tr>
            <tr>
              <th align="left">Transaction Number <font color="Red"> *</font></th>
              <td ><input type="text" name="nTransactionNumber"  class="required"></td>
            </tr>
            <tr>
              <th align="left">Level Name <font color="Red"> *</font></th>
              <td ><?php 
		$sql="SELECT sLevel FROM tblmembershiplevels ORDER BY sLevel ";
		
		$rs=$dbo->select($sql);
		?>
                <select name="sItemName" class="form-control select2">
                  <?php if(!empty($rs))
		while($row=$dbo->getobj($rs))
			echo "<option value='".$row->sLevel."'>".$row->sLevel."</option>";
				
	?>
                </select></td>
            </tr>
            <tr align="left">
              <td colspan="2"><input type="submit" value="Add" name="Add" class="btn btn-primary btn-responsive"></td>
            </tr>
        </table>
      </form>
    </div></div></div></div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">

	function lookup(inputString,file,suggestions,autosuggestionlist) {
		if(inputString.length == 0) {
			// Hide the suggestion box.
			$(suggestions).hide();
			
		} else {
			$.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$(suggestions).show();
					$(autosuggestionlist).html(data);
				}
			});
		}
	} // lookup
	
	function fill(thisValue,id,suggestions,thisValueId) {
		$(id).val(thisValue);
		$(suggestions+'Hidden').val(thisValueId);
		$(suggestions).hide();
	}


</script>
<style type="text/css">

.suggestionsBox {
    position: absolute;
    left: 400px;
    margin: 10px 0px 0px 0px;
    width: 250px;
    background-color: #212427;
    -moz-border-radius: 7px;
    -webkit-border-radius: 7px;
    border: 2px solid #000;
    color: #fff;
}

.suggestionList {
    margin: 0px;
    padding: 5px;
}

.suggestionList li {
    margin: 0px 0px 5px 0px;
    padding: 3px;
    cursor: pointer;
}

.suggestionList li:hover {
    background-color: #659CD8;
}
</style>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{

				onkeyup: false, 
 				rules: {nCommission:{ max:100000}}
			});
		});
</script>
</body></html>