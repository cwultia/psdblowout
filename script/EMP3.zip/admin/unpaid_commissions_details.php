<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Unpaid Commission Details';
	$css = <<<EOT
<!--page level css -->

<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

	
	switch ($chkSsettings->sCurrencyFormat) {
		case "USD":
			$cvalue = "$";
			break;
		case "EUR":
			$cvalue = "&euro;";
			break;
		case "JPY":
			$cvalue = "&yen;";
			break;
		default:
			$cvalue = $chkSsettings->sCurrencyFormat;
	}
	
	// Affiliate ID
	$affiliate_id = $dbo->format($_GET['id']);
	$objAffiliate = get_user_by_id($affiliate_id);
	
	// Delete commission
	if (isset($_GET['action']) && $_GET['action'] == 'delete') {
		$sql = "DELETE FROM tblaffiliatepayments WHERE nAffiliatePayment_ID=" . $dbo->format($_GET['del_id']);
		$dbo->delete($sql);
	}

	require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Affiliates</li>
      <li><a href="unpaid_commissions.php">Unpaid Commissions</a></li>
      <li class="active">Details</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
      <div style="line-height: 1em;"> <a href="unpaid_commissions.php"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="unpaid_commissions.php">Go Back</a>
      </div>
      <div class="panel panel-primary">
    <div class="panel-heading">
      <h3 class="panel-title"> Unpaid Commissions For <?php echo $objAffiliate->sForename ?> <?php echo $objAffiliate->sSurname ?></h3>
    </div>
    <div class="panel-body">
    <div class="table-responsive">
       <table class="table table-striped table-bordered table-hover">
       <thead>
        <tr>
          <th>Member Name</th>
          <th>Email Address</th>
          <th>Join/Renewal Date</th>
          <th>Membership</th>
          <th>Commission</th>
          <th>Actions</th>
          </tr>
          </thead>
          <tbody>
          <?php
			// Old Query Below. Used The Sale Customer Email TO Check.
			// This is flawed as custom can change their email.
			// New method tracks by User Id, Not User Email.
				
			$sql = "
				SELECT tblaffiliatepayments . * , tblusers.nUser_ID
				FROM tblaffiliatepayments
				INNER JOIN tblusers ON sEmail = tblaffiliatepayments.sUserEmail
				WHERE tblaffiliatepayments.sPaymentStatus = ''
				AND tblaffiliatepayments.nAffiliate_ID ='$affiliate_id'
				ORDER BY tblaffiliatepayments.nMemberJoinDate
			";
			//die($sql);
			
			// New Query Uses nUser_ID
			/*$sql = "
			SELECT tblaffiliatepayments . * , tblusers.nUser_ID
			FROM tblaffiliatepayments
			INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.sUserEmail
WHERE tblaffiliatepayments.sPaymentStatus = ''
AND tblaffiliatepayments.nAffiliate_ID ='$affiliate_id'
ORDER BY tblaffiliatepayments.nMemberJoinDate
			";*/
			
			$tot_amt = 0;
			$rs = $dbo->select($sql);
			if ($rs !== false) {
				while ($row = $dbo->getassoc($rs)) {
					echo '<tr>';
					echo '<td ><a href="view_member.php?id='.$row['nUser_ID'].'"> ' . $row['sUserForename'] . ' ' . $row['sUserSurname'] . '</a></td>';
					echo '<td ><a href="view_member.php?id='.$row['nUser_ID'].'">' . $row['sUserEmail'] . '</a></td>';
					echo '<td >' . fShowDate($chkSsettings->nDateFormat, $row['nMemberJoinDate']) . '</td>';
					echo '<td >' . $row['sItemName'] . '</td>';
					echo '<td>' . $cvalue . ' ' . number_format($row['nCommission'], 2) . '</td>';
					echo '<td><a href="unpaid_commissions_edit.php?aid=' . $affiliate_id . '&pid='. $row['nAffiliatePayment_ID'] .'"><img src="images/Edit_24x24.png" width="24" height="24" alt="Edit Commission" border="0"></a> <a href="#" onclick="delete_commission(\''. $row['nAffiliatePayment_ID'] .'\')"><img src="images/Delete_24x24.png" width="24" height="24" alt="Delete Commission" border="0"></a></td>';
					echo '</tr>';
					$tot_amt += $row['nCommission'];				
				}			
				// Totals
				echo '<tr><td colspan="4" align="right"><b>Total</b></td>';
				echo '<td align="right"><b>' . $cvalue . ' ' . number_format($tot_amt, 2) . '</b></td>';
				echo '<td>&nbsp;</td></tr>';
			} else {
				echo "<tr><td colspan='6'>No Records Found</td></tr>";
			}
		?>
        </tbody>
      </table>
    </div></div></div></div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">
function delete_commission(id) {
	
	if (confirm("Are you sure you want to delete this commission?")) {
		document.location.href='unpaid_commissions_details.php?id=<?php echo $affiliate_id?>&action=delete&del_id=' + id;
	}
}
</script>
</body></html>