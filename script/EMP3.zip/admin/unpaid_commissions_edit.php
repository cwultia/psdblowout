<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Edit Unpaid Commissions';
	$css = <<<EOT
<!--page level css -->

<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

	
	// Affiliate Payment ID
	$affiliate_id = $dbo->format($_REQUEST['aid']);
	
	// Affiliate Payment ID
	$affiliatepayment_id = $dbo->format($_REQUEST['pid']);
	
	//if(empty($affiliatepayment_id)) {die("Invalid ID");}
	
	// Update affiliate commission
	if( isset($_GET['action']) && $_GET['action'] == "update" )
	{
		$sql = "UPDATE tblaffiliatepayments SET nCommission=" . $dbo->format($_POST['nCommission']) . "	
		WHERE nAffiliatePayment_ID=" . $affiliatepayment_id;
		$dbo->update($sql);
		
		$updated = true;
	}
	
	$sql = "
	SELECT * FROM tblaffiliatepayments 
	WHERE nAffiliatePayment_ID = " . $affiliatepayment_id;
		
	$objAffiliatePayment = $dbo->getobject($sql);
	
require_once('header.php');
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li class="active"> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12">
    <?php
		if ($updated) {
			$message = '<p class="success">Commission has been updated!</p>';
		}
		?>
    <?php echo isset($message) ? $message : '' ?>
    <div class="row"> <a href="unpaid_commissions_details.php?id=<?php echo $affiliate_id?>"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="unpaid_commissions_details.php?id=<?php echo $affiliate_id?>">Go Back</a> </div>
    <div class="panel panel-primary">
    <div class="panel-heading">
      <h3 class="panel-title"> Edit Unpaid Commissions For <?php echo $objAffiliate->sForename ?> <?php echo $objAffiliate->sSurname ?></h3>
    </div>
    <div class="panel-body">
    <div class="table-responsive">
      <form name="fUpdateCommission" action="unpaid_commissions_edit.php?action=update" method="post">
        <input type="hidden" name="pid" value="<?php echo $affiliatepayment_id?>">
        <input type="hidden" name="aid" value="<?php echo $affiliate_id?>">
        <table class="table table-striped table-bordered table-hover">
          <tr>
            <th align="left">Member Name</th>
            <td><?php echo $objAffiliatePayment->sUserForename ?> <?php echo $objAffiliatePayment->sUserSurname ?></td>
          </tr>
          <tr>
            <th align="left">Join/Renewal Date</th>
            <td><?php echo fShowDate($chkSsettings->nDateFormat, $objAffiliatePayment->nMemberJoinDate) ?></td>
          </tr>
          <tr>
            <th align="left">Commission Amount</th>
            <td><input type="text" name="nCommission" value="<?php echo number_format($objAffiliatePayment->nCommission,2) ?>" style="width: 50px;"></td>
          </tr>
          <tr>
            <td colspan="2"><input type="submit" value="Update" class="btn btn-primary btn-responsive"></td>
          </tr>
        </table>
      </form>
    </div></div></div></div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
</body></html>