<?php
include_once('../conn.php');
include_once('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'User Fields';
	$css = <<<EOT
<!--page level css -->
<!--end of page level css-->
EOT;

	// Update values
	if (isset($_POST['Update'])) {
		
		// Update tblsitesettings
		$nDisplayAddress = isset($_POST['nDisplayAddress']) ? 1 : 0;
		$nDisplayPhone = isset($_POST['nDisplayPhone']) ? 1 : 0;
		$nDisplayMobile = isset($_POST['nDisplayMobile']) ? 1 : 0;
		$nDisplayCoupon = isset($_POST['nDisplayCoupon']) ? 1 : 0;
		
		$sql = "UPDATE tblsitesettings SET 
				nDisplayAddressField = $nDisplayAddress,
				nDisplayTelephoneField = $nDisplayPhone,
				nDisplayMobileField = $nDisplayMobile,
				nDisplayCouponField  = $nDisplayCoupon
				;";
		
		$dbo->update($sql);
		
		// Update tblcustomfieldsettings
		for ($i = 1; $i <= 10; $i++) {
			
			$nDisplay = isset($_POST["nDisplay_$i"]) ? 1 : 0;
			if($nDisplay == 1){$nRequired = isset($_POST["nRequired_$i"]) ? 1 : 0;}
			else{$nRequired = 0;}
			
			
			$sql = "UPDATE tblcustomfieldsettings SET
					sCustomFieldName = '" . $dbo->format($_POST["sCustomFieldName_$i"]) . "',
					nDisplay = $nDisplay,
					nSortOrder = " . $dbo->format($_POST["nSortOrder_$i"]) . ",
					nRequired = '$nRequired' 
					WHERE nCustomFieldSetting_ID = $i";
			
			$dbo->update($sql);
		}
		
		// Get updated site data
		$objSiteSettings = $dbo->getobject("SELECT * FROM tblsitesettings");
		
		// Update message
		$message = "<span class='success'>User fields have been updated.</span>";
		
	}
	else {$objSiteSettings = $chkSsettings;}
	require_once('header.php');
	?>

<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>General Settings</li>
			<li class="active">User Fields</li>
		</ol>
	</section>
	<section class="content">
		<div class="col-md-12"> <?php echo isset($message) ? '<p>' . $message . '</p>' : ''; ?>
			<p>The settings on this page allow you to turn on/off certain fields from the member's join page. You can also add up to 10 custom fields incase you need to capture additional information when members sign up.</p>
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Common Fields</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<th rowspan="2">Field Name</th>
									<th colspan="2">Join Form</th>
									<th colspan="2">Affiliate Form
										</td>
									<th colspan="2">Member Profile
										</td>
								</tr>
								<tr>
									<th>Display?</th>
									<th>Required?</th>
									<th>Display?</th>
									<th>Required?</th>
									<th>Display?</th>
									<th>Required?</th>
								</tr>
								<tr>
									<th>First Name</th>
									<td align="center" class="gridrow1"><input name="checkbox" type="checkbox" id="checkbox" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox8" type="checkbox" id="checkbox8" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox" type="checkbox" id="checkbox" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox8" type="checkbox" id="checkbox8" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox" type="checkbox" id="checkbox" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox8" type="checkbox" id="checkbox8" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<th>Last Name</th>
									<td align="center" class="gridrow1"><input name="checkbox5" type="checkbox" id="checkbox5" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox9" type="checkbox" id="checkbox9" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox5" type="checkbox" id="checkbox5" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox9" type="checkbox" id="checkbox9" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox5" type="checkbox" id="checkbox5" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox9" type="checkbox" id="checkbox9" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<th>Email</th>
									<td align="center" class="gridrow1"><input name="checkbox6" type="checkbox" id="checkbox6" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox10" type="checkbox" id="checkbox10" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox6" type="checkbox" id="checkbox6" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox10" type="checkbox" id="checkbox10" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox6" type="checkbox" id="checkbox6" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox10" type="checkbox" id="checkbox10" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<th>Password</th>
									<td align="center" class="gridrow1"><input name="checkbox7" type="checkbox" id="checkbox7" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox11" type="checkbox" id="checkbox11" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox7" type="checkbox" id="checkbox7" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox11" type="checkbox" id="checkbox11" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox7" type="checkbox" id="checkbox7" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox11" type="checkbox" id="checkbox11" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<th>Complete Address<br></th>
									<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayAddress" value="1" <?php echo ($objSiteSettings->nDisplayAddressField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
								</tr>
								<tr>
									<th>Phone</th>
									<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayPhone" value="1" <?php echo ($objSiteSettings->nDisplayTelephoneField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
								</tr>
								<tr>
									<th>Mobile</th>
									<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayMobile" value="1" <?php echo ($objSiteSettings->nDisplayMobileField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
								</tr>
								<tr>
									<th>Coupon</th>
									<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayCoupon" value="1" <?php echo ($objSiteSettings->nDisplayCouponField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1">&nbsp;</td>
									<td align="center" class="gridrow1"><input name="checkbox2" type="checkbox" id="checkbox2" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox3" type="checkbox" id="checkbox3" disabled></td>
									<td align="center" class="gridrow1">&nbsp;</td>
									<td align="center" class="gridrow1">&nbsp;</td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Custom Fields</h3>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover">
								<tr>
									<th>Field Name</th>
									<th>Display?</th>
									<th>Sort Order</th>
									<th>Join Required?</th>
								</tr>
								<?php
	$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
	while($row = $dbo->getobj($objCustomFieldSettings)):
	?>
								<tr>
									<td class="gridrow1"><input type="text" name="sCustomFieldName_<?php echo $row->nCustomFieldSetting_ID ?>" value="<?php echo $row->sCustomFieldName ?>" style="width: 300px;" /></td>
									<td class="gridrow1" align="center"><input type="checkbox" name="nDisplay_<?php echo $row->nCustomFieldSetting_ID ?>" value="1" <?php echo ($row->nDisplay) ? ' checked=checked' : '' ?> /></td>
									<td class="gridrow1"><input type="text" name="nSortOrder_<?php echo $row->nCustomFieldSetting_ID ?>" value="<?php echo $row->nSortOrder ?>" style="width: 30px;" /></td>
									<td class="gridrow1"><input name="nRequired_<?php echo $row->nCustomFieldSetting_ID ?>" type="checkbox" id="nRequired_<?php echo $row->nCustomFieldSetting_ID ?>" value="1" <?php echo ($row->nRequired) ? ' checked=checked' : '' ?> /></td>
								</tr>
								<?php endwhile; ?>
							</table>
						</div>
					</div>
				</div>
				<input type="submit" name="Update" value="Save Changes" class="btn btn-primary btn-responsive" />
			</form>
		</div>
	</section>
	<!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
</body></html>