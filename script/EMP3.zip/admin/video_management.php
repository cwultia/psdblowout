<?php

include_once ('../conn.php');
include_once ('../functions.php');

	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Video Management';
	$css = <<<EOT
<!--page level css -->



<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

	$ctid = (isset($_REQUEST['ctid'])) ? $_REQUEST['ctid'] : 0; // Category ID
	$ft = (isset($_REQUEST['ft'])) ? $_REQUEST['ft'] : ''; // File Type
	$ipp = (!empty($_GET['ipp'])) ? $_GET['ipp'] : 10; // Items per Page
	$sort = (!empty($_GET['sort'])) ? $_GET['sort'] : 'sFileName';
	$sortdir = (!empty($_GET['sortdir'])) ? $_GET['sortdir'] : 'ASC';
	$start = (!empty($_GET['start'])) ? $_GET['start'] : 0;
	
	// Set QueryString Values after post
	if (isset($_POST['Update'])) {
		$ctid = $_POST['ctid'];
		$ipp = $_POST['ipp'];
		$sort = $_POST['sort'];
		$sortdir = $_POST['sortdir'];
		$start = $_POST['start'];
	}
	
	// Setup Options for Items per Page listing
	$aIPP = array('5', '10', '15', '20', '25', '50', '100');
	
	// DELETE FILE
	if ($_GET['act'] == 'd') {
		$row = $dbo->getrow("SELECT sFilename FROM tblvideos WHERE nVideo_ID = '" . $dbo->format($_GET['flid']) . "'");
		$dbo->delete("DELETE FROM tblvideos WHERE nVideo_ID = " . $dbo->format($_GET['flid']));
		$message = "<p class='success'>Video has been deleted.</p>";
	}
	
	// LOCK/UNLOCK VIDEOS
	if (isset($_GET['lock']) && is_numeric($_GET['lock'])) {
		if (isset($_GET['id']) && is_numeric($_GET['id'])) {
			$sql = "UPDATE tblvideos SET nMemberOnly=" . $dbo->format($_GET['lock']) . " WHERE nVideo_ID=" . $dbo->format($_GET['id']);
			$dbo->update($sql);
		}
	}
	
	// IMPORT FILES
	if ($_GET['act'] == 'imp') {
		include_once('mime.php');
		$new = addVideosToDb('/');
		$removed = removeVideosFromDb();
		$msg = ($new > 0) ? $new . " videos(s) imported. " : "No videos to import. ";
		$msg .= ($removed > 0) ? $removed . " videos(s) removed. " : "No videos to remove. ";
		$message = "<p class='success'>$msg</p>";
	
	}
	
	// Get File Types List
	$aFile = array('All Files', 'AUDIO', 'DOC', 'EXCEL', 'EXE', 'FLASH', 'IMAGES', 'PDF', 'VIDEO', 'ZIP');
	ksort($aFile);
	$filetype = '';
	foreach ($aFile as $item) {
		$selected = ($item == $ft) ? 'selected' : '';
		$filetype .= sprintf("<option value='%s' %s>%s</option>", $item, $selected, $item);
	}
	
	require_once('header.php');
	
	$sql = sprintf("SELECT * FROM tblvideos ORDER BY %s %s ", $sort, $sortdir);
	// Get Count to pass into paging object
	$rs = $dbo->select("SELECT COUNT(*) FROM tblvideos " . $qry);
	$row = $dbo->getarray($rs,'NUM');
	$number = $row[0];
	
	// Start Paging
	/*********************************************************/
	include_once ('paging.php');
	$objPaging = new Paging();
	
	unset($_GET['start']);
	
	$objPaging->Total_Records_Per_Page = $ipp;
	$objPaging->Total_Records = $number;
	$index = $start;
	$indexupto = $index + $objPaging->Total_Records_Per_Page;
	$objPaging->prepare_ParameterString($_GET);
	$objPaging->set_Start_Item($indexupto);
	$objPaging->Has_First_Last = true;
	$navigator = $objPaging->Create_Paging();
	$pageinfo = $objPaging->get_PageInfo();
	$counter = 0;
	$sql .= "LIMIT " . $objPaging->Total_Records_Per_Page . " OFFSET " . $index;
	/*********************************************************/
	//echo $sql;
	
	$result = $dbo->select($sql);
	
	// Put together QueryString
	$qs = sprintf("?ctid=%s&start=%s&ipp=%s&ft=%s", $ctid, $start, $ipp, $ft);
	//echo $qs;
	
	?>

<aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
      <li>Content</li>
      <li class="active">Videos</li>
    </ol>
  </section>
  <section class="content">
    <div class="col-md-12"> <?php echo isset($message) ? $message : '' ?>
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> Video Management</h3>
        </div>
        <div class="panel-body">
          <div style="padding-bottom:10px; width:50%; float:left">
            <input class="btn btn-primary btn-responsive" type="button" 
            onClick="document.location.href='video_management_add.php'" value="Add Remote Video" />
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input class="btn btn-primary btn-responsive" type="button" 
            onClick="document.location.href='video_management.php<?php echo $qs ?>&act=imp'" value="Import Local Videos" />
          </div>
          <div style="padding-bottom:10px; width:50%; float:left; text-align:right">Items per page&nbsp;
            <select id='ipp' style='height:1.5em' onChange="updateIPP(this)">
              <?php
foreach ($aIPP as $val) {
    $selected = ($val == $ipp) ? 'selected' : '';
    ;
    echo "<option value='$val' $selected>$val</option>";
}
?>
            </select>
          </div>
          <div style="clear:both"></div>
          
          
            <form name="form1" method="post" action="video_management.php">
            <div class="table-responsive">
              <div class="row" style="padding-bottom:5px;">
                <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
                <div style="width:50%;float:left">
                  <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
                </div>
              </div>
              <table class="table table-striped table-bordered table-hover">
                <thead>
                  <tr valign="top">
                    <th><?php $sd = ($sort == 'sFileName' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="video_management.php<?php echo $qs ?>&sort=sFileName&sortdir=<?php echo $sd ?>" class="bluenave">Video Filename</a></th>
                    <th><?php $sd = ($sort == 'sURL' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="video_management.php<?php echo $qs ?>&sort=sURL&sortdir=<?php echo $sd ?>" class="bluenave">Location</a></th>
                    <th> Embed Code </th>
                    <th><?php $sd = ($sort == 'nMemberOnly' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
                      <a href="video_management.php<?php echo $qs ?>&sort=nMemberOnly&sortdir=<?php echo $sd ?>" class="bluenave">Member Only Video?</a></th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
          // Add Sort to QueryString
          $qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['sortdir']);
          if (!empty($result)){
            while ($row = $dbo->getobj($result)){
               $localpath = 'assets'.$row->sPath;
               // Subfolder detection
               if($row->sPath !=='/'){$localpath .= '/';}
   ?>
                  <!-- VIDEO LISTING -->
                  <tr> 
                    <!-- FILENAME -->
                    <td ><?php echo $row->sFileName ?></td>
                    <!-- LOCATION -->
                    <td ><?php echo empty($row->sURL) ? '<a href="' . $localpath.$row->sFileName . '" target="_blank">Local File</a>' :'<a href="' . $row->sURL . '" target="_blank">Remote URL</a>'; ?></td>
                    <!-- EMBED CODE -->
                    <td > [[video <?php echo $row->nVideo_ID; ?>]] </td>
                    <!-- MEMBER ONLY -->
                    <td ><?php if ($row->nMemberOnly == 0) : ?>
                      <a href="video_management.php<?php echo $qs?>&id=<?php echo $row->nVideo_ID; ?>&lock=1" class="black" title="This can currently be viewed on the front end and members area pages. Click the padlock to only allow members to view this video."> <img src="images/icon_lock_open.png" alt="This can currently be seen on the front end and members area. Click the padlock to only allow members to view this video." width="16" height="16" border="0" /> </a>
                      <?php else : ?>
                      <a href="video_management.php<?php echo $qs?>&id=<?php echo $row->nVideo_ID; ?>&lock=0" class='black' title="This can currently be viewed on member's pages only. Click the padlock to unlock it so that you can use this video on both front-end AND members pages."> <img src="images/icon_lock.png" alt="This can currently be viewed on member's pages only. Click the padlock to unlock it so that you can use this video on both front-end AND members pages." width="16" height="16" border="0" /> </a>
                      <?php endif; ?></td>
                    <!-- ACTIONS -->
                    <td ><!-- Delete --> 
                      <a href="video_management.php<?php echo $qs ?>&flid=<?php echo $row->nVideo_ID; ?>&act=d" class="bluenew" OnClick="return cdel('<?php echo $row->sTitle ?>');"><img src="images/drop.jpg" width="16" height="16" border="0" class="iconspacing"></a></td>
                  </tr>
                  <?php 
		}
	}
	else{?>
                  <tr>
                    <td colspan="6" class="gridFooter">No Videos Added Yet</td>
                  </tr>
                  <?php 
	}
																	
?>
                </tbody>
              </table>
              <div class="row" style="padding-bottom:5px;">
                <div style="width:50%;float:left"> &nbsp; <?php echo $navigator; 	?> </div>
                <div style="width:50%;float:left">
                  <div style="text-align:right"> Page <?php echo $pageinfo ?> </div>
                </div>
              </div>
              <input type="hidden" id="act" name="act" value="">
              <input type="hidden" name="ctid" value="<?php echo $ctid ?>">
              <input type="hidden" name="ipp" value="<?php echo $ipp ?>">
              <input type="hidden" name="sort" value="<?php echo $sort ?>">
              <input type="hidden" name="sortdir" value="<?php echo $sortdir ?>">
              <input type="hidden" name="start" value="<?php echo $start ?>">
            </div>
            </form>
          
        </div>
      </div>
    </div>
  </section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">
			function cdel(w) {
				return confirm("Are you sure you want to DELETE the\n\""+w+"\" video?");
			}

			function openPopup(page) {	
				window.open(page,'','height=265,width=650,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');
			}
			
			function MM_openBrWindow(theURL,winName,features) {
				window.open(theURL,winName,features);
			}
			
			function filterFiles(oList) {
				var ft = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&ft=' + ft;
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=<?php echo $ipp ?>';
				document.location = 'video_management.php' + qs;
			}

			function updateIPP(oList) {
				var ipp = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&ft=<?php echo $ft ?>';
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=' + ipp;
				document.location = 'video_management.php' + qs;
			}
		</script>
</body></html>