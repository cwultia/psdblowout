<?php
include_once ('../conn.php');
include_once ('../functions.php');

$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Add New Video';
	$css = <<<EOT
<!--page level css -->
<link href="vendors/fullcalendar/css/fullcalendar.css" rel="stylesheet" type="text/css" />
<link href="css/pages/calendar_custom.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="css/only_dashboard.css" />
<!-- daterange picker -->
<link href="vendors/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!--select css-->
<link href="vendors/select2/select2.css" rel="stylesheet" />
<link rel="stylesheet" href="vendors/select2/select2-bootstrap.css" />
<!--end of page level css-->
EOT;

// Process form
if (isset($_POST['Submit'])) {
	// Trim
	$url = trim($_POST['sVideoURL']);
	// Add Video URL to database
	$message = addRemoteVideoToDb($url) ? "<span class='success'>Video added to database successfully</span>" : "<span class='error'>There was a problem adding this video, please check the URL and try again.</span>";
}
 require_once('header.php');
	?>
   <aside class="right-side">
  <section class="content-header">
    <h1> <?php echo $title?> </h1>
    <ol class="breadcrumb">
      <li class="active"> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
	  <li>Content</li>
	  <li><a href="video_management.php">Video Management</a></li>
	  <li class="active">Add New Video</li>
    </ol>
  </section>
  <section class="content">

<!-- Start Content -->
<div class="col-md-12">
<?php echo isset($message) ? $message : '' ?>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title"> Add Remote Video</h3>
	</div>
	<div class="panel-body">
		<form id="formVideo" method="post" action="video_management_add.php">
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<th>URL <span style="color: red">*</span></th>
					<td class="gridRow1"><input type="text" name="sVideoURL" class="url required form-control" />
						<small>e.g. http://www.somewebsite.com/uploads/video123.flv</small></td>
				</tr>
			</table>
			<input name="Submit" type="submit" value="Submit" class="btn btn-primary btn-responsive">
		</form>
	</div>
</div>



</div>
</section>
  <!-- right-side --> 
</aside>
<?php
require_once('footer.php');
?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#formVideo").validate();
		});
</script>
	</body>
</html>