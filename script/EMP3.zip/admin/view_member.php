<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	if(!class_exists('empDateTime')){
		include_once('../includes/datetime.class.php');
		$empDateTime = new empDateTime($chkSsettings->nDateFormat);
	}
	
	$page = str_replace('.php','',basename($_SERVER['SCRIPT_FILENAME']));
	$title = 'Member Details';
	$css = <<<EOT
<!--page level css -->
<link href="vendors/modal/css/component.css" rel="stylesheet" />
<link href="css/pages/editor.css" rel="stylesheet" type="text/css"/>
<link href="vendors/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen" />

<!--end of page level css-->
EOT;
	
	if(!class_exists('empDateTime')){
		include_once('../includes/datetime.class.php');
		$empDateTime = new empDateTime($chkSsettings->nDateFormat);
	}
	
	// Set user id
	if (isset($_GET['id']) && is_numeric($_GET['id'])) {$_SESSION['user_id'] = $dbo->format($_GET['id']);}
	$user_id = $_SESSION['user_id'];
	
	// Get user's details
	$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = " . $user_id);
	if($objUser->nActive){$status = 'Active';}
	else{$status = 'Inactive';}
	
	// Get Login Details
	$sql = "SELECT * from tbluserlogins WHERE nUser_ID = $user_id ORDER BY nTimestamp DESC limit 1";
	$result = $dbo->select($sql);
	if($dbo->nr($result)){$loginData = $dbo->getobj($result);}
	
	$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
	
	// Get Payment Processors
	$payres = $dbo->select("SELECT nPaymentProcessor_ID,sProcessorName FROM tblpaymentprocessors");
	if($payres){
		while($row = $dbo->getobj($payres)){
			$processors[$row->nPaymentProcessor_ID] = $row->sProcessorName;
		}
	}
	
	// GET Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels";
	$levelRes = $dbo->select($sql);
	
	$levelsel = "<select id='membershiplevelselect' name='membershiplevel' onChange='getPaymentPlansByLevel(this)'>\n\t
	<option value = '0'>--- Choose Membership Level ---</option>\n\t";
	
	while($row = $dbo->getobj($levelRes)){
		$levelsel .= '<option value="'.$row->nLevel_ID.'">'.$row->sLevel.'</option>\n\t';
	}
	
	$levelsel .='</select>';
	
	require_once('header.php');
	// Lets Load Some Lists
	// Get All Payment Plans into array. $planlist
	$sql = "SELECT nPaymentPlan_ID,sPlanName FROM tblpaymentplans;";
	$listres = $dbo->select($sql);
	while($row = $dbo->getobj($listres)){
		$planlist[$row->nPaymentPlan_ID] = $row->sPlanName;
	}
	
	// Get All Coupons
	$sql = "SELECT nCoupon_ID,sCouponCode FROM tblcoupons;";
	$couponres = $dbo->select($sql);
	if($couponres){
		while($row = $dbo->getobj($couponres)){
			$couponlist[$row->nCoupon_ID] = $row->sCouponCode;
		}
	}
?>
<aside class="right-side">
	<section class="content-header">
		<h1> <?php echo $title?> </h1>
		<ol class="breadcrumb">
			<li> <a href="home.php"> <i class="livicon" data-name="home" data-size="16" data-color="#333" data-hovercolor="#333"></i> Home </a> </li>
			<li>Members</li>
			<li><a href="manage_members.php">Manage Members</a></li>
			<li class="active"> Member Details</li>
		</ol>
	</section>
	<section class="content"> <?php echo isset($message) ? $message : '' ?>
		<div class="col-md-4">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Member Profile <a href="#" onClick="return showEdit('profile','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<div id="profileShow" style="display:block">
							<table class="table table-striped table-bordered table-hover">
								<tr >
									<th>First name</th>
									<td ><?php echo $objUser->sForename ?></td>
								</tr>
								<tr >
									<th>Last name</th>
									<td><?php echo $objUser->sSurname ?></td>
								</tr>
								<tr >
									<th>Email Address</th>
									<td>
										<a style="text-decoration:underline" data-toggle="modal" data-href="#sendEmail" href="#sendEmail" data-user-id = "<?php echo $objUser->nUser_ID ?>" title="Click To Send Email"><?php echo $objUser->sEmail ?></a>
									</td>
								</tr>
								<tr >
									<th>Password</th>
									<td><?php echo $objUser->sPassword?></td>
								</tr>
								<tr >
									<th>Address</th>
									<td><?php echo $objUser->sAddr1 ?></td>
								</tr>
								<tr >
									<th>&nbsp;</th>
									<td><?php echo $objUser->sAddr2 ?></td>
								</tr>
								<tr >
									<th>City/Town</th>
									<td><?php echo $objUser->sTown ?></td>
								</tr>
								<tr >
									<th>State/County</th>
									<td><?php echo $objUser->sCounty ?></td>
								</tr>
								<tr >
									<th>Zip/Postcode</th>
									<td><?php echo $objUser->sPostcode ?></td>
								</tr>
								<tr >
									<th>Country</th>
									<td><?php echo get_country_name($objUser->sCountry) ?></td>
								</tr>
								<tr >
									<th>Telephone</th>
									<td><?php echo $objUser->sTelephone ?></td>
								</tr>
								<tr >
									<th>Mobile</th>
									<td><?php echo $objUser->sMobile ?></td>
								</tr>
							</table>
							<div align="center">
								<form action="login_as_client.php" method="post" name="form1" target="_new">
									<input name="user" type="hidden" id="user" value="<?php echo $objUser->sEmail ?>">
									<input type="submit" name="button" id="button" value="Login as Member" class="btn btn-responsive btn-primary">
									&nbsp;
									<input type="button" class="btn btn-responsive btn-success" name="senddetails" id="senddetails" value="Send Login Details" onClick="resendLogin();">
								</form>
								<span id="msgResend"></span> </div>
						</div>
						<!-- Hidden Edit Details Box -->
						<div id="profileEdit" style="display:none">
							<form action="actions.php?type=member" method="post">
								<table class="table table-striped table-bordered table-hover">
									<tr >
										<td class="">First name</td>
										<td ><input class="required" name="sForename" id="sForename" style="width:90%;" type="text" value="<?php echo ($_SESSION['form']['sForename'])? $_SESSION['form']['sForename']: $objUser->sForename;?>" />
											<?php if($_SESSION['profile']['errors']['nm']==1)	echo '<br /><span class="error">[ REQUIRED ]</span>'; ?></td>
									</tr>
									<tr >
										<td>Last name</td>
										<td><input class="required" name="sSurname" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sSurname'])? $_SESSION['form']['sSurname']: $objUser->sSurname;?>" type="text" />
											<?php if($_SESSION['profile']['errors']['ln']==1) echo '<br /><span class="error">[ REQUIRED ]</span>';	?></td>
									</tr>
									<tr >
										<td>Email Address</td>
										<td><input class="required email" name="sEmail" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sEmail'])? $_SESSION['form']['sEmail']: $objUser->sEmail;?>" />
											<?php
		if($_SESSION['profile']['errors']['em']==1)	echo "<br /><span class=\"error\">[ REQUIRED ]</span>";
		if($_SESSION['profile']['errors']['em']==2) echo "<br /><span class=\"error\">[ INVALID ]</span>";
		?></td>
									</tr>
									<tr >
										<td>Password</td>
										<td><input class="" name="sPassword" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sPassword'])? $_SESSION['form']['sPassword']: $objUser->sPassword;?>" type="password"/>
											<?php if($_SESSION['profile']['errors']['pw']==1) echo '<br /><span class="error">Passwords Do Not Match</span>'; ?></td>
									</tr>
									<tr >
										<td>Confirm Password</td>
										<td><input class="" name="sConfirmPass" style="width:90%;" size="40"  value="" type="password"/></td>
									</tr>
									<tr >
										<td>Address</td>
										<td><input  name="sAddr1" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sAddr1'])? $_SESSION['form']['sAddr1']: $objUser->sAddr1;?>"type="text" /></td>
									</tr>
									<tr >
										<td>&nbsp;</td>
										<td><input  name="sAddr2" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sAddr2'])? $_SESSION['form']['sAddr2']: $objUser->sAddr2;?>"type="text" /></td>
									</tr>
									<tr >
										<td>City/Town</td>
										<td><input  name="sTown" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sTown'])? $_SESSION['form']['sTown']: $objUser->sTown;?>" /></td>
									</tr>
									<tr >
										<td>State/County</td>
										<td><input  name="sCounty" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sCounty'])? $_SESSION['form']['sCounty']: $objUser->sCounty;?>" type="text" /></td>
									</tr>
									<tr >
										<td>Zip/Postcode</td>
										<td><input  name="sPostcode" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sPostcode'])? $_SESSION['form']['sPostcode']: $objUser->sPostcode;?>" /></td>
									</tr>
									<tr >
										<td>Country</td>
										<td><?php
		if($_POST['country']=="")
		{
			$co7=$row->sCountry;
		}
		else
		{
			$co7=$_POST['country'];
		}
	
		$Selected = ($country) ? $country : (($_SESSION['form']['sCountry'])? $_SESSION['form']['sCountry']: $objUser->sCountry);
		//$CountryDropMenu = countrydm("sCountry",$Selected);
		//echo $CountryDropMenu;
		echo get_country_list('sCountry',$Selected,0);
		
		?></td>
									</tr>
									<tr >
										<td>Telephone</td>
										<td><input  name="sTelephone" style="width:90%;" value="<?php echo ($_SESSION['form']['Telephone'])? $_SESSION['form']['sTelephone']: $objUser->sTelephone;?>" /></td>
									</tr>
									<tr >
										<td>Mobile</td>
										<td><input  name="sMobile" style="width:90%;" value="<?php echo ($_SESSION['form']['Mobile'])? $_SESSION['form']['sMobile']: $objUser->sMobile;?>" /></td>
									</tr>
								</table>
								<input name="id" type="hidden" value="<?php echo $objUser->nUser_ID ?>">
								<input name="act" type="hidden" value="updateProfile">
								<br />
								<div align="center">
									<input type="submit" value="Update Profile" class="btn btn-responsive btn-primary"/>
									&nbsp;
									<input type="button" value="Cancel" onClick="showEdit('profile','show')" class="btn btn-responsive btn-danger"/>
								</div>
							</form>
						</div>
						<!-- End Hidden End --> 
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Account Information<a href="#" onClick="return showEdit('account','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<div id="accountShow">
							<div align="center"></div>
							<table class="table table-striped table-bordered table-hover">
								<tr >
									<th>Account Type</th>
									<td><form action="actions.php?type=member" method="post">
											<?php
				
				// If Is Already Admin
				if($objUser->nAdmin){?>
											Administrator
											<?php }
				else{?>
											Customer
											<?php } ?>
										</form></td>
								</tr>
								<tr >
									<th>Status</th>
									<td ><form action="actions.php?type=member" method="post">
											<?php if ($objUser->nUser_ID == 1) : ?>
											<a href="#" onClick="javascript:alert('You cannot deactivate the admin user.');return false;"><img src="images/dropd.gif" alt="Not allowed to deactivate the admin user" width="16" height="16" border="0" /></a>
											<?php else : ?>
											<?php if ($objUser->nActive == 0) : ?>
											Inactive
											<?php else : ?>
											Active
											<?php endif; // ($row->nActive == 0) ?>
											<?php endif; // ($row->nUser_ID == 1) ?>
										</form></td>
								</tr>
								<tr >
									<th>Signup Date</th>
									<td><?php echo fShowDate($chkSsettings->nDateFormat, $objUser->nJoinDate) ?></td>
								</tr>
								<tr >
									<th>Customer For</th>
									<td><?php 
			  
				$diff = abs(time() - strtotime($objUser->nJoinDate));

				$years = floor($diff / (365*60*60*24));
				$months = floor($diff / (60*60*24*30));
				$days = floor($diff / (60*60*24));
				
				if($days < 30){$since = $days.' Days';}
				else{
					if($months < 12){$since = $months.' Months';}
					else{
						if($years > 1){$since = $years.' Years';}
						else{$since = $years.'Year';}
						}
					
					}
			  
			  echo $since ?></td>
								</tr>
								<tr >
									<th>Email Preference</th>
									<td><form action="actions.php?type=member" method="post">
											<?php if ($objUser->nUnsubscribe == '0'){  ?>
											Receive All
											<?php }else{?>
											Receive None
											<?php } ?>
										</form></td>
								</tr>
								<tr >
									<th>Email Status</th>
									<td><?php echo ($objUser->nConfirmed) ?'<span class="green">Confirmed</span>': '<span class="error">Un-Confirmed</span>' ?></td>
								</tr>
								<tr >
									<th>Last Login</th>
									<td><?php if($loginData){?>
										Date: <?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$loginData->nTimestamp)) ?><br>
										Ip	Address: <?php echo $loginData->sIp ?><br>
										Browser: <?php echo $loginData->sBrowser ?>
										<?php }
              else{echo 'Never';} ?></td>
								</tr>
							</table>
						</div>
						<div id="accountEdit" style="display:none;">
							<form action="actions.php?type=member" method="post">
								<table class="table table-striped table-bordered table-hover">
									<tr >
										<th><label for="nAdmin">Account Type</label></th>
										<td><select name="nAdmin" id="nAdmin">
												<option value="1" <?php echo ($objUser->nAdmin) ? 'selected' :''; ?>>Administrator</option>
												<option value="0" <?php echo (!$objUser->nAdmin) ? 'selected' :''; ?>>Customer</option>
											</select></td>
									</tr>
									<tr >
										<th><label for="nActive">Status</label></th>
										<td ><select name="nActive" id="nActive">
												<option value="1" 
													<?php 
													if($objUser->nUser_ID == 1){echo 'disabled ';}
													if($objUser->nActive == '1'){echo 'selected';}
													
													?>> Active </option>
												<option value="0"
									
													<?php 
													if($objUser->nUser_ID == 1){echo 'disabled ';}
													if($objUser->nActive == '0'){echo 'selected';}
													
													?>>Inactive </option>
											</select></td>
									</tr>
									<tr >
										<th><label for="nJoinDate">Signup Date</label></th>
										<td><input name="nJoinDate" type="text" id="nJoinDate" value="<?php echo fShowDate($chkSsettings->nDateFormat, $objUser->nJoinDate) ?>" class="datepicker"></td>
									</tr>
									<tr >
										<th><label for="nUnsubscribe">Email Preference</label></th>
										<td><select name="nUnsubscribe" id="nUnsubscribe">
												<option value="0" <?php echo ($objUser->nUnsubscribe == '0') ? 'selected': '' ?>>Receive All</option>
												<option value="1" <?php echo ($objUser->nUnsubscribe == '1') ? 'selected': '' ?>>Receive None</option>
											</select></td>
									</tr>
									<tr >
										<th><label for="nConfirmed">Email Status</label></th>
										<td><select name="nConfirmed" id="nConfirmed">
												<option value="1" <?php echo ($objUser->nConfirmed) ? 'selected' : '' ?> >Confirmed</option>
												<option value="0" <?php echo ($objUser->nConfirmed) ? '' : 'selected'?> >Unconfirmed</option>
											</select></td>
									</tr>
								</table>
								<div align="center">
									<input name="id" type="hidden" value="<?php echo $objUser->nUser_ID ?>">
									<input name="currentconfirm" type="hidden" value="<?php echo $objUser->nConfirmed ?>">
									<input name="act" type="hidden" value="updateAccount">
									<input name="" type="submit" value="Update Changes" class="btn btn-responsive btn-primary">
									&nbsp;&nbsp;
									<input type="button" name="button2" id="button2" value="Cancel"  class="btn btn-responsive btn-warning" onClick="return showEdit('account','show')">
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Admin Functions</h3>
				</div>
				<div class="panel-body"> <a class="btn btn-responsive btn-success" data-toggle="modal" data-href="#addNewSale" href="#addNewSale">Add Sale</a> <a class="btn btn-responsive btn-info" data-toggle="modal" data-href="#addNewLevel" href="#addNewLevel">Assign Membership</a> <a class="btn btn-responsive btn-warning" data-toggle="modal" data-href="#addTransaction" href="#addTransaction">Add Transaction</a> </div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Admin Comments</h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<div>
							<form action="actions.php?type=member" method="post">
								<textarea name="sComments" id="comments" rows="5" class="form-control" onKeyPress="showEdit('comments','edit')" ><?php echo $objUser->sComments ?></textarea>
								<input type="hidden" name="id" value="<?php echo $objUser->nUser_ID ?>" />
								<input type="hidden" name="act" value="updateComments" />
								<div id="commentsEdit" style="display:none" align="center">
									<input type="submit" value="Save Comments" class="btn btn-primary btn-responsive"/>
									&nbsp;
									<input type="button" value="Cancel" onClick="showEdit('comments','show')" class="btn btn-warning btn-responsive" />
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Affiliate Information <a href="#" onClick="return showEdit('affiliate','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<div id="affiliateShow">
							<table class="table table-striped table-bordered table-hover">
								<tr >
									<th>Referred By</th>
									<td ><?php $user = get_user_by_id($objUser->nAffiliate_ID);echo ($user)?'<a href="?id='.$objUser->nAffiliate_ID.'">'.$user->sForename.' '.$user->sSurname.'</a>':'None' ?></td>
								</tr>
								<tr >
									<th>Is Affiliate</th>
									<td ><?php echo ($objUser->nAffiliate)?'Yes':'No' ?></td>
								</tr>
								<?php if($objUser->nAffiliate){?>
								<tr >
									<th>Paypal Email</th>
									<td><?php echo ($objUser->sPaypalEmail)? $objUser->sPaypalEmail : 'None'?></td>
								</tr>
								<tr >
									<th>Custom Commission %</th>
									<td><?php echo ($objUser->nCustomCommission > 0)? $objUser->nCustomCommission.' %':'None' ?></td>
								</tr>
								<tr >
									<th>Affiliate Link</th>
									<td><?php echo $chkSsettings->sSiteURL?>/index.php?afid=<?php echo $objUser->nUser_ID ?></td>
								</tr>
								<?php } ?>
							</table>
						</div>
						<!-- Hidden Edit Field -->
						<div id="affiliateEdit" style="display:none">
							<form action="actions.php?type=member" method="post">
								<table class="table table-striped table-bordered table-hover">
									<tr >
										<th>Referred By</th>
										<td ><select name="nAffiliate_ID">
												<option value="">No Affiliate</option>
												<?php
		$sqlaf="select * from tblusers 
		where naffiliate=1 and nUser_ID != '" . $objUser->nUser_ID . "' 
		order by sforename";

		$resultaf = $dbo->select($sqlaf);
		if ($resultaf) {
			while($rowaf=$dbo->getobj($resultaf))
			{
				echo "<option value=\"" . $rowaf->nUser_ID . "\"";
			
				if($rowaf->nUser_ID==$objUser->nAffiliate_ID) echo "selected";
			
				echo ">" . $rowaf->sForename . " " . $rowaf->sSurname . "</option>";
			}
		}
		?>
											</select></td>
									</tr>
									<tr >
										<th>Is Affiliate</th>
										<td ><input type="checkbox" name="nAffiliate" value="1" 
			  <?php if($_SESSION['form']['nAffiliate']){if($_SESSION['form']['nAffiliate'] == 1){echo "checked";}}
			  else{if($objUser->nAffiliate==1) { echo "checked"; }} ?> /></td>
									</tr>
									<tr >
										<th>Paypal Email</th>
										<td><input class="inputText" name="sPaypalEmail" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sPaypalEmail'])?$_SESSION['form']['sPaypalEmail']: $objUser->sPaypalEmail?>" />
											<?php if($_SESSION['affiliate']['errors']['pem']==2) echo "<br /><span class=\"error\">[ INVALID FORMAT ]</span>";?></td>
									</tr>
									<tr >
										<th>Custom Commission %</th>
										<td><input class="inputText" name="nCustomCommission" style="width: 50px;" size="40" value="<?php echo ($_SESSION['form']['nCustomCommission']) ?$_SESSION['form']['nCustomCommission']:$objUser->nCustomCommission?>" /></td>
									</tr>
								</table>
								<div align="center">
									<input type="submit" value="Save Affiliate" class="btn btn-primary btn-responsive"/>
									&nbsp;
									<input type="button" value="Cancel" onClick="showEdit('affiliate','show')" class="btn btn-warning btn-responsive"/>
								</div>
								<input type="hidden" name="id" value="<?php echo $objUser->nUser_ID ?>" />
								<input type="hidden" name="act" value="updateAffiliate" />
							</form>
						</div>
						<!-- END Hidden Edit Field --> 
					</div>
				</div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Additional Profile Details <a href="#" onClick="return showEdit('customfields','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<div id="customfieldsShow">
							<div align="center"></div>
							<table class="table table-striped table-bordered table-hover">
								<?php
			$c = 0;
			$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
			while($row2 = $dbo->getobj($objCustomFieldSettings)):
			if($row2->nCustomFieldSetting_ID ==1){$v = $objUser->sCustomField1;}
			elseif($row2->nCustomFieldSetting_ID ==2){$v = $objUser->sCustomField2;}
			elseif($row2->nCustomFieldSetting_ID ==3){$v = $objUser->sCustomField3;}
			elseif($row2->nCustomFieldSetting_ID ==4){$v = $objUser->sCustomField4;}
			elseif($row2->nCustomFieldSetting_ID ==5){$v = $objUser->sCustomField5;}
			elseif($row2->nCustomFieldSetting_ID ==6){$v = $objUser->sCustomField6;}
			elseif($row2->nCustomFieldSetting_ID ==7){$v = $objUser->sCustomField7;}
			elseif($row2->nCustomFieldSetting_ID ==8){$v = $objUser->sCustomField8;}
			elseif($row2->nCustomFieldSetting_ID ==9){$v = $objUser->sCustomField9;}
			else{$v = $objUser->sCustomField10;}
			if($v!='')$c++;
			if($c > 0 && $v !=''){
				
	?>
								<tr >
									<th><?php echo $row2->sCustomFieldName ?></th>
									<td width="189"><?php echo $v; ?></td>
								</tr>
								<?php }endwhile;
	  if($c == 0){echo '<tr ><td>None</td></tr>';} ?>
							</table>
						</div>
						<!-- Hidden Edit Field -->
						<div id="customfieldsEdit" style="display:none;">
							<form action="actions.php?type=member" method="post">
								<table class="table table-striped table-bordered table-hover">
									<?php
			$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
			while($row2 = $dbo->getobj($objCustomFieldSettings)):
			if($row2->nCustomFieldSetting_ID ==1){$v = $objUser->sCustomField1;}
			elseif($row2->nCustomFieldSetting_ID ==2){$v = $objUser->sCustomField2;}
			elseif($row2->nCustomFieldSetting_ID ==3){$v = $objUser->sCustomField3;}
			elseif($row2->nCustomFieldSetting_ID ==4){$v = $objUser->sCustomField4;}
			elseif($row2->nCustomFieldSetting_ID ==5){$v = $objUser->sCustomField5;}
			elseif($row2->nCustomFieldSetting_ID ==6){$v = $objUser->sCustomField6;}
			elseif($row2->nCustomFieldSetting_ID ==7){$v = $objUser->sCustomField7;}
			elseif($row2->nCustomFieldSetting_ID ==8){$v = $objUser->sCustomField8;}
			elseif($row2->nCustomFieldSetting_ID ==9){$v = $objUser->sCustomField9;}
			else{$v = $objUser->sCustomField10;}
	?>
									<tr >
										<th><?php echo $row2->sCustomFieldName ?></th>
										<td><input  name="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>" id="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>" style="width:90%;" size="40" type="text" value="<?php echo $v; ?>" /></td>
									</tr>
									<?php endwhile; ?>
								</table>
								<input type="hidden" name="id" value="<?php echo $objUser->nUser_ID ?>" />
								<input type="hidden" name="act" value="updateCustom" />
								<div align="center">
									<input type="submit" value="Update Fields" class="btn btn-responsive btn-primary"/>
									&nbsp;
									<input type="button" value="Cancel" onClick="showEdit('customfields','show')" class="btn btn-responsive btn-warning"/>
								</div>
							</form>
							<!-- END Hidden Edit Field --> 
						</div>
					</div>
				</div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Recent Emails</h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<div id="recentEmails">
							<table class="table table-striped table-bordered table-hover">
								<?php
			$c = 0;
			$objRecentEmails = $dbo->select("SELECT *,  UNIX_TIMESTAMP(dSentTime) as sentstamp FROM tblemails WHERE nUser_ID = ".$objUser->nUser_ID." AND nStatus = '1' ORDER BY dSentTime DESC LIMIT 5");
			if($objRecentEmails){
				while($row2 = $dbo->getobj($objRecentEmails)):?>
								<tr >
									<td width="136" nowrap="nowrap" ><?php echo $empDateTime->showDateFromStamp($row2->sentstamp); echo ' '.$empDateTime->showTimeFromStamp($row2->sentstamp);?></td>
									<td width="189"><a id="recentEmailLink" onClick="loadRecentEmail(<?php echo $row2->nEmail_ID; ?>);"><?php echo $row2->sSubject; ?></a></td>
								</tr>
								<?php endwhile;
			}
			
	  else{echo '<tr ><td>None</td></tr>';} ?>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Active Membership Levels</h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead>
								<tr>
									<th>Membership Level</th>
									<th>Started On </th>
									<th>Current Day</th>
									<th>Expires</th>
									<th>Coupon </th>
									<th>Pay Plan </th>
									<th>Payment Count</th>
									<th>Transaction #</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php
				// Get only levels this user belongs to
				
				$sql = "SELECT tbluserlevels. *, 
				tblmembershiplevels.sLevel,
				tblpaymentplans.nRegularAmount,
				tblpaymentplans.nRegularPeriod,
				tblpaymentplans.sRegularPeriod,
				tblpaymentplans.nOneTimePayment,
				tblpaymentplans.sPlanName,
				tblpaymentprocessors.sProcessorName
				FROM tbluserlevels
				INNER JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
				LEFT JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
				LEFT JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
				WHERE tbluserlevels.nUser_ID =".$dbo->format($_GET['id'])." AND tbluserlevels.nActive = 1;";

				//die($sql);
				$result = $dbo->select($sql);
				if($dbo->nr($result)){
					while($row = $dbo->getobj($result)){?>
								<tr>
									<td ><?php echo $row->sLevel ?></td>
									<td ><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateActive);?></td>
									<td ><?php  
				
											$start = strtotime($row->nDateActive);
											$end = time();
											$days_between = ceil(abs($end - $start) / 86400);
											echo $days_between;
				
				  							?>
									</td>
									<td ><?php
											$class = ($row->nDateExpires < date('Ymd'))?'class="error"':'class="green"';
										?>
										<span <?php echo $class ?>><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?></span></td>
									<td ><?php echo  ($row->nCoupon_ID !=NULL && $row->nCoupon_ID !='0')?$row->nCoupon_ID:'None'; ?></td>
									<td ><?php echo ($row->sPlanName)?$row->sPlanName: 'N/A' ?></td>
									<td ><?php echo $row->nPaymentCounter;?></td>
									<td ><?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'N/A';?></td>
									<td ><form action="actions.php?type=member" method="post">
											<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>" />
											<input type="hidden" name="nAssignedLevel_ID" value="<?php echo $row->nUserLevel_ID ?>" />
											<input type="hidden" name="act" value="modlevel" />
											<input type="hidden" name="Level" value="Deactivate" />
											<?php 
						// No Payment Button Needed For One Time Payments, that never expire.
						
						if($row->nPaymentPlan_ID =! '0' || $row->nOneTimePayment != '1' && $row->nRegularPeriod != '0'){}
						
						if($row->nOneTimePayment == '1' && $row->nRegularPeriod == '0'){}else{
							 // No Payment Button Available For Admin Assigned Membership 
							 if($row->nPaymentPlan_ID != '0'){
							 $row->formattedExpireDate = fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); 
							?>
											<div style="display:none" id="row_<?php echo $row->nUserLevel_ID ?>"><?php echo json_encode($row)?></div>
<a class="btn btn-responsive btn-success" data-toggle="modal" data-href="#editLevel" href="#editLevel" data-id = "<?php echo $row->nUserLevel_ID ?>">Edit Level</a>
											<?php }
						} ?>
											<input name="" type="submit" value="Deactivate" class="btn btn-responsive btn-danger"/>
										</form></td>
								</tr>
								<?php }
				}
				else{
					echo '<tr><td  colspan="9"> No Active Memberships</td></tr>';
					} ?>
							</tbody>
						</table>
						<br>
					</div>
				</div>
			</div>
									<?php
// We need to go back through the loop and print divisions.
	
	if($dbo->nr($result)){
		
		$dbo->seek($result, 0);
		$n = 0;
		while($row = $dbo->getobj($result)){?>
			<?php $pickers[$n] = 'txt'; ?>
			<div id="LevelEdit_<?php echo $row->nUserLevel_ID ?>" style="display:none">
	<table>
		<tr>
			<th><label for="Plan">Payment Plan</label></th>
			<td><select name="Plan" id="Plan">
					<option value="0" <?php if($row->nPaymentPlan_ID == 0){ echo 'selected'; }?>>None</option>
					<?php
						// build the select from the predefined array of details.
						// Current Payment Plan Id $row->nPaymentPlan_ID
					foreach($planlist as $k=>$v){ ?>
						<option value="<?php echo $k ?>" <?php  if($k == $row->nPaymentPlan_ID) { echo 'selected';} ?> ><?php echo $v; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<tr>
			<th><label for="Count">Payment Count</label></th>
			<td><input type="text" name="Count" id="Count" value="<?php echo $row->nPaymentCounter ?>"/></td>
		</tr>
		<tr>
			<th>Transaction #</th>
			<td>
				<div id="txncontainer_<?php echo $row->nUserLevel_ID ?>">
				<input name="Txn" onKeyUp="lookup(this.value,'txn.php','.suggestionsm','.autoSuggestionsListm');" type="text"  value="<?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'';?>" autocomplete="off"/>
				<input type="hidden" id="suggestionsmHidden" name="suggestionsmHidden" />
				</div>
				<div class="suggestionsBox suggestionsm"  style="display: none;">
					<img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />
					<div class="suggestionList autoSuggestionsListm" ></div>
				</div>
			</td>
		</tr>
		<tr>
			<th>Coupon Used</th>
			<td ><select name="Coupon" id="Coupon">
					<option value="0" <?php if($row->nCoupon_ID == NULL){ echo 'selected'; }?>>None</option>
					<?php foreach($couponlist as $k=>$v){ ?>
					<option value="<?php echo $k ?>" <?php  if($k == $row->nCoupon_ID) { echo 'selected';} ?> ><?php echo $v; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<tr>
			<th>Start Date</th>
			<td >
			<label for="nExpires" class="col-sm-3 control-label">Select New Start Date</label>
        <div class="col-sm-5">
             <div class='input-group date'>
                 <input id="DateActive"  name="DateActive" type='text' class="col-sm-3 form-control" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateActive);?>"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
			</td>
		</tr>
		<tr>
			<th>Expire Date</th>
			<td >
			<label for="DateExpires" class="col-sm-3 control-label">Select New Start Date</label>
			 <div class='input-group date'>
			 <input type="text" name="DateExpires" class="col-sm-3 form-control" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?>" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>"/>
			  <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span></div>
			 </td>
			
		</tr>
	</table>
	<input type="hidden" name="level_id" value="<?php  echo $row->nUserLevel_ID  ?>" />
</div>			
<?php	$n++;}
	}
?>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Inactive Membership Levels</h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead>
								<tr>
									<th>Membership Level</th>
									<th>Started On </th>
									<th>Current Day</th>
									<th>Expires</th>
									<th>Coupon </th>
									<th>Pay Plan </th>
									<th>Payment Count</th>
									<th>Transaction #</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php
				// Get only levels this user belongs to
				
				$sql = "SELECT tbluserlevels. *, 
				tblmembershiplevels.sLevel,
				tblpaymentplans.nRegularAmount,
				tblpaymentplans.nRegularPeriod,
				tblpaymentplans.sRegularPeriod,
				tblpaymentplans.nOneTimePayment,
				tblpaymentplans.sPlanName,
				tblpaymentprocessors.sProcessorName
				FROM tbluserlevels
				INNER JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
				LEFT JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
				LEFT JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
				WHERE tbluserlevels.nUser_ID =".$_GET['id']." AND tbluserlevels.nActive = 0;";

				//die($sql);
				$result = $dbo->select($sql);
				if($dbo->nr($result)){
					while($row = $dbo->getobj($result)){?>
								<tr>
									<td ><?php echo $row->sLevel ?></td>
									<td ><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateActive);?></td>
									<td ><?php  
				
				$start = strtotime($row->nDateActive);
				$end = time();
				$days_between = ceil(abs($end - $start) / 86400);
				echo $days_between;
				
				  ?></td>
									<td ><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?></td>
									<td ><?php echo  ($row->nCoupon_ID !=NULL)?$row->nCoupon_ID:'None'; ?></td>
									<td ><?php echo ($row->sPlanName)?$row->sPlanName: 'N/A' ?></td>
									<td ><?php echo $row->nPaymentCounter;?></td>
									<td ><?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'N/A';?></td>
									<td ><form name="form2" method="post" action="actions.php?type=member">
											<?php if($row->nOneTimePayment == '1' && $row->nRegularPeriod == '0'){}
										else{
					  						$row->formattedExpireDate = fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); 
					  					?>
											<div style="display:none" id="row_<?php echo $row->nUserLevel_ID ?>"><?php echo json_encode($row)?></div>
											<a class="btn btn-primary btn-responsive btn-md" data-toggle="modal" data-href="#addPayment" href="#addPayment" data-row = "<?php echo $row->nUserLevel_ID ?>">Add Payment</a>
											<?php } ?>
											<a class="btn btn-responsive btn-success btn-md" data-toggle="modal" data-href="#ReactivateLevel" href="#ReactivateLevel" data-level-id = "<?php echo $row->nUserLevel_ID?>">Reactivate Level</a>
											<input  type="submit" value="Delete" class="btn btn-responsive btn-danger btn-md"/>
											<input name="act" type="hidden" id="act" value="modlevel" />
											<input name="Level" type="hidden" id="Level" value="Delete" />
											&nbsp;
											<input name="nAssignedLevel_ID" type="hidden" id="nAssignedLevel_ID" value="<?php echo $row->nUserLevel_ID ?>" />
										</form></td>
								</tr>
								<?php }
				}
				else{?>
								<tr>
									<td  colspan="9"> No Active Memberships</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Recent Transactions - <a href="manage_transactions.php?user=<?php echo $objUser->nUser_ID ?>"> View All</a></h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead>
								<tr>
									<th>Transaction Type</th>
									<th>Payment Processor</th>
									<th>Amount</th>
									<th>Date</th>
									<th>Transaction #</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$sql = "
								SELECT tbltransactions . * ,tbltransactiontypes.sType
								FROM tbltransactions
								JOIN tbltransactiontypes ON tbltransactiontypes.nTransactionType_ID = tbltransactions.nTransactionType_ID
								WHERE nUser_ID = '{$objUser->nUser_ID}' ORDER BY `tbltransactions`.`nTransaction_ID` DESC LIMIT 5";
			
								$res = $dbo->select($sql);
								// Used for V2 Compatibility
								$sql2 = "
								SELECT tbltransactions . * ,tbltransactiontypes.sType
								FROM tbltransactions
								JOIN tbltransactiontypes ON tbltransactiontypes.nTransactionType_ID = tbltransactions.nTransactionType_ID
								WHERE sUserEmail = '{$objUser->sEmail}' ORDER BY `tbltransactions`.`nTransaction_ID` DESC LIMIT 5";
								$res2 = $dbo->select($sql2);
								if($dbo->nr($res)){
				while($row3 = $dbo->getobj($res)){ ?>
								<tr>
									<td ><a href="manage_transactions.php?id=<?php echo $row3->nTransaction_ID ?>"><?php echo $row3->sType ?></a></td>
									<td ><?php echo $row3->sProcessor ?></td>
									<td ><?php echo $currency_symbol; echo number_format($row3->nSaleAmount,2); ?></td>
									<td ><?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',strtotime($row3->dDateTime))) ?></td>
									<td ><?php echo $row3->sTransactionNumber ?></td>
								</tr>
								<?php }
				}
								elseif($dbo->nr($res2)){
				while($row3 = $dbo->getobj($res2)){ ?>
								<tr>
									<td ><?php echo $row3->sType ?></td>
									<td ><?php echo $row3->sProcessor ?></td>
									<td ><?php echo $currency_symbol;echo number_format($row3->nSaleAmount,2); ?></td>
									<td ><?php echo fShowDate($chkSsettings->nDateFormat,strtotime($row3->dDateTime)) ?></td>
									<td ><?php echo $row3->sTransactionNumber ?></td>
								</tr>
								<?php }
				}
								else{echo '<tr><td colspan = "5" >No Transactions For User</td></tr>';}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<?php echo pluginClass::filter('admin_view_member_bottom');?> </div>
	</section>
	<!-- right-side --> 
</aside>
<!-- Begin Modal Windows --> 
<!-- Reactivate Level -->
<div class="modal fade in" id="ReactivateLevel" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
<form action="actions.php?type=member" method="post">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title">Reactivate Membership For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?></h4>
			</div>
			<div class="modal-body">
					<div class="form-group"><br />

    <label for="nExpires" class="col-sm-3 control-label">Select New Expiration Date</label>
        <div class="col-sm-5">
             <div class='input-group date' id='reactive_expire'>
                 <input id="nExpires" name="nExpires" type='text' class="col-sm-3 form-control" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 month')));?>"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
        </div><br />
<br />
			</div>
			<div class="modal-footer">
					<input type="hidden" name="nAssignedLevel_ID" id="ReactivateLevelId" value="" />
					<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
					<input type="hidden" name="act" value="modlevel" />
					<input type="hidden" name="Level" value="Reactivate" />
					<input name="" type="submit" value="Reactivate" class="btn btn-responsive btn-primary"/>
				<button type="button" data-dismiss="modal" class="btn btn-responsive btn-danger">Close</button>
			</div>
		</div>
	</div>
	</form>
</div>
<!-- Edit Level -->
<div class="modal fade in" id="editLevel" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form id="Model-Form" action="actions.php?type=member" method="post">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					Edit Membership Level</div>
				<div class="modal-body"><br />
					<div id="model-form-container"></div>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="act" value="modlevel" />
					<input type="hidden" name="Level" value="Edit" />
					<input class="btn btn-responsive btn-primary" type="submit" value="Save Changes"  />
					<button type="button" data-dismiss="modal" class="btn btn-responsive btn-danger">Close</button>
				</div>
			</div>
		</div>
	</form>
</div>
<!-- Add Payment -->
<div class="modal fade in" id="addPayment" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form action="actions.php?type=member" method="post" name="newPayment">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title">Add New Payment For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?></h4>
				</div>
				<div class="modal-body">
					<div id="recurring-instructions" style="display:none;width:500px;">
						<p>This feature will allow you to manually add a failed recurring payment, or reinstate the level using a new subscription id. </p>
						<p> If adding a received subscription payment that was not recorded by the script, the subscription number should remain the same.</p>
						<p> If linking this membership to a new subscription payment, than enter the new subscription id in the field below. </p>
						<p>This is an expermental process, that will eventually allow users to reinstate a previously assigned membership level, instead of creating a new one. <br>
							This will also allow for pick up where you left off, functionality. </p>
					</div>
					<div id="onetime-instructions" style="width:500px;">
						<p>This feature will allow you to manually process payments to extend expiration periods, where an automatic recurring payment system is not in place. </p>
						<p>This is an expermental process, that will eventually allow users to reinstate a previously assigned membership level, instead of creating a new one. <br>
							This will also allow for pick up where you left off, functionality. </p>
					</div>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<tr>
								<th>Membership Level</th>
								<td><span id="payment_LevelName">&nbsp;</span></td>
							</tr>
							<tr>
								<th>Payment Plan</th>
								<td><span id="payment_PlanName">&nbsp;</span></td>
							</tr>
							<tr>
								<th>Current <span id="payment_LevelIdentifier">Transaction</span> Number</th>
								<td><span id="payment_LevelIdentifierValue"></span></td>
							</tr>
							<tr>
								<th>New <span id="payment_LevelIdentifier2">Transaction</span> Number</th>
								<td><input type="text" name="payment_transactionnumber" id="payment_transactionnumber" class="form-control" /></td>
							</tr>
							<tr>
								<th><label for="payment_datetime" class="control-label">Select New Start Date</label></th>
								<td>
								 
			 <div class='input-group date'>
			<input type="text" name="payment_datetime" id="payment_datetime" class="col-sm-3 form-control" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i');?>" data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?> hh:ii" readonly="readonly"/>
			  <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span></div>
								</td>
							</tr>
							<tr>
								<th>Expire <span id="expirePeriod"></span> From:</th>
								<td><input type="radio" name="setExpire" value="payment" id="RadioGroup1_0" />
									<label>Payment Date</label>
									<br />
									<input type="radio" name="setExpire" value="expire" id="RadioGroup1_1" />
									<label>Current Expire Date (<span id="currentExpireDate"></span> )</label>
									<br />
									<input type="radio" name="setExpire" value="lesser" id="RadioGroup1_2" />
									<label>Lesser</label>
									<br />
									<input name="setExpire" type="radio" id="RadioGroup1_3" value="greater" checked="checked" />
									<label>Greater</label></td>
							</tr>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="act" value="addPaymentByLevel">
					<input type="hidden" name="userId" value="<?php echo $_GET['id']  ?>" />
					<input type="hidden" id="paymentPlanId" name="planId" value="" />
					<input type="hidden" name="userLevelId" id="payment_userLevelId" value="" />
					<input type="submit" value="Process Payment" class="btn btn-responsive btn-primary"/>
					<button type="button" data-dismiss="modal" class="btn btn-responsive">Close</button>
				</div>
			</div>
		</div>
	</form>
</div>
<!-- Add New Sale -->
<div class="modal fade in" id="addNewSale" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form action="actions.php?type=member" method="post">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title">Add New Sale For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?></h4>
				</div>
				<div class="modal-body">
					<p><strong>Adding A New Sale Will Perform The Following Actions:</strong><br>
						Add A New Sale Transaction To The database<br>
						Assign Affiliate Commission On The Sale<br>
						Assign New Membership Level To Member </p>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<tr>
								<th>Membership Level</th>
								<td><?php echo $levelsel ?></td>
							</tr>
							<tr>
								<th>Payment Plan</th>
								<td><select name="paymentPlan" id="paymentPlan">
										<option>--- Select Payment Plan ---</option>
									</select></td>
							</tr>
							<tr>
								<th>Transaction #</th>
								<td><input type="text" name="transactionnumber" id="transactionnumber" /></td>
							</tr>
							<tr>
								<th>Date / Time</th>
								<td >
									<label for="datetime" class="col-sm-3 control-label">Transaction Time</label>
        							<div class="col-sm-5">
             <div class='input-group date'>
                <input type="text" name="datetime" id="newSale_datetime" class="col-sm-3 form-control" 
				data-date-format="<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?> hh:ii"
				value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i');?> " readonly />
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
		
		</td>
	</tr>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<input name="act" type="hidden" value="processManualSale" />
					<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
					<input type="submit" value="Process Sale" class="btn btn-responsive btn-primary"/>
					<button type="button" data-dismiss="modal" class="btn btn-responsive btn-dander">Close</button>
				</div>
			</div>
		</div>
	</form>
</div>
<!-- Add New Level -->
<div class="modal fade in" id="addNewLevel" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form action="actions.php?type=member" method="post">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					Add New Membership For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?> </div>
				<div class="modal-body">
					<select name="nLevel_ID" id="nLevel_ID" class="select2">
						<option value="">Assign a level to this member</option>
						<?php 
				// Get all levels which user is not already assigned to
				$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels 
				WHERE nActive=1 AND nLevel_ID NOT IN (SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $objUser->nUser_ID . ")ORDER BY sLevel";
				$result = $dbo->select($sql);
				if ($result) {
					while ($objLevel = $dbo->getobj($result)) {
						echo '<option value="' . $objLevel->nLevel_ID . '">' . $objLevel->sLevel . '</option>';
					}
				}
				?>
					</select>
					&nbsp;
					
					Expires:
					<input  name="nDateExpires" id="nDateExpires" style="width: 80px;" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 month')));?>" readonly />
					<?php if($df==1)	echo "<span class=\"required\">Invalid date format (mm/dd/yyyy)</span>"; ?>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="act" value="modlevel" />
					<input type="hidden" name="Level" value="Add" />
					<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
					<input name="Level" type="submit" id="Level"  value="Add" class="btn btn-responsive btn-primary">
					<button type="button" data-dismiss="modal" class="btn btn-responsive btn-dander">Close</button>
				</div>
			</div>
		</div>
	</form>
</div>
<!-- Add Transaction -->
<div class="modal fade in" id="addTransaction" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form action="actions.php?type=member" method="post">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					Add New Transaction For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?> </div>
				<div class="modal-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<tr>
								<th><label for="type">Transaction Type</label></th>
								<td ><select name="type" id="type">
										<option value="1" selected>Sale</option>
										<option value="2">Refund</option>
										<option value="3">Cancellation</option>
									</select></td>
							</tr>
							<tr>
								<th>Processor</th>
								<td ><select name="processor" id="processor">
										<option value="" selected>None</option>
										<?php
				foreach ($processors as $k=>$v){?>
										<option value="<?php echo $v ?>"><?php echo $v ?></option>
										<?php }
				
				
				?>
									</select></td>
							</tr>
							<tr>
								<th>Transaction # </th>
								<td ><input type="text" name="transactionnumber" id="transactionnumber"></td>
							</tr>
							<tr>
								<th><label for="amount">Amount</label>
								</th>
								<td ><?php echo $currency_symbol ?>
									<input type="text" name="amount" id="amount"></td>
							</tr>
							<tr>
								<th>Date / Time </th>
								<td ><input type="text" name="datetime" id="datetime"  
		value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i s');?> " readonly /></td>
							</tr>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="act" value="addTransaction" />
					<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
					<input type="submit" value="Save Transaction" class="btn btn-responsive btn-primary"/>
					<button type="button" data-dismiss="modal" class="btn btn-responsive btn-danger">Close</button>
				</div>
			</div>
		</div>
	</form>
</div>
<!-- Send Email -->
<div class="modal fade in" id="sendEmail" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<form action="actions.php?type=member" method="post" id="sendEmailModal">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					Send Email To Member</div>
				<div class="modal-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<tr>
								<th>From Name:</th>
								<td><label for="from_name"></label>
									<input type="text" name="from_name" id="from_name" value="<?php echo $chkSsettings->sSiteName ?>" style="width:90%"></td>
							</tr>
							<tr>
								<th>From Email:</th>
								<td><label for="from_email"></label>
									<input type="text" name="from_email" id="from_email" value="<?php echo $chkSsettings->sSupportEmail ?>" style="width:90%"></td>
							</tr>
							<tr>
								<th>Email Type</th>
								<td><p>
										<label>
											<input name="emailType" type="radio" id="EmailType_0" value="text"  onClick="setEmailType(this)">
											Plain Text</label>
										<br>
										<label>
											<input type="radio" name="emailType" value="html" id="EmailType_1" checked="CHECKED" onClick="setEmailType(this)">
											Html</label>
										<br>
									</p></td>
							</tr>
						</table>
						<br>
						<table class="table table-striped table-bordered table-hover">
							<tr>
								<th>Subject:</th>
								<td><label for="subject"></label>
									<input name="subject" type="text" id="subject" size="50" style="width:90%"></td>
							</tr>
							<tr>
								<th>Message</th>
								<td><label for="email_message"></label>
									<textarea name="email_message" id="email_message" cols="45" rows="15" style="width:90%" class="tinymce_full"></textarea></td>
							</tr>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="sendEmailToId" id="sendEmailToId">
					<input type="hidden" name="act" value="sendEmail">
					<input type="submit" name="button2" id="button2" value="Send Mail" class="btn btn-responsive btn-primary">
					<button type="button" data-dismiss="modal" class="btn btn-responsive btn-danger">Close</button>
				</div>
			</div>
		</div>
	</form>
</div>
<!-- Recent Email Details -->
<div class="modal fade in" id="recentEmail" tabindex="-1" role="dialog" aria-hidden="false" style="display:none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				Send Email To Member</div>
			<div class="modal-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
						<tr>
							<th>Subject</th>
							<td><span id="recentEmail_Subject">Loading ...</span></td>
						</tr>
						<tr>
							<th valign="top" >Message</th>
							<td><span id="recentEmail_Message" style="max-width:400px;">Loading ...</span></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" data-dismiss="modal" class="btn btn-responsive btn-danger">Close</button>
			</div>
		</div>
	</div>
</div>



<!-- END Modal Windows -->
<?php require_once('footer.php'); ?>
<!--datetime picker-->
<script type="text/javascript" src="vendors/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="vendors/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>

<?php if(get_option('use_mce') == '1'){
		$doc_base = $chkSsettings->sSiteURL .'/'; ?>
<script  src="vendors/tinymce/js/tinymce/tinymce.min.js" type="text/javascript" ></script>
<script type="text/javascript" src="common/js/tiny_mce/init.php?folder=<?php echo TEMPLATEFOLDER ?>&base=<?php echo $doc_base  ?>&linktype=r"></script>
<?php } ?>
<script src="vendors/modal/js/classie.js"></script> 
<script src="vendors/modal/js/modalEffects.js"></script> 
<script language="javascript" type="text/javascript" src="common/js/view_member.js">	</script>
<iframe name="runcode" scrolling="auto" frameborder="1" style="width:0; height:0; visibility:hidden" src="about:blank" tabindex="-1"></iframe>
<script type="text/javascript">
var pickerFormat = '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>';
var pickerEnd = '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?>';
$(function() {
	$('#reactive_expire').datetimepicker({
		format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?>',
		minView: 'month',
		endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?>', 
    	autoclose: true
	});
	$('#newSale_datetime').datetimepicker({
		 format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?> hh:ii', 
		<!-- endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?> - 00:00:00', -->
    	autoclose: true,
		minuteStep:1
	});
	$('#payment_datetime').datetimepicker({
		 format: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat)?> hh:ii', 
		<!-- endDate: '<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd','2145916800'));?> - 00:00:00', -->
    	autoclose: true,
		minuteStep:1
	});
});
    <?php if($_SESSION['profile']['errors']){?>
		$(document).ready(showEdit('profile','edit'));
	<?php } ?>
	<?php if($_SESSION['affiliate']['errors']){
		//die(var_dump($_SESSION['profile']['errors'])); ?>
		
		$(document).ready(showEdit('affiliate','edit'));
	<?php } ?>
		</script>
</body></html>